import React from 'react';
import { AppState } from '../types';

export function OnboardingTour({
  state,
  updateState,
  setActiveTab,
}: {
  state: AppState;
  updateState: any;
  setActiveTab: (tab: string) => void;
}) {
  // If tour has already been seen or dismissed
  if (state.onboardingCompleted) return null;

  return null;
}
