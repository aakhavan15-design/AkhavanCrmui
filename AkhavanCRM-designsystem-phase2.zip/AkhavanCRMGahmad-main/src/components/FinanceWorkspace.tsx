import React, { useState } from 'react';
import { AppState, Cheque, Payment, Invoice } from '../types';
import { Card } from './ui/Card';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { 
  Wallet, TrendingUp, AlertCircle, FileText, CheckCircle, Clock, 
  Plus, CheckCircle2, DollarSign, CreditCard, ShieldAlert, PhoneCall,
  CalendarCheck, AlertTriangle, ArrowUpRight, ShieldCheck, Check
} from 'lucide-react';
import { generateId, formatAppDate } from '../lib/utils';
import { CustomDatePicker } from './ui/CustomDatePicker';
import { 
  evaluateAllCustomerCollections, 
  generateCollectionTaskForAccount, 
  CustomerCollectionProfile 
} from '../services/collectionEngine';
import { DynamicFormRenderer } from './shared/DynamicFormRenderer';
import { COLLECTION_PROMISE_SCHEMA } from '../services/dynamicFormEngine';

interface FinanceWorkspaceProps {
  state: AppState;
  updateState?: (updater: (draft: AppState) => AppState | void) => void;
}

export function FinanceWorkspace({ state, updateState }: FinanceWorkspaceProps) {
  const [activeTab, setLocalTab] = useState<'overview' | 'invoices' | 'payments' | 'cheques' | 'collection'>('overview');
  const [notice, setNotice] = useState<string | null>(null);

  // Collection Engine Modal States
  const [showPromiseModal, setShowPromiseModal] = useState(false);
  const [selectedProfileForPromise, setSelectedProfileForPromise] = useState<CustomerCollectionProfile | null>(null);
  const [showAutoTaskModal, setShowAutoTaskModal] = useState(false);
  const [selectedProfileForTask, setSelectedProfileForTask] = useState<CustomerCollectionProfile | null>(null);
  const [autoTaskDueDate, setAutoTaskDueDate] = useState(new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]);
  const [autoTaskNote, setAutoTaskNote] = useState('');

  // New Payment Modal
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [payAccountId, setPayAccountId] = useState('');
  const [payAmount, setPayAmount] = useState('50000000');
  const [payMethod, setPayMethod] = useState<'CASH' | 'TRANSFER' | 'CHEQUE'>('TRANSFER');
  const [payRef, setPayRef] = useState('');
  const [payBank, setPayBank] = useState('بانک ملت');

  // New Invoice Modal
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invSource, setInvSource] = useState<'FROM_QUOTE' | 'MANUAL'>('FROM_QUOTE');
  const [invSelectedQuoteId, setInvSelectedQuoteId] = useState('');
  const [invAccountId, setInvAccountId] = useState('');
  const [invAmount, setInvAmount] = useState('120000000');
  const [invDescription, setInvDescription] = useState('صورتحساب رسمی فروش و خدمات');
  const [invNumber, setInvNumber] = useState('');
  const [invDueDate, setInvDueDate] = useState(new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0]);

  // New Cheque Modal
  const [showChequeModal, setShowChequeModal] = useState(false);
  const [chqAccountId, setChqAccountId] = useState('');
  const [chqAmount, setChqAmount] = useState('80000000');
  const [chqNumber, setChqNumber] = useState('');
  const [chqBank, setChqBank] = useState('بانک صادرات');
  const [chqDueDate, setChqDueDate] = useState(new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]);

  const invoices = state.invoices || [];
  const payments = state.payments || [];
  const cheques: Cheque[] = state.cheques || [];
  const today = new Date().toISOString().split('T')[0];

  let totalReceivables = 0;
  let totalOverdue = 0;
  let totalCredit = 0;

  const aging = {
    current: 0,
    days30: 0,
    days60: 0,
    days90: 0,
    days90Plus: 0
  };

  invoices.forEach(inv => {
    const balance = inv.totalAmount - inv.paidAmount;
    if (balance > 0) {
      totalReceivables += balance;
      if (inv.dueDate && inv.dueDate < today) {
        totalOverdue += balance;
        
        const diffTime = Math.abs(new Date(today).getTime() - new Date(inv.dueDate).getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays <= 30) aging.days30 += balance;
        else if (diffDays <= 60) aging.days60 += balance;
        else if (diffDays <= 90) aging.days90 += balance;
        else aging.days90Plus += balance;
      } else {
        aging.current += balance;
      }
    } else if (balance < 0) {
      totalCredit += Math.abs(balance);
    }
  });

  const openCheques = cheques.filter(c => c.status === 'PENDING' || c.status === 'RECEIVED' || c.status === 'DEPOSITED');
  const openChequesTotal = openCheques.reduce((sum, c) => sum + c.amount, 0);

  const overdueTasks = (state.tasks || []).filter(t => t.dueDate && t.dueDate < today && t.status !== 'COMPLETED').length;
  const todayVisits = (state.activities || []).filter(a => a.type === 'VISIT' && a.dateTime.startsWith(today)).length;

  const handleCreatePayment = () => {
    if (!payAccountId || !updateState) return;
    const amountNum = Number(payAmount) || 0;
    const refCode = payRef.trim() || `TRX-${Math.floor(100000 + Math.random() * 900000)}`;

    const newPayment: Payment = {
      id: generateId(),
      accountId: payAccountId,
      customerId: payAccountId,
      amount: amountNum,
      date: new Date().toISOString(),
      method: payMethod,
      reference: refCode,
      bankName: payBank,
      status: 'CLEARED'
    };

    updateState(draft => {
      if (!draft.payments) draft.payments = [];
      draft.payments.unshift(newPayment);

      // update account balance
      const acc = (draft.accounts || []).find(a => a.id === payAccountId);
      if (acc) {
        acc.balance = (acc.balance || 0) - amountNum;
      }
    });

    setShowPaymentModal(false);
    setNotice(`تراکنش واریز به مبلغ ${amountNum.toLocaleString()} ریال با کد رهگیری ${refCode} با موفقیت ثبت شد.`);
    setTimeout(() => setNotice(null), 4000);
  };

  const handleCreateInvoice = () => {
    if (!invAccountId || !updateState) return;
    const amountNum = Number(invAmount) || 0;
    const invNum = invNumber.trim() || `INV-${Math.floor(140300 + Math.random() * 900)}`;

    const selectedQuote = state.quotes?.find(q => q.id === invSelectedQuoteId);
    let invoiceItems = [
      {
        id: generateId(),
        description: invDescription || 'صورتحساب خدمات و کالا',
        quantity: 1,
        unitPrice: amountNum,
        total: amountNum
      }
    ];

    if (invSource === 'FROM_QUOTE' && selectedQuote && selectedQuote.lines.length > 0) {
      invoiceItems = selectedQuote.lines.map(line => {
        const prod = state.externalProducts?.find(p => p.id === line.productId);
        return {
          id: generateId(),
          description: prod?.name || `کالای کد ${line.productId}`,
          quantity: line.quantity,
          unitPrice: line.unitPrice,
          total: line.lineTotal
        };
      });
    }

    const newInvoice: Invoice = {
      id: generateId(),
      invoiceNumber: invNum,
      accountId: invAccountId,
      customerId: invAccountId,
      totalAmount: amountNum,
      paidAmount: 0,
      balance: amountNum,
      status: 'UNPAID',
      date: new Date().toISOString(),
      dueDate: invDueDate,
      items: invoiceItems
    };

    updateState(draft => {
      if (!draft.invoices) draft.invoices = [];
      draft.invoices.unshift(newInvoice);

      const acc = (draft.accounts || []).find(a => a.id === invAccountId);
      if (acc) {
        acc.balance = (acc.balance || 0) + amountNum;
        acc.totalRevenue = (acc.totalRevenue || 0) + amountNum;
      }

      if (invSource === 'FROM_QUOTE' && selectedQuote) {
        const q = draft.quotes?.find(item => item.id === selectedQuote.id);
        if (q) {
          q.status = 'ACCEPTED';
          (q as any).invoicedId = newInvoice.id;
        }
      }
    });

    setShowInvoiceModal(false);
    setNotice(`فاکتور رسمی جدید ${invNum} به مبلغ ${amountNum.toLocaleString()} ریال صادر گردید.`);
    setTimeout(() => setNotice(null), 4000);
  };

  const handleCreateCheque = () => {
    if (!chqAccountId || !updateState) return;
    const amountNum = Number(chqAmount) || 0;
    const num = chqNumber.trim() || `CHQ-${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    const newCheque: Cheque = {
      id: generateId(),
      chequeNumber: num,
      bankName: chqBank,
      amount: amountNum,
      dueDate: chqDueDate,
      status: 'RECEIVED',
      customerId: chqAccountId,
      accountId: chqAccountId
    };

    updateState(draft => {
      if (!draft.cheques) draft.cheques = [];
      draft.cheques.unshift(newCheque);
    });

    setShowChequeModal(false);
    setNotice(`چک صیادی شماره ${num} به مبلغ ${amountNum.toLocaleString()} ریال ثبت گردید.`);
    setTimeout(() => setNotice(null), 4000);
  };

  const collectionData = evaluateAllCustomerCollections(state);

  const handleSavePromise = (formValues: Record<string, any>) => {
    if (!selectedProfileForPromise || !updateState) return;
    const targetAccount = state.accounts?.find(a => a.id === selectedProfileForPromise.accountId);
    if (!targetAccount) return;

    const promiseId = generateId();
    const promisedAmountNum = Number(formValues.promisedAmount) || 0;
    const promisedDateStr = formValues.promisedDate || new Date().toISOString().split('T')[0];

    updateState(draft => {
      if (!(draft as any).collectionPromises) (draft as any).collectionPromises = [];
      (draft as any).collectionPromises.unshift({
        id: promiseId,
        accountId: targetAccount.id,
        accountName: targetAccount.name,
        promisedAmount: promisedAmountNum,
        promisedDate: promisedDateStr,
        paymentMethod: formValues.paymentMethod,
        sayadChequeNumber: formValues.sayadChequeNumber,
        contactPerson: formValues.contactPerson,
        notes: formValues.negotiationNotes,
        status: 'PENDING',
        createdAt: new Date().toISOString()
      });

      if (formValues.autoGenerateCalendarTask) {
        if (!draft.tasks) draft.tasks = [];
        const newTask = generateCollectionTaskForAccount(
          targetAccount,
          selectedProfileForPromise,
          state.currentUserId || 'user-admin',
          promisedDateStr,
          `تعهد واریز ${promisedAmountNum.toLocaleString('fa-IR')} ریال توسط ${formValues.contactPerson} (${formValues.paymentMethod === 'SAYAD_CHEQUE' ? 'چک صیاد' : 'واریز نقدی'}).`
        );
        draft.tasks.unshift(newTask);
      }

      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.unshift({
        id: generateId(),
        customerId: targetAccount.id,
        type: 'PROMISE',
        title: `ثبت تعهد پرداخت به مبلغ ${promisedAmountNum.toLocaleString('fa-IR')} ریال`,
        description: `مذاکره با: ${formValues.contactPerson} | موعد: ${formatAppDate(promisedDateStr, state.settings?.locale)} | روش: ${formValues.paymentMethod === 'SAYAD_CHEQUE' ? 'چک صیادی' : 'حواله مستقیم'}`,
        dateTime: new Date().toISOString()
      });

      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.unshift({
        id: generateId(),
        action: 'COLLECTION_PROMISE_CREATED',
        entityType: 'ACCOUNT',
        entityId: targetAccount.id,
        details: `ثبت تعهد پرداخت مطالبات برای "${targetAccount.name}" به مبلغ ${promisedAmountNum.toLocaleString()} ریال`,
        actor: state.currentUserId || 'کاربر سیستم',
        createdAt: new Date().toISOString()
      });
    });

    setShowPromiseModal(false);
    setSelectedProfileForPromise(null);
    setNotice(`تعهد پرداخت برای ${targetAccount.name} به مبلغ ${promisedAmountNum.toLocaleString()} ریال با موفقیت ثبت و وظیفه پیگیری تنظیم شد.`);
    setTimeout(() => setNotice(null), 5000);
  };

  const handleGenerateManualTask = () => {
    if (!selectedProfileForTask || !updateState) return;
    const targetAccount = state.accounts?.find(a => a.id === selectedProfileForTask.accountId);
    if (!targetAccount) return;

    updateState(draft => {
      if (!draft.tasks) draft.tasks = [];
      const newTask = generateCollectionTaskForAccount(
        targetAccount,
        selectedProfileForTask,
        state.currentUserId || 'user-admin',
        autoTaskDueDate,
        autoTaskNote
      );
      draft.tasks.unshift(newTask);

      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.unshift({
        id: generateId(),
        action: 'COLLECTION_TASK_CREATED',
        entityType: 'TASK',
        entityId: newTask.id,
        details: `وظیفه پیگیری وصول مطالبات برای مشتری "${targetAccount.name}" ایجاد شد.`,
        actor: state.currentUserId || 'کاربر سیستم',
        createdAt: new Date().toISOString()
      });
    });

    setShowAutoTaskModal(false);
    setSelectedProfileForTask(null);
    setAutoTaskNote('');
    setNotice(`وظیفه پیگیری وصول برای ${targetAccount.name} در کارتابل وظایف و تقویم شمسی ثبت گردید.`);
    setTimeout(() => setNotice(null), 5000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-canvas p-5 sm:p-8 space-y-6 pb-32" dir="rtl">
      {notice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-2xl flex items-center gap-2 font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}
      
      {/* Header and Quick Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl font-black text-text-main tracking-tight">امور مالی و وصولی</h1>
          <p className="text-xs text-text-secondary mt-0.5">پایش وضعیت جریان وجوه نقد، فاکتورها، دریافتی‌ها و چک‌های صیادی</p>
        </div>
        
        {updateState && (
          <div className="flex flex-wrap items-center gap-2">
            <button 
              onClick={() => {
                if (state.accounts?.[0]) setPayAccountId(state.accounts[0].id);
                setShowPaymentModal(true);
              }}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all active:scale-95"
            >
              <Plus size={14} /> ثبت دریافتی / حواله
            </button>
            <button 
              onClick={() => {
                if (state.accounts?.[0]) setInvAccountId(state.accounts[0].id);
                setShowInvoiceModal(true);
              }}
              className="px-3.5 py-2 bg-primary hover:bg-primary-dark text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all active:scale-95"
            >
              <Plus size={14} /> صدور فاکتور جدید
            </button>
            <button 
              onClick={() => {
                if (state.accounts?.[0]) setChqAccountId(state.accounts[0].id);
                setShowChequeModal(true);
              }}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all active:scale-95"
            >
              <Plus size={14} /> ثبت چک صیادی
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5">
          <div className="flex items-center gap-2.5 mb-2 text-text-secondary">
            <Wallet size={16} />
            <span className="text-xs font-bold">کل مطالبات (ریال)</span>
          </div>
          <div className="text-lg font-black text-text-main font-mono">{totalReceivables.toLocaleString()}</div>
        </Card>
        <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5">
          <div className="flex items-center gap-2.5 mb-2 text-[#991B1B]">
            <AlertCircle size={16} />
            <span className="text-xs font-bold">معوقات (ریال)</span>
          </div>
          <div className="text-lg font-black text-[#991B1B] font-mono">{totalOverdue.toLocaleString()}</div>
        </Card>
        <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5">
          <div className="flex items-center gap-2.5 mb-2 text-[#166534]">
            <TrendingUp size={16} />
            <span className="text-xs font-bold">بستانکاری مشتریان</span>
          </div>
          <div className="text-lg font-black text-[#166534] font-mono">{totalCredit.toLocaleString()}</div>
        </Card>
        <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5">
          <div className="flex items-center gap-2.5 mb-2 text-[#92400E]">
            <FileText size={16} />
            <span className="text-xs font-bold">چک‌های در جریان</span>
          </div>
          <div className="text-lg font-black text-[#92400E] font-mono">{openCheques.length} فقره</div>
          <div className="text-[10px] text-text-secondary mt-1 font-mono">{openChequesTotal.toLocaleString()} ریال</div>
        </Card>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="bg-[#FEF2F2] text-[#991B1B] px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2.5 border border-[#FECACA] shadow-subtle">
          <Clock size={14} /> {overdueTasks} وظیفه پیگیری معوق
        </div>
        <div className="bg-[#F0FDF4] text-[#166534] px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2.5 border border-[#DCFCE7] shadow-subtle">
          <CheckCircle size={14} /> {todayVisits} ویزیت وصولی امروز
        </div>
      </div>

      <Card padding="lg" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-6 space-y-4">
        <h2 className="text-sm font-bold text-text-main">گزارش سنی مطالبات (AR Aging)</h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
          <div className="bg-canvas p-4 rounded-2xl border border-border/60">
            <div className="text-[10px] text-text-secondary mb-1 font-bold">جاری</div>
            <div className="text-xs sm:text-sm font-bold text-text-main font-mono">{aging.current.toLocaleString()}</div>
          </div>
          <div className="bg-[#FFFBEB] p-4 rounded-2xl border border-[#FDE68A]">
            <div className="text-[10px] text-[#92400E] mb-1 font-bold">۱ تا ۳۰ روز</div>
            <div className="text-xs sm:text-sm font-bold text-[#92400E] font-mono">{aging.days30.toLocaleString()}</div>
          </div>
          <div className="bg-[#FEF3C7] p-4 rounded-2xl border border-[#FCD34D]">
            <div className="text-[10px] text-[#92400E] mb-1 font-bold">۳۱ تا ۶۰ روز</div>
            <div className="text-xs sm:text-sm font-bold text-[#92400E] font-mono">{aging.days60.toLocaleString()}</div>
          </div>
          <div className="bg-[#FEF2F2] p-4 rounded-2xl border border-[#FECACA]">
            <div className="text-[10px] text-[#991B1B] mb-1 font-bold">۶۱ تا ۹۰ روز</div>
            <div className="text-xs sm:text-sm font-bold text-[#991B1B] font-mono">{aging.days90.toLocaleString()}</div>
          </div>
          <div className="bg-[#FEE2E2] p-4 rounded-2xl border border-[#FCA5A5] col-span-2 sm:col-span-1">
            <div className="text-[10px] text-[#991B1B] mb-1 font-bold">+۹۰ روز</div>
            <div className="text-xs sm:text-sm font-bold text-[#991B1B] font-mono">{aging.days90Plus.toLocaleString()}</div>
          </div>
        </div>
      </Card>

      <div className="flex items-center gap-4 sm:gap-6 border-b border-border/60 overflow-x-auto">
        <button onClick={() => setLocalTab('overview')} className={`pb-3 text-sm font-bold border-b-[3px] cursor-pointer transition-colors whitespace-nowrap ${activeTab === 'overview' ? 'border-primary text-primary' : 'border-transparent text-text-secondary hover:text-text-main'}`}>نمای کلی</button>
        <button onClick={() => setLocalTab('collection')} className={`pb-3 text-sm font-bold border-b-[3px] cursor-pointer transition-colors whitespace-nowrap flex items-center gap-1.5 ${activeTab === 'collection' ? 'border-primary text-primary' : 'border-transparent text-text-secondary hover:text-text-main'}`}>
          <ShieldAlert size={15} className="text-amber-500" />
          <span>پیگیری هوشمند مطالبات</span>
          {collectionData.summary.highRiskAccountsCount > 0 && (
            <span className="px-1.5 py-0.5 text-[10px] font-black rounded-full bg-red-500 text-white">
              {collectionData.summary.highRiskAccountsCount}
            </span>
          )}
        </button>
        <button onClick={() => setLocalTab('invoices')} className={`pb-3 text-sm font-bold border-b-[3px] cursor-pointer transition-colors whitespace-nowrap ${activeTab === 'invoices' ? 'border-primary text-primary' : 'border-transparent text-text-secondary hover:text-text-main'}`}>فاکتورها ({invoices.length})</button>
        <button onClick={() => setLocalTab('payments')} className={`pb-3 text-sm font-bold border-b-[3px] cursor-pointer transition-colors whitespace-nowrap ${activeTab === 'payments' ? 'border-primary text-primary' : 'border-transparent text-text-secondary hover:text-text-main'}`}>دریافتی‌ها ({payments.length})</button>
        <button onClick={() => setLocalTab('cheques')} className={`pb-3 text-sm font-bold border-b-[3px] cursor-pointer transition-colors whitespace-nowrap ${activeTab === 'cheques' ? 'border-primary text-primary' : 'border-transparent text-text-secondary hover:text-text-main'}`}>چک‌ها ({cheques.length})</button>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5 space-y-3">
              <div className="flex justify-between items-center border-b border-border/60 pb-2">
                <span className="text-xs font-bold text-text-main">آخرین فاکتورهای صادر شده</span>
                <button onClick={() => setLocalTab('invoices')} className="text-[11px] font-bold text-primary hover:underline cursor-pointer">مشاهده همه ({invoices.length})</button>
              </div>
              <div className="space-y-2">
                {invoices.slice(0, 4).map(inv => (
                  <div key={inv.id} className="flex justify-between items-center text-xs py-1.5 border-b border-border/40 last:border-none">
                    <span className="font-mono text-text-main font-bold">{inv.invoiceNumber}</span>
                    <span className="font-mono text-primary font-bold">{inv.totalAmount.toLocaleString()} ریال</span>
                  </div>
                ))}
                {invoices.length === 0 && <div className="text-xs text-text-secondary py-3 text-center">فاکتوری ثبت نشده است.</div>}
              </div>
            </Card>

            <Card padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl p-5 space-y-3">
              <div className="flex justify-between items-center border-b border-border/60 pb-2">
                <span className="text-xs font-bold text-text-main">چک‌های در انتظار وصول</span>
                <button onClick={() => setLocalTab('cheques')} className="text-[11px] font-bold text-primary hover:underline cursor-pointer">مشاهده همه ({cheques.length})</button>
              </div>
              <div className="space-y-2">
                {openCheques.slice(0, 4).map(c => (
                  <div key={c.id} className="flex justify-between items-center text-xs py-1.5 border-b border-border/40 last:border-none">
                    <div>
                      <span className="text-text-main font-bold block">{c.bankName || 'بانک نامشخص'}</span>
                      <span className="text-[10px] text-text-secondary font-mono">{c.chequeNumber || c.id}</span>
                    </div>
                    <div className="text-left font-mono">
                      <span className="text-xs text-[#92400E] font-bold block">{c.amount.toLocaleString()} ریال</span>
                      <span className="text-[10px] text-text-secondary">{c.dueDate || 'بدون تاریخ'}</span>
                    </div>
                  </div>
                ))}
                {openCheques.length === 0 && <div className="text-xs text-text-secondary py-3 text-center">چک در انتظاری وجود ندارد.</div>}
              </div>
            </Card>
          </div>
        </div>
      )}

      {activeTab === 'invoices' && (
        <div className="space-y-3">
          {invoices.map(inv => {
            const acc = (state.accounts || []).find(a => a.id === (inv as any).accountId);
            return (
              <Card key={inv.id} padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl flex justify-between items-center p-5">
                <div>
                  <div className="text-sm font-bold text-text-main font-mono">{inv.invoiceNumber}</div>
                  {acc && <div className="text-xs text-text-secondary mt-0.5">{acc.name}</div>}
                  <div className="text-xs text-text-secondary mt-1 font-mono">سررسید: {formatAppDate(inv.dueDate, state.settings?.locale)}</div>
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold text-text-main font-mono">{inv.totalAmount.toLocaleString()} ریال</div>
                  <div className={`text-xs font-bold mt-1 ${inv.status === 'PAID' ? 'text-[#166534]' : inv.status === 'OVERDUE' ? 'text-[#991B1B]' : 'text-[#92400E]'}`}>
                    {inv.status === 'PAID' ? 'پرداخت شده' : inv.status === 'OVERDUE' ? 'معوق' : 'باز'}
                  </div>
                </div>
              </Card>
            );
          })}
          {invoices.length === 0 && <div className="text-center text-xs text-text-secondary py-12 bg-surface rounded-3xl border border-border/80">فاکتوری یافت نشد.</div>}
        </div>
      )}

      {activeTab === 'payments' && (
        <div className="space-y-3">
          {payments.map(p => {
            const acc = (state.accounts || []).find(a => a.id === p.accountId);
            return (
              <Card key={p.id} padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl flex justify-between items-center p-5">
                <div>
                  <div className="flex items-center gap-2">
                    <strong className="text-sm font-bold text-text-main">
                      {p.method === 'CASH' ? 'پرداخت نقدی' : p.method === 'TRANSFER' ? 'انتقال بانکی (حواله)' : 'چک صیادی'}
                    </strong>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-lg ${p.status === 'CLEARED' ? 'bg-[#F0FDF4] text-[#166534]' : 'bg-amber-50 text-[#92400E]'}`}>
                      {p.status === 'CLEARED' ? 'تسویه و وصول شده' : 'در انتظار وصول'}
                    </span>
                  </div>
                  {acc && <div className="text-xs text-text-secondary mt-1">{acc.name}</div>}
                  {p.reference && <div className="text-[11px] text-text-secondary font-mono mt-0.5">کد رهگیری: {p.reference}</div>}
                  <div className="text-[10px] text-text-secondary font-mono mt-1">تاریخ: {formatAppDate(p.date, state.settings?.locale)}</div>
                </div>
                <div className="text-left font-mono">
                  <span className="text-sm font-bold text-[#166534] block">+{p.amount.toLocaleString()} ریال</span>
                  {p.bankName && <span className="text-[10px] text-text-secondary">{p.bankName}</span>}
                </div>
              </Card>
            );
          })}
          {payments.length === 0 && <div className="text-center text-xs text-text-secondary py-12 bg-surface rounded-3xl border border-border/80">هیچ تراکنش دریافتی ثبت نشده است.</div>}
        </div>
      )}

      {activeTab === 'cheques' && (
        <div className="space-y-3">
          {cheques.map(c => (
            <Card key={c.id} padding="md" className="bg-surface border border-border/80 shadow-subtle rounded-3xl flex justify-between items-center p-5">
              <div>
                <div className="flex items-center gap-2">
                  <strong className="text-sm font-bold text-text-main">{c.bankName || 'بانک مرکزی / صیاد'}</strong>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-lg ${c.status === 'CLEARED' ? 'bg-[#F0FDF4] text-[#166534]' : c.status === 'BOUNCED' ? 'bg-red-50 text-[#991B1B]' : 'bg-amber-50 text-[#92400E]'}`}>
                    {c.status === 'CLEARED' ? 'وصول شد' : c.status === 'BOUNCED' ? 'برگشتی' : 'در جریان'}
                  </span>
                </div>
                <div className="text-xs text-text-secondary font-mono mt-1">شماره صیادی: {c.chequeNumber || c.id}</div>
                <div className="text-[10px] text-text-secondary font-mono mt-0.5">تاریخ سررسید: {formatAppDate(c.dueDate, state.settings?.locale)}</div>
              </div>
              <div className="text-left font-mono">
                <span className="text-sm font-bold text-[#92400E] block">{c.amount.toLocaleString()} ریال</span>
              </div>
            </Card>
          ))}
          {cheques.length === 0 && <div className="text-center text-xs text-text-secondary py-12 bg-surface rounded-3xl border border-border/80">هیچ چکی ثبت نشده است.</div>}
        </div>
      )}

      {activeTab === 'collection' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Summary KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card padding="md" className="bg-red-50/60 border border-red-200 rounded-3xl p-4.5 space-y-1">
              <div className="flex items-center gap-1.5 text-red-700 text-xs font-bold">
                <AlertTriangle size={15} /> کل مطالبات معوق
              </div>
              <div className="text-base sm:text-lg font-black text-red-800 font-mono">
                {collectionData.summary.totalOverdueAmount.toLocaleString('fa-IR')} <span className="text-[11px] font-normal">ریال</span>
              </div>
              <div className="text-[10px] text-red-600 font-bold">
                {collectionData.summary.totalUnpaidInvoicesCount} فاکتور باز پرداخت‌نشده
              </div>
            </Card>

            <Card padding="md" className="bg-rose-50/60 border border-rose-200 rounded-3xl p-4.5 space-y-1">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold">
                <ShieldAlert size={15} /> معوقات بحرانی (&gt;۶۰ روز)
              </div>
              <div className="text-base sm:text-lg font-black text-rose-800 font-mono">
                {collectionData.summary.criticalOverdueAmount.toLocaleString('fa-IR')} <span className="text-[11px] font-normal">ریال</span>
              </div>
              <div className="text-[10px] text-rose-600 font-bold">
                ریسک بالای سوخت مطالبات
              </div>
            </Card>

            <Card padding="md" className="bg-amber-50/60 border border-amber-200 rounded-3xl p-4.5 space-y-1">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold">
                <ShieldCheck size={15} /> مشتریان پرریسک
              </div>
              <div className="text-base sm:text-lg font-black text-amber-800 font-mono">
                {collectionData.summary.highRiskAccountsCount} <span className="text-[11px] font-normal">مشتری</span>
              </div>
              <div className="text-[10px] text-amber-600 font-bold">
                قفل خودکار اعتبار و لزوم تأیید
              </div>
            </Card>

            <Card padding="md" className="bg-emerald-50/60 border border-emerald-200 rounded-3xl p-4.5 space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold">
                <CalendarCheck size={15} /> وعده‌های وصولی امروز
              </div>
              <div className="text-base sm:text-lg font-black text-emerald-800 font-mono">
                {collectionData.summary.todayPromisesCount} <span className="text-[11px] font-normal">فقره</span>
              </div>
              <div className="text-[10px] text-emerald-600 font-bold">
                پیگیری و ثبت اسناد واریز
              </div>
            </Card>
          </div>

          {/* Customer Risk & Collection List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1">
              <h3 className="text-xs font-black text-text-main flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-primary" />
                <span>رتبه‌بندی ریسک مشتریان و فهرست مطالبات سررسیدشده</span>
              </h3>
              <span className="text-[11px] text-text-secondary">
                موتور هوشمند وصول: مرتب‌سازی بر اساس امتیاز ریسک و روزهای تأخیر
              </span>
            </div>

            {collectionData.profiles.map(p => {
              const riskColor = 
                p.riskLevel === 'CRITICAL' ? 'bg-red-500 text-white' :
                p.riskLevel === 'HIGH' ? 'bg-amber-500 text-white' :
                p.riskLevel === 'MEDIUM' ? 'bg-blue-500 text-white' :
                'bg-emerald-500 text-white';

              const riskBadgeLabel =
                p.riskLevel === 'CRITICAL' ? 'بحرانی' :
                p.riskLevel === 'HIGH' ? 'پرریسک' :
                p.riskLevel === 'MEDIUM' ? 'ریسک متوسط' :
                'کم‌ریسک';

              return (
                <Card 
                  key={p.accountId}
                  padding="md"
                  className={`bg-surface border rounded-3xl p-5 transition-all hover:shadow-subtle ${
                    p.riskLevel === 'CRITICAL' ? 'border-red-300 bg-red-50/10' :
                    p.riskLevel === 'HIGH' ? 'border-amber-300 bg-amber-50/10' :
                    'border-border/80'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-black text-text-main">{p.accountName}</span>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${riskColor}`}>
                          امتیاز ریسک {p.riskScore}٪ ({riskBadgeLabel})
                        </span>
                        {p.bouncedChequesCount > 0 && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                            {p.bouncedChequesCount} چک برگشتی
                          </span>
                        )}
                        {p.maxDaysOverdue > 0 && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                            {p.maxDaysOverdue} روز حداکثر تأخیر
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-text-secondary flex items-center gap-4 flex-wrap">
                        <span>مانده معوق: <strong className="text-red-700 font-mono">{p.overdueBalance.toLocaleString('fa-IR')} ریال</strong></span>
                        <span>سقف اعتبار مصوب: <strong className="font-mono text-text-main">{p.creditLimit.toLocaleString('fa-IR')} ریال</strong></span>
                        <span>تلفن تماس: <strong className="font-mono text-text-main" dir="ltr">{p.phone || '-'}</strong></span>
                      </div>

                      <div className="text-[11px] text-primary bg-primary/5 px-3 py-1.5 rounded-xl border border-primary/10 inline-block font-medium">
                        اقدام پیشنهادی سیستم: {p.recommendedAction}
                      </div>

                      {p.activePromises.length > 0 && (
                        <div className="text-[11px] text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                          وعده پرداخت فعال: {p.activePromises[0].promisedAmount.toLocaleString('fa-IR')} ریال در تاریخ {formatAppDate(p.activePromises[0].promisedDate, state.settings?.locale)} ({p.activePromises[0].contactPerson})
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-start lg:self-center">
                      <button
                        onClick={() => {
                          setSelectedProfileForPromise(p);
                          setShowPromiseModal(true);
                        }}
                        className="px-3.5 py-2 bg-primary hover:bg-primary-dark text-white text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
                      >
                        <CalendarCheck size={14} /> ثبت تعهد پرداخت (فرم پویا)
                      </button>
                      <button
                        onClick={() => {
                          setSelectedProfileForTask(p);
                          setAutoTaskNote(`پیگیری فوری معوقات ${p.overdueBalance.toLocaleString('fa-IR')} ریال و توافق نحوه تسویه.`);
                          setShowAutoTaskModal(true);
                        }}
                        className="px-3.5 py-2 bg-canvas border border-border text-text-main hover:bg-surface text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <PhoneCall size={14} /> وظیفه پیگیری تقویم
                      </button>
                    </div>
                  </div>
                </Card>
              );
            })}

            {collectionData.profiles.length === 0 && (
              <div className="text-center text-xs text-text-secondary py-12 bg-surface rounded-3xl border border-border/80">
                هیچ حساب یا مطالبات معوقی در سیستم ثبت نشده است.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: New Payment */}
      {showPaymentModal && (
        <Modal 
          isOpen={showPaymentModal} 
          onClose={() => setShowPaymentModal(false)} 
          title="ثبت دریافتی و تسویه حساب" 
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setShowPaymentModal(false)}>انصراف</Button>
              <Button variant="primary" size="sm" onClick={handleCreatePayment}>ثبت پرداخت</Button>
            </>
          }
        >
          <div className="space-y-4 text-xs" dir="rtl">
            <div>
              <label className="block font-bold mb-1 text-text-main">حساب تجاری طرف معامله *</label>
              <select 
                value={payAccountId} 
                onChange={e => setPayAccountId(e.target.value)} 
                className="w-full bg-canvas border border-border/80 p-2.5 rounded-xl font-bold outline-none"
              >
                <option value="">انتخاب حساب مشتری...</option>
                {(state.accounts || []).map(a => <option key={a.id} value={a.id}>{a.name} ({a.code || a.phone || '-'})</option>)}
              </select>
            </div>
            <div>
              <label className="block font-bold mb-1 text-text-main">مبلغ دریافتی (ریال) *</label>
              <Input 
                value={payAmount} 
                onChange={e => setPayAmount(e.target.value)} 
                placeholder="50000000" 
                dir="ltr" 
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold mb-1 text-text-main">روش دریافت:</label>
                <select 
                  value={payMethod} 
                  onChange={e => setPayMethod(e.target.value as any)} 
                  className="w-full bg-canvas border border-border/80 p-2.5 rounded-xl font-bold outline-none"
                >
                  <option value="TRANSFER">حواله پایا / ساتنا</option>
                  <option value="CASH">نقدی / کارتخوان POS</option>
                  <option value="CHEQUE">چک صیادی</option>
                </select>
              </div>
              <Input 
                label="نام بانک یا درگاه" 
                value={payBank} 
                onChange={e => setPayBank(e.target.value)} 
                placeholder="بانک ملت" 
              />
            </div>
            <Input 
              label="کد رهگیری فیش یا سند واریز" 
              value={payRef} 
              onChange={e => setPayRef(e.target.value)} 
              placeholder="مثال: 94810294" 
              dir="ltr" 
            />
          </div>
        </Modal>
      )}

      {/* Modal: New Invoice */}
      {showInvoiceModal && (
        <Modal 
          isOpen={showInvoiceModal} 
          onClose={() => setShowInvoiceModal(false)} 
          title="صدور فاکتور فروش رسمی" 
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setShowInvoiceModal(false)}>انصراف</Button>
              <Button variant="primary" size="sm" onClick={handleCreateInvoice}>صدور و ثبت فاکتور</Button>
            </>
          }
        >
          <div className="space-y-4 text-xs" dir="rtl">
            {/* Source Mode Toggle */}
            <div className="p-1 bg-canvas rounded-xl border border-border/80 grid grid-cols-2 gap-1 text-center">
              <button
                type="button"
                onClick={() => setInvSource('FROM_QUOTE')}
                className={`py-2 rounded-lg font-bold transition-all cursor-pointer ${
                  invSource === 'FROM_QUOTE' ? 'bg-primary text-white shadow-xs' : 'text-text-secondary hover:text-text-main'
                }`}
              >
                تبدیل از پیش‌فاکتور (پیشنهادی)
              </button>
              <button
                type="button"
                onClick={() => setInvSource('MANUAL')}
                className={`py-2 rounded-lg font-bold transition-all cursor-pointer ${
                  invSource === 'MANUAL' ? 'bg-primary text-white shadow-xs' : 'text-text-secondary hover:text-text-main'
                }`}
              >
                صدور مستقیم و دستی
              </button>
            </div>

            {invSource === 'FROM_QUOTE' && (
              <div className="p-3 bg-primary/5 rounded-2xl border border-primary/20 space-y-2">
                <label className="block font-bold text-text-main">انتخاب پیش‌فاکتور مرجع جهت تبدیل به فاکتور رسمی:</label>
                <select 
                  value={invSelectedQuoteId} 
                  onChange={e => {
                    const qId = e.target.value;
                    setInvSelectedQuoteId(qId);
                    const q = state.quotes?.find(item => item.id === qId);
                    if (q) {
                      setInvAccountId(q.accountId || '');
                      setInvAmount(String(q.totalAmount));
                      setInvNumber(`INV-${q.quoteNumber.replace('QT-', '')}`);
                      setInvDescription(`اقلام رسمی پیش‌فاکتور ${q.quoteNumber} (${q.lines?.length || 0} ردیف کالا)`);
                    }
                  }} 
                  className="w-full bg-white border border-border/80 p-2.5 rounded-xl font-bold outline-none cursor-pointer"
                >
                  <option value="">انتخاب پیش‌فاکتور...</option>
                  {(state.quotes || []).map(q => {
                    const acc = state.accounts?.find(a => a.id === q.accountId);
                    return (
                      <option key={q.id} value={q.id}>
                        {q.quoteNumber} | {acc?.name || 'مشتری نامشخص'} | {q.totalAmount.toLocaleString()} ریال ({q.status === 'ACCEPTED' ? 'تایید مشتری' : q.status === 'APPROVED' ? 'تایید مدیریت' : q.status})
                      </option>
                    );
                  })}
                </select>
                <span className="text-[11px] text-text-secondary block">
                  با انتخاب پیش‌فاکتور، اقلام و مبالغ مستقیماً به سند قطعی مالی منتقل شده و بدهی حساب مشتری ثبت می‌شود.
                </span>
              </div>
            )}

            <div>
              <label className="block font-bold mb-1 text-text-main">حساب خریدار *</label>
              <select 
                value={invAccountId} 
                onChange={e => setInvAccountId(e.target.value)} 
                className="w-full bg-canvas border border-border/80 p-2.5 rounded-xl font-bold outline-none cursor-pointer"
              >
                <option value="">انتخاب حساب خریدار...</option>
                {(state.accounts || []).map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Input 
                label="شماره فاکتور (اختیاری)" 
                value={invNumber} 
                onChange={e => setInvNumber(e.target.value)} 
                placeholder="خودکار یا مثال: INV-1403-12" 
                dir="ltr" 
              />
              <Input 
                label="مبلغ کل فاکتور (ریال) *" 
                value={invAmount} 
                onChange={e => setInvAmount(e.target.value)} 
                placeholder="120000000" 
                dir="ltr" 
              />
            </div>

            <Input 
              label="شرح یا عنوان فاکتور" 
              value={invDescription} 
              onChange={e => setInvDescription(e.target.value)} 
              placeholder="مثال: فاکتور قطعی سفارش لوازم خانگی و تجهیزات" 
            />

            <div>
              <label className="block font-bold mb-1 text-text-main">تاریخ سررسید پرداخت (تقویم شمسی):</label>
              <CustomDatePicker 
                value={invDueDate} 
                onChange={setInvDueDate} 
                calendarType={state.settings?.locale?.calendar === 'gregorian' ? 'gregorian' : 'jalali'}
              />
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: New Cheque */}
      {showChequeModal && (
        <Modal 
          isOpen={showChequeModal} 
          onClose={() => setShowChequeModal(false)} 
          title="ثبت چک صیادی دریافتی" 
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setShowChequeModal(false)}>انصراف</Button>
              <Button variant="primary" size="sm" onClick={handleCreateCheque}>ثبت چک در سامانه</Button>
            </>
          }
        >
          <div className="space-y-4 text-xs" dir="rtl">
            <div>
              <label className="block font-bold mb-1 text-text-main">صاحب حساب / مشتری *</label>
              <select 
                value={chqAccountId} 
                onChange={e => setChqAccountId(e.target.value)} 
                className="w-full bg-canvas border border-border/80 p-2.5 rounded-xl font-bold outline-none cursor-pointer"
              >
                <option value="">انتخاب حساب مشتری...</option>
                {(state.accounts || []).map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input 
                label="شناسه ۱۶ رقمی صیاد *" 
                value={chqNumber} 
                onChange={e => setChqNumber(e.target.value)} 
                placeholder="7829103847561928" 
                dir="ltr" 
              />
              <Input 
                label="مبلغ چک (ریال) *" 
                value={chqAmount} 
                onChange={e => setChqAmount(e.target.value)} 
                placeholder="80000000" 
                dir="ltr" 
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input 
                label="نام بانک و شعبه" 
                value={chqBank} 
                onChange={e => setChqBank(e.target.value)} 
                placeholder="بانک صادرات - شعبه بازار" 
              />
              <div>
                <label className="block font-bold mb-1 text-text-main">تاریخ سررسید چک (تقویم شمسی):</label>
                <CustomDatePicker 
                  value={chqDueDate} 
                  onChange={setChqDueDate} 
                  calendarType={state.settings?.locale?.calendar === 'gregorian' ? 'gregorian' : 'jalali'}
                />
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: Record Promise to Pay with Dynamic Form Engine */}
      {showPromiseModal && selectedProfileForPromise && (
        <Modal 
          isOpen={showPromiseModal} 
          onClose={() => { setShowPromiseModal(false); setSelectedProfileForPromise(null); }} 
          title={`ثبت تعهد و وعده پرداخت: ${selectedProfileForPromise.accountName}`}
        >
          <DynamicFormRenderer
            schema={COLLECTION_PROMISE_SCHEMA}
            initialValues={{
              promisedAmount: selectedProfileForPromise.overdueBalance || 50000000,
              promisedDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
              paymentMethod: 'TRANSFER',
              autoGenerateCalendarTask: true,
              contactPerson: selectedProfileForPromise.accountName
            }}
            onSubmit={handleSavePromise}
            onCancel={() => { setShowPromiseModal(false); setSelectedProfileForPromise(null); }}
            submitLabel="ثبت تعهد و تنظیم وظیفه تقویم"
          />
        </Modal>
      )}

      {/* Modal: Generate Collection Task */}
      {showAutoTaskModal && selectedProfileForTask && (
        <Modal 
          isOpen={showAutoTaskModal} 
          onClose={() => { setShowAutoTaskModal(false); setSelectedProfileForTask(null); }} 
          title={`تنظیم وظیفه پیگیری وصول: ${selectedProfileForTask.accountName}`}
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => { setShowAutoTaskModal(false); setSelectedProfileForTask(null); }}>انصراف</Button>
              <Button variant="primary" size="sm" onClick={handleGenerateManualTask}>ثبت در تقویم و کارتابل</Button>
            </>
          }
        >
          <div className="space-y-4 text-xs" dir="rtl">
            <div className="p-3 bg-red-50 rounded-2xl border border-red-200 text-red-800 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldAlert size={15} />
                <span>مشتری: {selectedProfileForTask.accountName} (سطح ریسک: {selectedProfileForTask.riskLevel})</span>
              </div>
              <div className="text-[11px]">
                مانده معوق: <strong>{selectedProfileForTask.overdueBalance.toLocaleString('fa-IR')} ریال</strong> | حداکثر تأخیر: <strong>{selectedProfileForTask.maxDaysOverdue} روز</strong>
              </div>
            </div>

            <div>
              <label className="block font-bold mb-1 text-text-main">تاریخ موعد پیگیری در تقویم شمسی *</label>
              <CustomDatePicker 
                value={autoTaskDueDate} 
                onChange={setAutoTaskDueDate} 
                calendarType={state.settings?.locale?.calendar === 'gregorian' ? 'gregorian' : 'jalali'}
              />
            </div>

            <Input 
              label="یادداشت و هدف مذاکره کارشناس مالی" 
              value={autoTaskNote} 
              onChange={e => setAutoTaskNote(e.target.value)} 
              placeholder="مثال: تماس با مدیر مالی جهت استعلام وضعیت واریز فاکتورهای معوق" 
            />
          </div>
        </Modal>
      )}
    </div>
  );
}
