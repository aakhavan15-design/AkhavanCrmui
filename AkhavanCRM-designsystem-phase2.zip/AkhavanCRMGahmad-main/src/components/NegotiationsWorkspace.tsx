import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState, Opportunity, OpportunityStage, ID } from '../types';
import { TrendingUp, Plus, Calendar, Building2 } from 'lucide-react';
import { formatCurrency, generateId, parsePersianNumber, formatInputCurrency, cleanNumericInput, formatAppDate } from '../lib/utils';
import { emitBusinessEvent } from '../lib/events';
import { Card } from './ui/Card';
import { FilterChip } from './ui/Tabs';
import { EmptyState } from './ui/EmptyState';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';
import { Button } from './ui/Button';
import { CustomDatePicker } from './ui/CustomDatePicker';
import { SearchableSelect } from './ui/SearchableSelect';

export function NegotiationsWorkspace({ state, updateState }: { state: AppState; updateState: (updater: (draft: AppState) => AppState | void) => void; setActiveTab?: (tab: any) => void; }) {
  const navigate = useNavigate();
  const [activeStage, setActiveStage] = useState<string>('ALL');
  const [showNewModal, setShowNewModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newAccountId, setNewAccountId] = useState(state.activeContextAccountId || state.accounts[0]?.id || '');
  const [newStage, setNewStage] = useState<OpportunityStage>('DISCOVERY');
  const [newCloseDate, setNewCloseDate] = useState(new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]);
  const [errorMsg, setErrorMsg] = useState('');

  const opportunities = state.opportunities || [];

  const stages: { id: string; label: string; color: string }[] = [
    { id: 'ALL', label: 'همه فرصت‌ها', color: 'bg-canvas text-text-secondary' },
    { id: 'DISCOVERY', label: 'شناسایی (Discovery)', color: 'bg-sky-50 text-[#075985]' },
    { id: 'PROPOSAL', label: 'پروپوزال (Proposal)', color: 'bg-primary/10 text-primary' },
    { id: 'NEGOTIATION', label: 'مذاکره (Negotiation)', color: 'bg-amber-50 text-[#92400E]' },
    { id: 'WON', label: 'موفق (Won)', color: 'bg-[#F0FDF4] text-[#166534]' },
    { id: 'LOST', label: 'از دست رفته (Lost)', color: 'bg-red-50 text-[#991B1B]' },
  ];

  const filtered = useMemo(() => {
    if (activeStage === 'ALL') return opportunities;
    return opportunities.filter(o => o.stage === activeStage);
  }, [opportunities, activeStage]);

  const totalValue = filtered.reduce((sum, o) => sum + (o.amount || 0), 0);

  const handleCreateOpportunity = () => {
    setErrorMsg('');
    if (!newTitle.trim() || !newAccountId) {
      setErrorMsg('لطفاً عنوان فرصت و حساب تجاری مربوطه را مشخص نمایید.');
      return;
    }
    const newOpp: Opportunity = {
      id: generateId(),
      accountId: newAccountId,
      title: newTitle.trim(),
      amount: parsePersianNumber(newValue),
      stage: newStage,
      expectedCloseDate: newCloseDate,
      ownerId: state.currentUserId || 'usr_sales',
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.opportunities) draft.opportunities = [];
      draft.opportunities.unshift(newOpp);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'OPPORTUNITY_CREATED',
        entityType: 'OPPORTUNITY',
        entityId: newOpp.id,
        details: `فرصت تجاری جدید "${newOpp.title}" با ارزش ${newOpp.amount.toLocaleString()} ریال ثبت شد`,
        actor: state.users.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    emitBusinessEvent('OPPORTUNITY_CREATED', 'OPPORTUNITY', newOpp.id, newOpp, state, updateState);

    setNewTitle('');
    setNewValue('');
    setShowNewModal(false);
  };

  const handleUpdateStage = (oppId: ID, stage: OpportunityStage) => {
    updateState(draft => {
      const opp = (draft.opportunities || []).find((o: any) => o.id === oppId);
      if (opp) opp.stage = stage;
    });
  };

  const accountOptions = state.accounts.map(a => ({ value: a.id, label: a.name, subLabel: a.code }));

  return (
    <div className="flex-1 flex flex-col bg-canvas" dir="rtl">
      <div className="shrink-0 bg-canvas px-4 pt-4 pb-2 space-y-4 z-10">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-extrabold text-text-main tracking-tight flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" /> پایپ‌لاین فرصت‌های تجاری
            </h2>
            <span className="text-xs text-text-secondary">
              ارزش کل فیلتر جاری: <strong className="font-mono text-primary font-bold">{formatCurrency(totalValue)} ریال</strong>
            </span>
          </div>
          <Button variant="primary" onClick={() => setShowNewModal(true)} icon={<Plus className="w-4 h-4" />}>
            فرصت جدید
          </Button>
        </div>
        
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {stages.map(s => (
            <FilterChip 
              key={s.id} 
              label={s.label} 
              active={activeStage === s.id} 
              onClick={() => setActiveStage(s.id)} 
            />
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24 space-y-3 pt-2">
        {filtered.length > 0 ? (
          filtered.map(opp => {
            const acc = state.accounts?.find(a => a.id === opp.accountId);
            const stageDef = stages.find(s => s.id === opp.stage);
            return (
              <Card key={opp.id} padding="md" className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:shadow-md transition-shadow bg-white border-[#E2E8F0]">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="text-sm font-bold text-text-main">{opp.title}</strong>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${stageDef?.color}`}>
                      {stageDef?.label || opp.stage}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-text-secondary pt-1">
                    <button 
                      onClick={() => navigate(`/accounts/${opp.accountId}`)}
                      className="flex items-center gap-1 font-medium text-text-main hover:text-primary transition-colors cursor-pointer"
                    >
                      <Building2 size={12} className="text-text-secondary" /> {acc?.name || 'حساب نامشخص'}
                    </button>
                    {opp.expectedCloseDate && (
                      <span className="flex items-center gap-1 font-mono text-[11px] text-text-secondary">
                        <Calendar size={12} /> تاریخ هدف: {formatAppDate(opp.expectedCloseDate, state.settings?.locale)}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 self-end sm:self-center">
                  <div className="text-left font-mono">
                    <span className="text-[10px] text-text-secondary block">ارزش برآوردی</span>
                    <strong className="text-sm font-bold text-primary">{formatCurrency(opp.amount)} ریال</strong>
                  </div>

                  <div className="flex gap-1">
                    {opp.stage !== 'WON' && opp.stage !== 'LOST' && (
                      <>
                        <button 
                          onClick={() => handleUpdateStage(opp.id, 'WON')}
                          className="px-2 py-1 text-xs font-bold rounded-lg bg-[#F0FDF4] text-[#166534] hover:bg-[#DCFCE7] transition-colors cursor-pointer border border-[#BBF7D0]"
                          title="ثبت به عنوان برنده (Won)"
                        >
                          برنده (Won)
                        </button>
                        <button 
                          onClick={() => handleUpdateStage(opp.id, 'LOST')}
                          className="px-2 py-1 text-xs font-bold rounded-lg bg-red-50 text-[#991B1B] hover:bg-red-100 transition-colors cursor-pointer border border-red-200"
                          title="ثبت به عنوان از دست رفته (Lost)"
                        >
                          باخت (Lost)
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </Card>
            );
          })
        ) : (
          <EmptyState 
            icon={<TrendingUp className="w-8 h-8 text-text-secondary opacity-50" />} 
            title="فرصتی یافت نشد" 
            description="فرصت تجاری جدید برای پیشبرد مذاکرات تعریف کنید." 
            actionLabel="ثبت فرصت جدید"
            onAction={() => setShowNewModal(true)}
          />
        )}
      </div>

      <Modal
        isOpen={showNewModal}
        onClose={() => setShowNewModal(false)}
        title="ثبت فرصت تجاری جدید (New Opportunity)"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setShowNewModal(false)}>انصراف</Button>
            <Button variant="primary" size="sm" onClick={handleCreateOpportunity}>ثبت فرصت</Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          {errorMsg && <div className="bg-red-50 border border-red-200 text-[#991B1B] px-3 py-2 rounded-lg font-bold">{errorMsg}</div>}
          
          <Input
            label="عنوان فرصت / پروژه"
            placeholder="مثال: قرارداد تامین اقلام فصلی زمستان"
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            required
          />

          <SearchableSelect 
            label="حساب تجاری مربوطه (Account)"
            options={accountOptions}
            value={newAccountId}
            onChange={setNewAccountId}
            required
          />

          <div className="grid grid-cols-2 gap-3">
            <Input
              label="ارزش تخمینی معامله (ریال)"
              placeholder="مثال: 150,000,000"
              value={formatInputCurrency(newValue)}
              onChange={e => setNewValue(cleanNumericInput(e.target.value))}
              dir="ltr"
            />
            <div>
              <label className="block font-bold text-text-main mb-1">تاریخ هدف بستن قرارداد</label>
              <CustomDatePicker value={newCloseDate} onChange={d => setNewCloseDate(d)} />
            </div>
          </div>

          <div>
            <label className="block font-bold text-text-main mb-1">مرحله اولیه در قیف فروش</label>
            <select 
              value={newStage} 
              onChange={e => setNewStage(e.target.value as OpportunityStage)}
              className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 font-medium outline-none focus:border-primary"
            >
              <option value="DISCOVERY">شناسایی و ارزیابی نیاز (Discovery)</option>
              <option value="PROPOSAL">ارائه پیشنهاد و پیش‌فاکتور (Proposal)</option>
              <option value="NEGOTIATION">مذاکره نهایی شرایط (Negotiation)</option>
            </select>
          </div>
        </div>
      </Modal>
    </div>
  );
}
