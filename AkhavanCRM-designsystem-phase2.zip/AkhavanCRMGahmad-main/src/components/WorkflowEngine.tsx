import { useEffect } from 'react';
import { AppState } from '../types';
import { generateId } from '../lib/utils';

export function WorkflowEngine({ state, updateState }: { state: AppState, updateState: any }) {
  useEffect(() => {
    const interval = setInterval(() => {
      let hasChanges = false;
      const today = new Date().toISOString().split('T')[0];
      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

      const tasks = state.tasks || [];
      const quotes = state.quotes || [];
      const notifications = state.notifications || [];

      const taskUpdated = tasks.some(t => {
        if (t.status === 'COMPLETED') return false;
        let calculatedSla: 'ON_TRACK' | 'AT_RISK' | 'BREACHED' = 'ON_TRACK';
        if (t.dueDate && t.dueDate < today) {
          calculatedSla = 'BREACHED';
        } else if (t.dueDate && (t.dueDate === today || t.dueDate <= tomorrow)) {
          calculatedSla = 'AT_RISK';
        }
        return t.slaStatus !== calculatedSla;
      });

      const threshold = 100000000;
      const highValueQuotePending = quotes.some(q => 
        q.totalAmount > threshold && 
        q.status === 'DRAFT' && 
        !notifications.some(n => n.title?.includes(q.quoteNumber))
      );

      if (taskUpdated || highValueQuotePending) {
        updateState((draft: AppState) => {
          let stateChanged = false;

          if (!draft.notifications) draft.notifications = [];
          if (!draft.tasks) draft.tasks = [];

          draft.tasks.filter(t => t.status !== 'COMPLETED').forEach(task => {
            let calculatedSla: 'ON_TRACK' | 'AT_RISK' | 'BREACHED' = 'ON_TRACK';
            if (task.dueDate && task.dueDate < today) {
              calculatedSla = 'BREACHED';
            } else if (task.dueDate && (task.dueDate === today || task.dueDate <= tomorrow)) {
              calculatedSla = 'AT_RISK';
            }
            if (task.slaStatus !== calculatedSla) {
              task.slaStatus = calculatedSla;
              stateChanged = true;
            }
          });

          (draft.quotes || []).filter(q => q.totalAmount > threshold && q.status === 'DRAFT').forEach(quote => {
            const alreadyNotified = draft.notifications!.some(n => n.title?.includes(quote.quoteNumber));
            if (!alreadyNotified) {
              draft.notifications!.push({
                id: generateId(),
                title: `پیش‌فاکتور با ارزش بالا (${quote.quoteNumber})`,
                message: `پیش‌فاکتور جدید به ارزش ${new Intl.NumberFormat('fa-IR').format(quote.totalAmount)} ریال ثبت شده است.`,
                type: 'INFO',
                read: false,
                createdAt: new Date().toISOString(),
                linkTab: 'quotes'
              });
              stateChanged = true;
            }
          });

          if (!stateChanged) return false;
        });
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [updateState, state.tasks, state.quotes, state.notifications]);

  return null;
}
