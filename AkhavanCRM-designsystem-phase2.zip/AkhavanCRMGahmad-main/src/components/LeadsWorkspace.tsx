import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState, Lead, LeadStage, ID, Account } from '../types';
import { generateId, matchesSearch } from '../lib/utils';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';
import { FilterChip } from './ui/Tabs';
import { EmptyState } from './ui/EmptyState';
import { UserCheck, Plus, Search, Phone, CheckCircle2, Clock } from 'lucide-react';

interface LeadsWorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
  setActiveTab?: (tab: any) => void;
}

export function LeadsWorkspace({ state, updateState }: LeadsWorkspaceProps) {
  const navigate = useNavigate();
  const [activeStage, setActiveStage] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewLeadOpen, setIsNewLeadOpen] = useState(false);
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const stages: { id: string; label: string; color: string }[] = [
    { id: 'ALL', label: 'همه سرنخ‌ها', color: 'bg-canvas text-text-secondary' },
    { id: 'NEW', label: 'جدید (NEW)', color: 'bg-sky-50 text-[#075985]' },
    { id: 'CONTACTED', label: 'تماس اولیه (CONTACTED)', color: 'bg-primary/10 text-primary' },
    { id: 'QUALIFIED', label: 'واجد شرایط (QUALIFIED)', color: 'bg-amber-50 text-[#92400E]' },
    { id: 'CONVERTED', label: 'تبدیل به مشتری (CONVERTED)', color: 'bg-[#F0FDF4] text-[#166534]' },
    { id: 'LOST', label: 'از دست رفته (LOST)', color: 'bg-red-50 text-[#991B1B]' },
  ];

  const filteredLeads = useMemo(() => {
    let list = state.leads || [];
    if (activeStage !== 'ALL') {
      list = list.filter((l: any) => l.stage === activeStage);
    }
    if (searchQuery.trim()) {
      list = list.filter((l: any) => 
        matchesSearch(l.companyName, searchQuery) || 
        matchesSearch(l.contactName, searchQuery) || 
        matchesSearch(l.phone, searchQuery)
      );
    }
    return list;
  }, [state.leads, activeStage, searchQuery]);

  const handleCreateLead = () => {
    setErrorMsg('');
    if (!companyName.trim() || !contactName.trim()) {
      setErrorMsg('لطفاً نام شرکت و نام مخاطب را وارد کنید.');
      return;
    }
    const newLead: Lead = {
      id: generateId(),
      companyName: companyName.trim(),
      contactName: contactName.trim(),
      phone: phone.trim(),
      stage: 'NEW',
      ownerId: state.currentUserId || 'usr_sales',
      notes: notes.trim(),
      createdAt: new Date().toISOString()
    };
    updateState(draft => {
      if (!draft.leads) draft.leads = [];
      draft.leads.unshift(newLead);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'LEAD_CREATED',
        entityType: 'LEAD',
        entityId: newLead.id,
        details: `سرنخ جدید برای شرکت ${newLead.companyName} ثبت شد`,
        actor: state.users.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });
    setCompanyName('');
    setContactName('');
    setPhone('');
    setNotes('');
    setIsNewLeadOpen(false);
  };

  const handleUpdateStage = (leadId: ID, nextStage: LeadStage) => {
    updateState(draft => {
      const lead = (draft.leads || []).find((l: any) => l.id === leadId);
      if (lead) {
        lead.stage = nextStage;
      }
    });
  };

  const handleConvertLeadToAccount = (lead: Lead) => {
    const newAccountId = generateId();
    updateState(draft => {
      const newAccount: Account = {
        id: newAccountId,
        name: lead.companyName,
        code: `ACC-${Date.now().toString().slice(-4)}`,
        status: 'ACTIVE',
        phone: lead.phone,
        active: true,
        contacts: [
          {
            id: generateId(),
            accountId: newAccountId,
            name: lead.contactName,
            phone: lead.phone,
            isPrimary: true
          }
        ],
        createdAt: new Date().toISOString()
      };
      if (!draft.accounts) draft.accounts = [];
      draft.accounts.unshift(newAccount);

      const l = (draft.leads || []).find((item: any) => item.id === lead.id);
      if (l) {
        l.stage = 'CONVERTED';
        l.convertedAccountId = newAccountId;
      }

      draft.activeContextAccountId = newAccountId;
      draft.activeContextCustomerId = newAccountId;

      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'LEAD_CONVERTED',
        entityType: 'LEAD',
        entityId: lead.id,
        details: `سرنخ ${lead.companyName} با موفقیت به حساب تجاری تبدیل شد`,
        actor: state.users.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    navigate(`/accounts/${newAccountId}`);
  };

  return (
    <div className="flex-1 flex flex-col bg-canvas" dir="rtl">
      <div className="shrink-0 bg-canvas px-4 pt-4 pb-2 space-y-4 z-10">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-extrabold text-text-main tracking-tight flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-primary" /> مدیریت سرنخ‌های فروش (Leads)
            </h2>
            <span className="text-xs text-text-secondary">پایش، صلاحیت‌سنجی و تبدیل سرنخ‌ها به حساب‌های رسمی</span>
          </div>
          <Button variant="primary" onClick={() => setIsNewLeadOpen(true)} icon={<Plus className="w-4 h-4" />}>
            ثبت سرنخ جدید
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {stages.map(s => (
              <FilterChip 
                key={s.id} 
                label={s.label} 
                active={activeStage === s.id} 
                onClick={() => setActiveStage(s.id)} 
              />
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <input 
              type="text" 
              placeholder="جستجوی شرکت یا مخاطب..." 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full h-[38px] bg-white border border-[#E2E8F0] rounded-[12px] pl-4 pr-10 text-xs font-medium text-text-main placeholder:text-text-secondary outline-none focus:border-primary transition-all shadow-sm"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-text-secondary" size={16} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24 space-y-3 pt-2">
        {filteredLeads.length > 0 ? (
          filteredLeads.map((lead: any) => {
            const stageDef = stages.find(s => s.id === lead.stage);
            return (
              <Card key={lead.id} padding="md" className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:shadow-md transition-shadow border-[#E2E8F0] bg-white">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="text-sm font-bold text-text-main">{lead.companyName}</strong>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${stageDef?.color}`}>
                      {stageDef?.label || lead.stage}
                    </span>
                  </div>
                  <div className="text-xs text-text-secondary flex flex-wrap gap-4 pt-1">
                    <span className="flex items-center gap-1 font-medium text-text-main">
                      مخاطب: {lead.contactName}
                    </span>
                    {lead.phone && (
                      <span className="flex items-center gap-1 font-mono">
                        <Phone size={12} className="text-text-secondary" /> {lead.phone}
                      </span>
                    )}
                    <span className="flex items-center gap-1 font-mono text-[11px] text-text-secondary">
                      <Clock size={12} /> {new Date(lead.createdAt).toLocaleDateString('fa-IR')}
                    </span>
                  </div>
                  {lead.notes && (
                    <p className="text-xs text-text-secondary bg-canvas p-2 rounded-lg mt-2 border border-[#E2E8F0]">
                      یادداشت: {lead.notes}
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
                  {lead.stage === 'NEW' && (
                    <button 
                      onClick={() => handleUpdateStage(lead.id, 'CONTACTED')}
                      className="text-xs font-bold px-3 py-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors cursor-pointer"
                    >
                      ثبت تماس اولیه
                    </button>
                  )}

                  {lead.stage === 'CONTACTED' && (
                    <button 
                      onClick={() => handleUpdateStage(lead.id, 'QUALIFIED')}
                      className="text-xs font-bold px-3 py-1.5 rounded-lg bg-amber-50 text-[#92400E] hover:bg-amber-100 transition-colors cursor-pointer"
                    >
                      تایید صلاحیت (Qualified)
                    </button>
                  )}

                  {lead.stage === 'QUALIFIED' && (
                    <Button 
                      size="sm" 
                      variant="primary" 
                      onClick={() => handleConvertLeadToAccount(lead)}
                      icon={<CheckCircle2 className="w-3.5 h-3.5" />}
                    >
                      تبدیل به حساب رسمی (Account)
                    </Button>
                  )}

                  {lead.stage === 'CONVERTED' && (
                    <span className="text-xs font-bold text-[#166534] bg-[#F0FDF4] px-3 py-1 rounded-lg border border-[#BBF7D0] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> حساب ایجاد شد
                    </span>
                  )}

                  {lead.stage !== 'CONVERTED' && lead.stage !== 'LOST' && (
                    <button 
                      onClick={() => handleUpdateStage(lead.id, 'LOST')}
                      className="text-xs font-semibold px-2 py-1 text-text-secondary hover:text-[#991B1B] rounded transition-colors cursor-pointer"
                      title="لغو / از دست رفته"
                    >
                      انصراف
                    </button>
                  )}
                </div>
              </Card>
            );
          })
        ) : (
          <EmptyState 
            icon={<UserCheck className="w-8 h-8 text-text-secondary opacity-50" />} 
            title="هیچ سرنخی یافت نشد" 
            description="برای شروع روی دکمه ثبت سرنخ جدید کلیک کنید." 
            actionLabel="ثبت سرنخ جدید"
            onAction={() => setIsNewLeadOpen(true)}
          />
        )}
      </div>

      <Modal 
        isOpen={isNewLeadOpen} 
        onClose={() => setIsNewLeadOpen(false)}
        title="ثبت سرنخ بازرگانی جدید (Lead)"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setIsNewLeadOpen(false)}>انصراف</Button>
            <Button variant="primary" size="sm" onClick={handleCreateLead}>ثبت سرنخ</Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          {errorMsg && <div className="bg-red-50 border border-red-200 text-[#991B1B] px-3 py-2 rounded-lg font-bold">{errorMsg}</div>}
          
          <Input 
            label="نام شرکت / فروشگاه" 
            placeholder="مثال: فروشگاه برادران حسینی"
            value={companyName}
            onChange={e => setCompanyName(e.target.value)}
            required
          />
          <Input 
            label="نام شخص مخاطب یا تصمیم‌گیرنده" 
            placeholder="مثال: مهندس حسینی"
            value={contactName}
            onChange={e => setContactName(e.target.value)}
            required
          />
          <Input 
            label="شماره تماس / موبایل" 
            placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
            value={phone}
            onChange={e => setPhone(e.target.value)}
          />
          <div>
            <label className="block font-bold text-text-main mb-1">یادداشت و اطلاعات تکمیلی</label>
            <textarea 
              rows={3}
              placeholder="توضیحات در مورد کانال ورود سرنخ، پتانسیل همکاری یا نیازمندی‌ها..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 font-medium outline-none focus:border-primary"
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
