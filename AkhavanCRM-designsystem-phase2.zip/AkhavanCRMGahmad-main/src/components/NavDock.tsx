import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { menuSections, TOP_TAB_IDS, isActivePath } from '../lib/navigation';

/** Dock عمودی شیشه‌ای (فقط دسکتاپ، سمت راست در RTL): دسترسی مستقیم به همه ماژول‌های خارج از قرص‌های بالا */
export function NavDock() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const groups = menuSections
    .map(s => ({ ...s, items: s.items.filter(i => !TOP_TAB_IDS.includes(i.id)) }))
    .filter(s => s.items.length > 0);

  return (
    <nav aria-label="دسترسی سریع به ماژول‌ها"
      className="glass-strong no-scrollbar fixed end-4 top-1/2 z-30 hidden max-h-[78vh] -translate-y-1/2 flex-col items-center gap-1.5 overflow-y-auto rounded-full p-2 lg:flex">
      {groups.map((g, gi) => (
        <React.Fragment key={g.id}>
          {gi > 0 && <span aria-hidden className="my-1 h-px w-6 bg-text-main/10" />}
          {g.items.map(item => {
            const on = isActivePath(pathname, item.path);
            const Icon = item.icon;
            return (
              <button key={item.id} onClick={() => navigate(item.path)} title={item.label} aria-label={item.label}
                aria-current={on ? 'page' : undefined}
                className={cn(
                  'grid h-11 w-11 shrink-0 cursor-pointer place-items-center rounded-full transition-all duration-200',
                  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent active:scale-95',
                  on ? 'bg-primary text-white shadow-lux' : 'text-text-secondary hover:bg-white hover:text-text-main'
                )}>
                <Icon strokeWidth={on ? 2.3 : 1.75} className="h-5 w-5" />
              </button>
            );
          })}
        </React.Fragment>
      ))}
    </nav>
  );
}
