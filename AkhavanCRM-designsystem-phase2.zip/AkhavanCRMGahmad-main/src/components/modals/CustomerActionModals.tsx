import React, { useState } from 'react';
import { AppState, Account, CustomerTimelineEvent } from '../../types';
import { generateId, formatInputCurrency, parsePersianNumber } from '../../lib/utils';
import { X } from 'lucide-react';
import { SearchableSelect } from '../ui/SearchableSelect';
import { Button } from '../ui/Button';

interface ModalProps {
  customer: Account;
  onClose: () => void;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
}

const ModalOverlay: React.FC<{ children: React.ReactNode, onClose: () => void, title: string }> = ({ children, onClose, title }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-text-main/40 backdrop-blur-sm animate-in fade-in" dir="rtl">
    <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
      <div className="flex justify-between items-center px-4 py-3 border-b border-slate-100 bg-canvas shrink-0">
        <h3 className="font-extrabold text-sm text-text-main">{title}</h3>
        <button onClick={onClose} className="p-1.5 text-text-secondary hover:text-text-main hover:bg-slate-200 rounded-xl transition-colors cursor-pointer">
          <X size={16} />
        </button>
      </div>
      <div className="p-4 overflow-y-auto flex-1">
        {children}
      </div>
    </div>
  </div>
);

export function NewVisitModal({ customer, onClose, updateState }: ModalProps) {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('10:00');
  const [purpose, setPurpose] = useState('');
  
  const handleSave = () => {
    if (!purpose) return;
    
    updateState(draft => {
      const visitId = generateId();
      if (!draft.visits) draft.visits = [];
      draft.visits.push({
        id: visitId,
        accountId: customer.id,
        repId: draft.currentUserId || 'SYSTEM',
        status: 'PLANNED',
        notes: purpose
      });
      
      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'VISIT',
        title: 'ویزیت برنامه‌ریزی شد',
        description: purpose,
        dateTime: new Date().toISOString(),
        relatedEntityId: visitId
      });
      return draft;
    });
    onClose();
  };

  return (
    <ModalOverlay title="ثبت ویزیت جدید" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">تاریخ</label>
          <input 
            type="date" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-medium text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={date} 
            onChange={e => setDate(e.target.value)} 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">ساعت</label>
          <input 
            type="time" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-medium text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={time} 
            onChange={e => setTime(e.target.value)} 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">هدف ویزیت</label>
          <textarea 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary transition-all resize-none" 
            rows={3} 
            value={purpose} 
            onChange={e => setPurpose(e.target.value)} 
            placeholder="دلیل مراجعه و برنامه‌ریزی ویزیت..." 
          />
        </div>
        <Button onClick={handleSave} className="w-full mt-2">ثبت ویزیت</Button>
      </div>
    </ModalOverlay>
  );
}

export function NewCallModal({ customer, onClose, updateState }: ModalProps) {
  const [subject, setSubject] = useState('');
  const [type, setType] = useState<'PHONE'|'WHATSAPP'|'SMS'|'INTERNAL_NOTE'>('PHONE');
  const [outcome, setOutcome] = useState<'ANSWERED' | 'NO_ANSWER' | 'BUSY' | 'CALLBACK' | 'COMPLETED' | 'OTHER'>('ANSWERED');
  const [summary, setSummary] = useState('');
  
  const handleSave = () => {
    if (!subject) return;
    
    updateState(draft => {
      const commId = generateId();
      if (!draft.communications) draft.communications = [];
      draft.communications.push({
        id: commId,
        customerId: customer.id,
        date: new Date().toISOString(),
        type,
        subject,
        summary,
        outcome
      });
      
      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'CALL',
        title: 'تماس: ' + subject,
        description: summary,
        dateTime: new Date().toISOString(),
        relatedEntityId: commId
      });
      return draft;
    });
    onClose();
  };

  return (
    <ModalOverlay title="ثبت تماس / ارتباط" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">نوع ارتباط</label>
          <select 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={type} 
            onChange={e => setType(e.target.value as any)}
          >
            <option value="PHONE">تماس تلفنی</option>
            <option value="WHATSAPP">واتساپ</option>
            <option value="SMS">پیامک</option>
            <option value="INTERNAL_NOTE">یادداشت داخلی</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">موضوع</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={subject} 
            onChange={e => setSubject(e.target.value)} 
            placeholder="موضوع تماس..." 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">نتیجه</label>
          <select 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={outcome} 
            onChange={e => setOutcome(e.target.value as any)}
          >
            <option value="ANSWERED">پاسخ داد</option>
            <option value="NO_ANSWER">عدم پاسخگویی</option>
            <option value="BUSY">مشغول</option>
            <option value="CALLBACK">نیاز به تماس مجدد</option>
            <option value="COMPLETED">تکمیل شده</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">خلاصه مذاکره / یادداشت</label>
          <textarea 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary transition-all resize-none" 
            rows={3} 
            value={summary} 
            onChange={e => setSummary(e.target.value)} 
            placeholder="شرح مکالمه..." 
          />
        </div>
        <Button onClick={handleSave} className="w-full mt-2">ثبت ارتباط</Button>
      </div>
    </ModalOverlay>
  );
}

export function NewTaskModal({ customer, onClose, updateState }: ModalProps) {
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [priority, setPriority] = useState<'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'>('NORMAL');
  const [description, setDescription] = useState('');
  
  const handleSave = () => {
    if (!title) return;
    
    updateState(draft => {
      const taskId = generateId();
      if (!draft.tasks) draft.tasks = [];
      draft.tasks.push({
        id: taskId,
        accountId: customer.id,
        customerId: customer.id,
        title,
        description,
        dueDate,
        priority,
        status: 'OPEN',
        slaStatus: 'ON_TRACK',
        assigneeType: 'USER',
        assigneeId: draft.currentUserId || 'SYSTEM',
        createdAt: new Date().toISOString()
      });
      
      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'TASK_CREATED',
        title: 'تسک جدید: ' + title,
        description: description,
        dateTime: new Date().toISOString(),
        relatedEntityId: taskId
      });
      return draft;
    });
    onClose();
  };

  return (
    <ModalOverlay title="تسک و وظیفه جدید" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">عنوان وظیفه</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={title} 
            onChange={e => setTitle(e.target.value)} 
            placeholder="مثال: پیگیری فاکتور سررسید گذشته" 
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-text-main mb-1">مهلت انجام</label>
            <input 
              type="date" 
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-medium text-text-main outline-none focus:bg-white focus:border-primary" 
              value={dueDate} 
              onChange={e => setDueDate(e.target.value)} 
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-text-main mb-1">اولویت</label>
            <select 
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary" 
              value={priority} 
              onChange={e => setPriority(e.target.value as any)}
            >
              <option value="LOW">کم</option>
              <option value="NORMAL">عادی</option>
              <option value="HIGH">بالا</option>
              <option value="URGENT">فوری</option>
            </select>
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">توضیحات</label>
          <textarea 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary transition-all resize-none" 
            rows={3} 
            value={description} 
            onChange={e => setDescription(e.target.value)} 
            placeholder="شرح کامل کار..." 
          />
        </div>
        <Button onClick={handleSave} className="w-full mt-2">ایجاد تسک</Button>
      </div>
    </ModalOverlay>
  );
}

export function NewActivityModal({ customer, onClose, updateState }: ModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  
  const handleSave = () => {
    if (!title) return;
    
    updateState(draft => {
      const actId = generateId();
      if (!draft.activities) draft.activities = [];
      draft.activities.push({
        id: actId,
        accountId: customer.id,
        type: 'NOTE',
        title,
        description,
        dateTime: new Date().toISOString(),
        ownerId: draft.currentUserId || 'SYSTEM'
      });
      
      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'NOTE',
        title: title,
        description: description,
        dateTime: new Date().toISOString(),
        relatedEntityId: actId
      });
      return draft;
    });
    onClose();
  };

  return (
    <ModalOverlay title="ثبت یادداشت / فعالیت عمومی" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">عنوان</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={title} 
            onChange={e => setTitle(e.target.value)} 
            placeholder="عنوان یادداشت..." 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">توضیحات</label>
          <textarea 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary transition-all resize-none" 
            rows={3} 
            value={description} 
            onChange={e => setDescription(e.target.value)} 
            placeholder="توضیحات تکمیلی..." 
          />
        </div>
        <Button onClick={handleSave} className="w-full mt-2">ثبت یادداشت</Button>
      </div>
    </ModalOverlay>
  );
}

export function NewNegotiationModal({ customer, onClose, updateState }: ModalProps) {
  const [title, setTitle] = useState('');
  const [estimatedValue, setEstimatedValue] = useState('');
  const [expectedCloseDate, setExpectedCloseDate] = useState(new Date().toISOString().split('T')[0]);
  
  const handleSave = () => {
    if (!title) return;
    
    updateState(draft => {
      const negId = generateId();
      if (!draft.opportunities) draft.opportunities = [];
      draft.opportunities.push({
        id: negId,
        accountId: customer.id,
        title,
        createdAt: new Date().toISOString(),
        stage: 'DISCOVERY',
        amount: estimatedValue ? parseInt(estimatedValue.replace(/\D/g, '')) : 0,
        expectedCloseDate
      });
      
      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'NEGOTIATION',
        title: 'فرصت/مذاکره جدید: ' + title,
        dateTime: new Date().toISOString(),
        relatedEntityId: negId
      });
      
      return draft;
    });
    onClose();
  };

  return (
    <ModalOverlay title="ثبت فرصت / مذاکره جدید" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">عنوان / موضوع</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={title} 
            onChange={e => setTitle(e.target.value)} 
            placeholder="مثال: قرارداد تأمین کالا پاییزه..." 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">ارزش تقریبی (ریال)</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={estimatedValue} 
            onChange={e => setEstimatedValue(formatInputCurrency(e.target.value))} 
            dir="ltr" 
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">تاریخ پیش‌بینی نتیجه</label>
          <input 
            type="date" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-medium text-text-main outline-none focus:bg-white focus:border-primary" 
            value={expectedCloseDate} 
            onChange={e => setExpectedCloseDate(e.target.value)} 
          />
        </div>
        <Button onClick={handleSave} className="w-full mt-2">ثبت فرصت</Button>
      </div>
    </ModalOverlay>
  );
}

export function NewPaymentModal({ customer, onClose, updateState, state }: ModalProps & { state?: AppState }) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'CASH' | 'TRANSFER' | 'CHEQUE'>('TRANSFER');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [reference, setReference] = useState('');
  const [chequeDueDate, setChequeDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  const [error, setError] = useState('');

  const openInvoices = ((state?.invoices) || []).filter(i => (i.accountId === customer.id || i.customerId === customer.id) && i.balance > 0);
  const invoiceOptions = openInvoices.map(i => ({
    value: i.id,
    label: `فاکتور ${i.invoiceNumber || i.id}`,
    subLabel: `مانده: ${i.balance.toLocaleString('fa-IR')} ریال`
  }));

  const handleSave = () => {
    setError('');
    const numericAmount = parsePersianNumber(amount);
    if (!numericAmount || isNaN(numericAmount)) {
      setError('مبلغ نامعتبر است.');
      return;
    }

    updateState(draft => {
      const paymentId = generateId();
      
      if (selectedInvoiceId) {
        const invoice = (draft.invoices || []).find(i => i.id === selectedInvoiceId);
        if (!invoice) {
          setError('فاکتور انتخاب شده یافت نشد.');
          return draft;
        }

        if (!draft.paymentAllocations) draft.paymentAllocations = [];
        draft.paymentAllocations.push({
          id: generateId(),
          paymentId: paymentId,
          invoiceId: selectedInvoiceId,
          amount: numericAmount,
          createdAt: new Date().toISOString()
        });

        invoice.paidAmount += numericAmount;
        invoice.balance = Math.max(0, invoice.totalAmount - invoice.paidAmount);
        invoice.status = invoice.balance === 0 ? 'PAID' : 'PARTIAL';
      }

      if (!draft.payments) draft.payments = [];
      draft.payments.push({
        id: paymentId,
        accountId: customer.id,
        customerId: customer.id,
        amount: numericAmount,
        date,
        method,
        reference,
        chequeDueDate: method === 'CHEQUE' ? chequeDueDate : undefined,
        status: method === 'CHEQUE' ? 'PENDING' : 'CLEARED',
        notes
      } as any);

      if (!draft.timelineEvents) draft.timelineEvents = [];
      draft.timelineEvents.push({
        id: generateId(),
        customerId: customer.id,
        type: 'PAYMENT',
        title: `ثبت دریافت وجه / وصولی (${method === 'CHEQUE' ? 'چک صیادی' : method === 'TRANSFER' ? 'حواله بانکی' : 'نقد'})`,
        description: `مبلغ: ${numericAmount.toLocaleString('fa-IR')} ریال ${selectedInvoiceId ? '(تخصیص یافته به فاکتور)' : ''}`,
        dateTime: new Date().toISOString(),
        relatedEntityId: paymentId
      });

      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'PAYMENT_RECORDED',
        entityType: 'PAYMENT',
        entityId: paymentId,
        details: `ثبت وصولی به مبلغ ${numericAmount} ریال برای مشتری ${customer.name}`,
        actor: draft.users?.find(u => u.id === draft.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });

      return draft;
    });

    if (!error) onClose();
  };

  return (
    <ModalOverlay title="ثبت دریافت وجه و وصولی" onClose={onClose}>
      <div className="space-y-4 text-xs">
        {error && <div className="text-[#991B1B] bg-[#FEF2F2] p-2 rounded-lg font-bold border border-[#FECACA]">{error}</div>}
        
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">مبلغ دریافتی (ریال) *</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-sm font-bold font-mono text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={amount} 
            onChange={e => setAmount(formatInputCurrency(e.target.value))} 
            placeholder="مبلغ به ریال"
            dir="ltr"
            autoFocus
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">روش پرداخت</label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'TRANSFER' as const, label: 'حواله بانکی' },
              { id: 'CHEQUE' as const, label: 'چک صیادی' },
              { id: 'CASH' as const, label: 'وجه نقد' },
            ].map(m => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                  method === m.id 
                    ? 'bg-primary/10 text-primary border-primary/30 shadow-sm' 
                    : 'bg-white border-slate-200 text-text-secondary hover:bg-canvas'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        <SearchableSelect 
          label="تخصیص به فاکتور باز (اختیاری)"
          options={invoiceOptions}
          value={selectedInvoiceId}
          onChange={setSelectedInvoiceId}
          placeholder="انتخاب فاکتور جهت کسر از بدهی..."
        />

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">تاریخ دریافت</label>
          <input 
            type="date" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary" 
            value={date} 
            onChange={e => setDate(e.target.value)} 
          />
        </div>

        {method === 'CHEQUE' && (
          <>
            <div>
              <label className="block text-xs font-bold text-text-main mb-1">تاریخ سررسید چک</label>
              <input 
                type="date" 
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary" 
                value={chequeDueDate} 
                onChange={e => setChequeDueDate(e.target.value)} 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-text-main mb-1">شماره صیادی / شماره چک</label>
              <input 
                type="text" 
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono text-text-main outline-none focus:bg-white focus:border-primary" 
                value={reference} 
                onChange={e => setReference(e.target.value)} 
                placeholder="شماره صیادی ۱۶ رقمی"
                dir="ltr"
              />
            </div>
          </>
        )}

        {method === 'TRANSFER' && (
          <div>
            <label className="block text-xs font-bold text-text-main mb-1">شماره پیگیری / ارجاع</label>
            <input 
              type="text" 
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono text-text-main outline-none focus:bg-white focus:border-primary" 
              value={reference} 
              onChange={e => setReference(e.target.value)} 
              placeholder="کد پیگیری تراکنش"
              dir="ltr"
            />
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">بانک و توضیحات</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main outline-none focus:bg-white focus:border-primary" 
            value={notes} 
            onChange={e => setNotes(e.target.value)} 
            placeholder="نام بانک، شعبه یا توضیحات..." 
          />
        </div>

        <div className="pt-2">
          <Button onClick={handleSave} className="w-full">ثبت دریافت و کسر از بدهی</Button>
        </div>
      </div>
    </ModalOverlay>
  );
}

export function NewContactModal({ customer, onClose, updateState, initialContact }: ModalProps & { initialContact?: any }) {
  const [name, setName] = useState(initialContact?.name || '');
  const [role, setRole] = useState(initialContact?.role || 'مسئول خرید');
  const [phone, setPhone] = useState(initialContact?.phone || '');
  const [mobile, setMobile] = useState(initialContact?.mobile || '');
  const [email, setEmail] = useState(initialContact?.email || '');
  const [notes, setNotes] = useState(initialContact?.notes || '');
  const [isPrimary, setIsPrimary] = useState(initialContact?.isPrimary ?? (customer.contacts?.length === 0));

  const handleSave = () => {
    if (!name.trim()) return;

    updateState(draft => {
      const targetCustomer = draft.accounts.find(c => c.id === customer.id);
      if (!targetCustomer) return draft;

      if (!targetCustomer.contacts) targetCustomer.contacts = [];

      if (isPrimary) {
        targetCustomer.contacts.forEach(c => { c.isPrimary = false; });
      }

      if (initialContact?.id) {
        const idx = targetCustomer.contacts.findIndex(c => c.id === initialContact.id);
        if (idx >= 0) {
          targetCustomer.contacts[idx] = {
            ...targetCustomer.contacts[idx],
            name, role, phone, mobile, email, notes, isPrimary
          } as any;
        }
      } else {
        const newContactId = generateId();
        targetCustomer.contacts.push({
          id: newContactId,
          accountId: customer.id,
          name, role, phone, mobile, email, notes, isPrimary
        } as any);

        if (!draft.timelineEvents) draft.timelineEvents = [];
        draft.timelineEvents.push({
          id: generateId(),
          customerId: customer.id,
          type: 'STATUS_CHANGE',
          title: 'مخاطب جدید افزوده شد',
          description: `${name} (${role})`,
          dateTime: new Date().toISOString(),
          relatedEntityId: newContactId
        });
      }

      return draft;
    });

    onClose();
  };

  return (
    <ModalOverlay onClose={onClose} title={initialContact ? 'ویرایش اطلاعات مخاطب' : 'افزودن مخاطب جدید'}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-text-main mb-1">نام و نام خانوادگی *</label>
          <input 
            type="text" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-bold text-text-main outline-none focus:bg-white focus:border-primary transition-all" 
            value={name} 
            onChange={e => setName(e.target.value)} 
            placeholder="مثال: حاج محمد حسینی"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">سمت / جایگاه سازمانی</label>
          <select 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main font-bold outline-none focus:bg-white focus:border-primary"
            value={role}
            onChange={e => setRole(e.target.value)}
          >
            <option value="مالک و صاحب امتیاز">مالک و صاحب امتیاز</option>
            <option value="مدیر فروشگاه">مدیر فروشگاه</option>
            <option value="مسئول خرید">مسئول خرید</option>
            <option value="حسابدار و امور مالی">حسابدار و امور مالی</option>
            <option value="مسئول انبار و تحویل">مسئول انبار و تحویل</option>
            <option value="فروشنده / صندوقدار">فروشنده / صندوقدار</option>
            <option value="سایر">سایر</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-text-main mb-1">تلفن همراه</label>
            <input 
              type="text" 
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono text-text-main outline-none focus:bg-white focus:border-primary" 
              value={mobile} 
              onChange={e => setMobile(e.target.value)} 
              placeholder="0912..."
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-text-main mb-1">تلفن ثابت</label>
            <input 
              type="text" 
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono text-text-main outline-none focus:bg-white focus:border-primary" 
              value={phone} 
              onChange={e => setPhone(e.target.value)} 
              placeholder="021..."
              dir="ltr"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">پست الکترونیک (ایمیل)</label>
          <input 
            type="email" 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs font-mono text-text-main outline-none focus:bg-white focus:border-primary" 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            placeholder="contact@email.com"
            dir="ltr"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-text-main mb-1">یادداشت و ترجیحات ارتباطی</label>
          <textarea 
            className="w-full p-2.5 rounded-xl border border-slate-200 bg-canvas text-xs text-text-main resize-none h-16 outline-none focus:bg-white focus:border-primary" 
            value={notes} 
            onChange={e => setNotes(e.target.value)} 
            placeholder="مثال: روزهای فرد قبل از ظهر تماس گرفته شود..."
          />
        </div>

        <div className="flex items-center gap-2 p-2.5 bg-canvas border border-slate-200 rounded-xl">
          <input 
            type="checkbox" 
            id="isPrimaryContact"
            checked={isPrimary}
            onChange={e => setIsPrimary(e.target.checked)}
            className="w-4 h-4 rounded text-primary accent-primary cursor-pointer"
          />
          <label htmlFor="isPrimaryContact" className="text-xs font-bold text-text-main cursor-pointer select-none">
            انتخاب به عنوان مخاطب و طرف تماس اصلی
          </label>
        </div>

        <Button 
          onClick={handleSave} 
          disabled={!name.trim()}
          className="w-full mt-2"
        >
          {initialContact ? 'ذخیره تغییرات' : 'افزودن مخاطب'}
        </Button>
      </div>
    </ModalOverlay>
  );
}
