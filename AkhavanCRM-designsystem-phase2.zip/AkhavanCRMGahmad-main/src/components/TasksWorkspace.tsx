import React, { useState, useMemo } from 'react';
import { AppState, CustomerTask, ID, Priority } from '../types';
import { processTaskCollaborationEvents } from '../lib/collaboration';
import { CheckSquare, Plus, Search, X } from 'lucide-react';
import { FilterChip } from './ui/Tabs';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';
import { EmptyState } from './ui/EmptyState';
import { Button } from './ui/Button';
import { CustomDatePicker } from './ui/CustomDatePicker';
import { SearchableSelect } from './ui/SearchableSelect';
import { TaskCard } from './shared/TaskCard';
import { AttachmentManager } from './ui/AttachmentManager';
import { generateId } from '../lib/utils';
import { parseTaskIntent } from '../lib/enterprise';
import { emitBusinessEvent } from '../lib/events';

interface TasksWorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
}

export function TasksWorkspace({ state, updateState }: TasksWorkspaceProps) {
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'OPEN' | 'IN_PROGRESS' | 'COMPLETED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [editingTask, setEditingTask] = useState<CustomerTask | null>(null);
  const [showAttachModalFor, setShowAttachModalFor] = useState<ID | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskDueDate, setTaskDueDate] = useState(new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]);
  const [taskAccountId, setTaskAccountId] = useState('');
  const [taskPriority, setTaskPriority] = useState<Priority>('NORMAL');
  const [assigneeType, setAssigneeType] = useState<'USER' | 'GROUP'>('USER');
  const [assigneeId, setAssigneeId] = useState<string>(state.currentUserId || '');

  const activeAccountId = state.activeContextAccountId;

  const filteredTasks = useMemo(() => {
    let list = (state.tasks || []).filter(t => activeAccountId ? (t.accountId === activeAccountId || t.customerId === activeAccountId) : true);

    if (filterStatus === 'OPEN') list = list.filter(t => t.status === 'OPEN');
    if (filterStatus === 'IN_PROGRESS') list = list.filter(t => t.status === 'IN_PROGRESS');
    if (filterStatus === 'COMPLETED') list = list.filter(t => t.status === 'COMPLETED');

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(t => t.title.toLowerCase().includes(q) || (t.description && t.description.toLowerCase().includes(q)));
    }

    return list.sort((a, b) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });
  }, [state.tasks, activeAccountId, filterStatus, searchQuery]);

  const openNewTaskModal = () => {
    setEditingTask(null);
    setTaskTitle('');
    setTaskDescription('');
    setTaskAccountId(state.activeContextAccountId || state.accounts?.[0]?.id || '');
    setTaskDueDate(new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]);
    setAssigneeType('USER');
    setAssigneeId(state.currentUserId || '');
    setErrorMsg('');
    setShowTaskModal(true);
  };

  const openEditTaskModal = (task: CustomerTask) => {
    setEditingTask(task);
    setTaskTitle(task.title);
    setTaskDescription(task.description || '');
    setTaskAccountId(task.accountId || '');
    setTaskDueDate(task.dueDate || '');
    setTaskPriority(task.priority || 'NORMAL');
    setAssigneeType(task.assigneeType || 'USER');
    setAssigneeId(task.assigneeId || '');
    setErrorMsg('');
    setShowTaskModal(true);
  };

  const handleSaveTask = () => {
    setErrorMsg('');
    if (!taskTitle.trim()) return setErrorMsg('عنوان وظیفه را تکمیل کنید.');
    if (!taskAccountId) return setErrorMsg('حساب تجاری مربوطه را مشخص کنید.');
    if (!assigneeId) return setErrorMsg('مسئول انجام کار را انتخاب کنید.');

    updateState(draft => {
      if (!draft.tasks) draft.tasks = [];
      
      if (editingTask) {
        const t = draft.tasks.find(x => x.id === editingTask.id);
        if (t) {
          t.title = taskTitle.trim();
          t.description = taskDescription.trim();
          t.accountId = taskAccountId;
          t.dueDate = taskDueDate;
          t.priority = taskPriority;
          
          if (t.assigneeId !== assigneeId) {
            if (!t.reassignHistory) t.reassignHistory = [];
            t.reassignHistory.push({
              fromId: t.assigneeId || 'UNKNOWN',
              toId: assigneeId,
              date: new Date().toISOString(),
              reason: 'ویرایش و ارجاع'
            });
            t.assigneeType = assigneeType;
            t.assigneeId = assigneeId;
          }
        }
      } else {
        const intentInfo = parseTaskIntent(taskTitle + ' ' + taskDescription);
        const newTask: CustomerTask = {
          id: generateId(),
          accountId: taskAccountId,
          customerId: taskAccountId,
          title: taskTitle.trim(),
          description: taskDescription.trim(),
          dueDate: taskDueDate,
          status: 'OPEN',
          priority: taskPriority === 'NORMAL' && intentInfo.priority !== 'NORMAL' ? intentInfo.priority : taskPriority,
          slaStatus: 'ON_TRACK',
          assigneeType,
          assigneeId,
          smartIntent: intentInfo.intent,
          smartReason: intentInfo.reason,
          createdAt: new Date().toISOString()
        };
        draft.tasks.unshift(newTask);
        processTaskCollaborationEvents(newTask, state, draft, true);
        emitBusinessEvent('TASK_CREATED', 'TASK', newTask.id, newTask, state, updateState);
      }
    });

    setShowTaskModal(false);
  };

  const handleToggleTaskStatus = (taskId: ID) => {
    updateState(draft => {
      const t = draft.tasks?.find(item => item.id === taskId);
      if (t) {
        t.status = t.status === 'COMPLETED' ? 'OPEN' : 'COMPLETED';
      }
    });
  };

  const accountOptions = (state.accounts || []).map(a => ({ value: a.id, label: a.name, subLabel: a.code }));
  const assigneeOptions = assigneeType === 'USER' 
    ? (state.users || []).map(u => ({ value: u.id, label: u.name }))
    : (state.groups || []).map(g => ({ value: g.id, label: g.name }));

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas" dir="rtl">
      <div className="shrink-0 bg-canvas px-5 sm:px-8 pt-6 pb-4 space-y-4 z-10">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-black text-text-main tracking-tight flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-primary" /> مدیریت وظایف
            </h2>
            <span className="text-xs text-text-secondary font-medium mt-0.5 block">پیگیری‌ها، ارجاعات و فایل‌های ضمیمه</span>
          </div>
          <Button variant="primary" onClick={openNewTaskModal} icon={<Plus className="w-4 h-4" />}>تسک جدید</Button>
        </div>
        
        {activeAccountId && (
          <div className="bg-primary/10 border border-primary/20 text-primary text-xs font-bold p-3.5 rounded-2xl flex items-center justify-between">
            <span>در حال نمایش پیگیری‌های اختصاصی حساب: {state.accounts?.find(a=>a.id===activeAccountId)?.name}</span>
            <button onClick={() => updateState(d => { d.activeContextAccountId = null; d.activeContextCustomerId = null; })} className="text-primary hover:text-primary-hover bg-primary/20 p-1.5 rounded-xl cursor-pointer">
              <X size={14} />
            </button>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between pt-2">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            <FilterChip label="همه وظایف" active={filterStatus === 'ALL'} onClick={() => setFilterStatus('ALL')} />
            <FilterChip label="در انتظار" active={filterStatus === 'OPEN'} onClick={() => setFilterStatus('OPEN')} />
            <FilterChip label="تکمیل‌شده" active={filterStatus === 'COMPLETED'} onClick={() => setFilterStatus('COMPLETED')} />
          </div>
          <div className="relative w-full sm:w-64">
            <input type="text" placeholder="جستجو..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full h-[42px] bg-surface border border-border/80 rounded-2xl pl-4 pr-11 text-xs font-medium text-text-main outline-none focus:border-primary shadow-subtle" />
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-text-secondary" size={16} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 px-5 sm:px-8 pb-32 pt-2">
        {filteredTasks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTasks.map(task => {
              const acc = state.accounts?.find(a => a.id === (task.accountId || task.customerId));
              const isDone = task.status === 'COMPLETED';
              let assigneeName = 'ناشناس';
              if (task.assigneeType === 'GROUP') {
                assigneeName = state.groups?.find(g => g.id === task.assigneeId)?.name || assigneeName;
              } else {
                assigneeName = state.users?.find(u => u.id === task.assigneeId)?.name || assigneeName;
              }
              const attachmentCount = (state.attachments || []).filter(a => a.entityId === task.id).length;

              return (
                <TaskCard 
                  key={task.id}
                  task={task}
                  account={acc}
                  assigneeName={assigneeName}
                  isCompleted={isDone}
                  attachmentCount={attachmentCount}
                  onToggleStatus={() => handleToggleTaskStatus(task.id)}
                  onEdit={() => openEditTaskModal(task)}
                  onAttach={() => setShowAttachModalFor(task.id)}
                />
              );
            })}
          </div>
        ) : (
          <EmptyState 
            icon={<CheckSquare className="w-8 h-8 text-text-secondary opacity-50" />} 
            title="وظیفه‌ای یافت نشد" 
            description="برای ایجاد تسک پیگیری جدید روی دکمه تسک جدید کلیک کنید." 
            actionLabel="تسک جدید"
            onAction={openNewTaskModal}
          />
        )}
      </div>

      <Modal 
        isOpen={showTaskModal} 
        onClose={() => setShowTaskModal(false)} 
        title={editingTask ? "ویرایش وظیفه" : "تعریف وظیفه جدید"}
        footer={
          <>
            <Button variant="ghost" onClick={() => setShowTaskModal(false)}>انصراف</Button>
            <Button variant="primary" onClick={handleSaveTask}>{editingTask ? 'ذخیره تغییرات' : 'ثبت وظیفه'}</Button>
          </>
        }
      >
        <div className="space-y-4 text-xs">
          {errorMsg && <div className="bg-[#FEF2F2] border border-[#FECACA] text-[#991B1B] px-4 py-3 rounded-2xl font-bold">{errorMsg}</div>}
          
          <Input label="عنوان وظیفه" placeholder="مثال: پیگیری تایید پیش‌فاکتور" value={taskTitle} onChange={e => setTaskTitle(e.target.value)} required />

          <SearchableSelect 
            label="مشتری / حساب تجاری مرتبط"
            options={accountOptions}
            value={taskAccountId}
            onChange={setTaskAccountId}
            required
          />

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-text-main mb-1">مهلت انجام</label>
              <CustomDatePicker value={taskDueDate} onChange={d => setTaskDueDate(d)} />
            </div>
            <div>
              <label className="block font-bold text-text-main mb-1">اولویت</label>
              <select value={taskPriority} onChange={e => setTaskPriority(e.target.value as Priority)} className="w-full bg-surface border border-border/80 rounded-2xl p-3 font-medium outline-none focus:border-primary">
                <option value="NORMAL">عادی</option>
                <option value="HIGH">بالا</option>
                <option value="URGENT">بسیار فوری</option>
                <option value="LOW">پایین</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-text-main mb-1">شرح و جزئیات اقدام</label>
            <textarea rows={3} placeholder="توضیحات تکمیلی..." value={taskDescription} onChange={e => setTaskDescription(e.target.value)} className="w-full bg-surface border border-border/80 rounded-2xl p-3 font-medium outline-none focus:border-primary shadow-subtle" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-text-main mb-1">نوع تخصیص</label>
              <select value={assigneeType} onChange={e => { setAssigneeType(e.target.value as 'USER'|'GROUP'); setAssigneeId(''); }} className="w-full bg-surface border border-border/80 rounded-2xl p-3 outline-none focus:border-primary">
                <option value="USER">فردی (کارشناس)</option>
                <option value="GROUP">تیمی (گروه کاری)</option>
              </select>
            </div>
            <SearchableSelect 
              label="مسئول انجام"
              options={assigneeOptions}
              value={assigneeId}
              onChange={setAssigneeId}
              required
            />
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={!!showAttachModalFor}
        onClose={() => setShowAttachModalFor(null)}
        title="مدیریت فایل‌ها و پیوست‌ها"
        footer={<Button variant="primary" onClick={() => setShowAttachModalFor(null)}>بستن</Button>}
      >
        {showAttachModalFor && (
          <AttachmentManager 
            entityId={showAttachModalFor}
            entityType="TASK"
            state={state}
            updateState={updateState}
          />
        )}
      </Modal>
    </div>
  );
}
