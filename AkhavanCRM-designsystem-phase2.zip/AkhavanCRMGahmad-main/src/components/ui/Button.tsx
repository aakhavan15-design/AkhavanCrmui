import React from 'react';
import { cn } from '../../lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost' | 'success';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  icon?: React.ReactNode;
  loading?: boolean;
  children?: React.ReactNode;
}

const base =
  'relative inline-flex items-center justify-center gap-2 rounded-full font-bold select-none cursor-pointer whitespace-nowrap ' +
  'transition-all duration-200 ease-out motion-safe:hover:-translate-y-px active:scale-[0.97] ' +
  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ' +
  'disabled:pointer-events-none disabled:opacity-45';

const variants = {
  primary:
    'text-white bg-linear-to-b from-[#2E2F35] to-primary hover:from-[#3B3C43] hover:to-[#17181B] ' +
    'shadow-[inset_0_1px_0_rgba(255,255,255,.16),0_10px_22px_-8px_rgba(11,11,12,.55)]',
  secondary:
    'text-text-main bg-white/70 backdrop-blur-md border border-white/80 hover:bg-white ' +
    'shadow-[inset_0_1px_0_#fff,0_6px_16px_-8px_rgba(15,23,42,.22)]',
  outline: 'text-text-main border border-text-main/15 bg-transparent hover:bg-white/60',
  danger:
    'text-white bg-linear-to-b from-[#D9726A] to-[#C25A52] hover:brightness-95 ' +
    'shadow-[inset_0_1px_0_rgba(255,255,255,.25),0_10px_22px_-8px_rgba(194,90,82,.6)]',
  ghost: 'text-text-main hover:bg-text-main/5',
  success:
    'text-[#0F3D12] bg-linear-to-b from-[#8AD48A] to-status-healthy hover:brightness-95 ' +
    'shadow-[inset_0_1px_0_rgba(255,255,255,.4),0_10px_22px_-8px_rgba(107,191,107,.6)]',
} as const;

const sizes = {
  sm: 'h-9 px-4 text-xs',
  md: 'h-11 px-5 text-xs',
  lg: 'h-12 px-6 text-sm',
  icon: 'h-11 w-11 p-0 text-sm',
} as const;

export function Button({
  variant = 'primary', size = 'md', icon, loading = false, className = '', children, disabled, ...props
}: ButtonProps) {
  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? (
        <span aria-hidden className="h-4 w-4 rounded-full border-2 border-current border-t-transparent motion-safe:animate-spin" />
      ) : icon ? (
        <span className="inline-flex shrink-0">{icon}</span>
      ) : null}
      {children}
    </button>
  );
}

/** دکمه گرد شیشه‌ای (جستجو، اعلان، منو...) مطابق مرجع */
export const IconButton = React.forwardRef<HTMLButtonElement, React.ButtonHTMLAttributes<HTMLButtonElement> & { 'aria-label': string; active?: boolean }>(
  ({ className, active, children, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        'relative grid h-11 w-11 shrink-0 cursor-pointer place-items-center rounded-full transition-all duration-200',
        'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent active:scale-95 motion-safe:hover:-translate-y-px',
        active ? 'bg-primary text-white shadow-lux' : 'glass text-text-main hover:bg-white',
        className
      )}
      {...props}
    >
      {children}
    </button>
  )
);
IconButton.displayName = 'IconButton';
