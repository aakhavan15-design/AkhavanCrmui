import React from 'react';
import { cn } from '../../lib/utils';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  className = '',
  ...props
}) => {
  return (
    <div className="space-y-1 text-right" dir="rtl">
      {label && <label className="block font-bold text-text-main text-xs mb-1">{label}</label>}
      <input
        className={cn(
          'w-full bg-white border border-[#E2E8F0] rounded-2xl p-3 text-xs font-medium text-text-main outline-none focus:border-accent focus:ring-2 focus:ring-accent/30 shadow-subtle transition-all',
          error ? 'border-rose-400 bg-rose-50/20' : '',
          className
        )}
        {...props}
      />
      {error && <span className="text-[10px] text-rose-600 block mt-0.5">{error}</span>}
    </div>
  );
};
