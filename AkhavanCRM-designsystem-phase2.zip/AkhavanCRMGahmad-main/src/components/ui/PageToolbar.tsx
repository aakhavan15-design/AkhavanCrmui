import React from 'react';
import { Search } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface PageToolbarProps {
  title?: string; subtitle?: string;
  search?: string; onSearchChange?: (v: string) => void; searchPlaceholder?: string;
  filters?: React.ReactNode; actions?: React.ReactNode; className?: string;
}

/** نوار ابزار استاندارد صفحه: عنوان + جستجو + فیلترها + اقدامات (شیشه‌ای، گرد) */
export function PageToolbar({ title, subtitle, search, onSearchChange, searchPlaceholder = 'جستجو...', filters, actions, className }: PageToolbarProps) {
  return (
    <div className={cn('glass flex flex-wrap items-center gap-3 rounded-[28px] p-3', className)}>
      {(title || subtitle) && (
        <div className="min-w-0 px-2">
          {title && <h1 className="truncate text-sm font-extrabold text-text-main">{title}</h1>}
          {subtitle && <p className="truncate text-[11px] text-text-secondary">{subtitle}</p>}
        </div>
      )}
      {onSearchChange && (
        <label className="flex h-11 min-w-[180px] flex-1 items-center gap-2 rounded-full bg-white/80 px-4 shadow-[inset_0_1px_3px_rgba(15,23,42,.06)] focus-within:ring-2 focus-within:ring-accent">
          <Search size={16} className="shrink-0 text-text-secondary" />
          <input type="text" value={search ?? ''} onChange={e => onSearchChange(e.target.value)} placeholder={searchPlaceholder}
            className="w-full bg-transparent text-xs font-medium text-text-main outline-none placeholder:text-text-secondary" />
        </label>
      )}
      {filters && <div className="no-scrollbar flex max-w-full items-center gap-2 overflow-x-auto">{filters}</div>}
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
