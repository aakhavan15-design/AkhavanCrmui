import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, ChevronDown, ChevronLeft, Sparkles, LogOut } from 'lucide-react';
import { Avatar } from './ui/Avatar';
import { cn } from '../lib/utils';
import { menuSections, isActivePath } from '../lib/navigation';

interface NavigationDrawerProps { isOpen: boolean; onClose: () => void; state: any }

export function NavigationDrawer({ isOpen, onClose, state }: NavigationDrawerProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({ sales: true, finance: true, operations: true, system: true });

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentUser = state?.users?.find((u: any) => u.id === state?.currentUserId);
  const currentRole = state?.roles?.find((r: any) => r.id === currentUser?.roleId);
  const toggleSection = (section: string) => setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  const go = (path: string) => { navigate(path); onClose(); };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-premium" dir="rtl" role="dialog" aria-modal="true" aria-label="منوی اصلی">
      <div onClick={onClose} className="fixed inset-0 bg-text-main/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-300" />

      <div className="fixed inset-y-0 right-0 z-50 flex max-w-full p-2">
        <div className="glass-strong flex h-full w-[85vw] max-w-[340px] animate-in slide-in-from-right flex-col overflow-hidden rounded-[32px] duration-300 ease-out">

          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-primary text-base font-black text-white shadow-lux">ا</span>
              <div>
                <h3 className="text-xs font-black tracking-tight text-text-main">AKHAVAN CRM</h3>
                <p className="text-[10px] font-medium text-text-secondary">سیستم جامع فروش و سازمان</p>
              </div>
            </div>
            <button onClick={onClose} aria-label="بستن منو"
              className="glass grid h-11 w-11 cursor-pointer place-items-center rounded-full text-text-main transition hover:bg-white">
              <X size={16} />
            </button>
          </div>

          <div className="px-3 pb-3">
            <button onClick={() => go('/profile')}
              className="flex w-full cursor-pointer items-center gap-2.5 rounded-full bg-white/70 p-2 text-start transition hover:bg-white">
              <Avatar name={currentUser?.name || 'کاربر'} size="sm" />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 truncate text-xs font-bold text-text-main">
                  <span>{currentUser?.name || 'کاربر سیستم'}</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-status-healthy" />
                </div>
                <div className="mt-0.5 truncate text-[10px] text-text-secondary">{currentRole?.name || 'مدیر سیستم'}</div>
              </div>
              <ChevronLeft size={14} className="text-text-secondary" />
            </button>
          </div>

          <div className="no-scrollbar flex-1 space-y-4 overflow-y-auto px-3 pb-3">
            <button onClick={() => go('/')}
              className={cn('flex w-full cursor-pointer items-center gap-2.5 rounded-full px-4 py-3 transition-all',
                currentPath === '/' ? 'bg-primary font-bold text-white shadow-lux' : 'text-text-main hover:bg-white/70')}>
              <Sparkles size={16} />
              <span className="text-xs font-bold">صفحه میز کار (خانه)</span>
            </button>

            {menuSections.map(section => {
              const open = openSections[section.id];
              return (
                <div key={section.id} className="space-y-1">
                  <button onClick={() => toggleSection(section.id)} aria-expanded={open}
                    className="flex w-full cursor-pointer items-center justify-between px-3 py-1.5 text-[11px] font-black text-text-secondary transition-colors hover:text-text-main">
                    <span>{section.title}</span>
                    <ChevronDown size={13} className={cn('transition-transform duration-200', open && 'rotate-180')} />
                  </button>
                  {open && (
                    <div className="space-y-0.5">
                      {section.items.map(item => {
                        const on = isActivePath(currentPath, item.path);
                        const Icon = item.icon;
                        return (
                          <button key={item.id} onClick={() => go(item.path)} aria-current={on ? 'page' : undefined}
                            className={cn('group flex w-full cursor-pointer items-center gap-2.5 rounded-full px-4 py-2.5 text-start transition-all',
                              on ? 'bg-primary font-extrabold text-white shadow-lux' : 'text-text-main hover:bg-white/70')}>
                            <Icon size={15} className={cn('shrink-0', on ? 'text-white' : 'text-text-secondary group-hover:text-text-main')} />
                            <span className="truncate text-xs">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between border-t border-text-main/5 p-3 px-5 text-[10px] text-text-secondary">
            <span className="font-mono">Akhavan v2.6 Pro</span>
            <button onClick={() => go('/profile')} className="flex cursor-pointer items-center gap-1 transition-colors hover:text-status-risk">
              <LogOut size={13} /><span>خروج</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
