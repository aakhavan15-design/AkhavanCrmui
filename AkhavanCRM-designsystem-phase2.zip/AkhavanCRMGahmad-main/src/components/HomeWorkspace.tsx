import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState } from '../types';
import { Card } from './ui/Card';
import { CheckSquare, Clock, AlertTriangle, Building2, ChevronLeft, Calendar } from 'lucide-react';

export function HomeWorkspace({ state }: { state: AppState }) {
  const navigate = useNavigate();
  const currentUser = state.users.find(u => u.id === state.currentUserId);
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  const myTasks = (state.tasks || []).filter(t => t.assigneeId === state.currentUserId && t.status !== 'COMPLETED');
  const overdueTasks = myTasks.filter(t => t.dueDate && t.dueDate < today);
  const pendingApprovals = (state.internalRequests || []).filter((r: any) => r.currentAssigneeId === state.currentUserId && r.status === 'IN_REVIEW');

  const todayActivities = (state.activities || []).filter(a => a.ownerId === state.currentUserId && a.dateTime.startsWith(today));
  const todayMeetings = (state.internalMeetings || []).filter((m: any) => (m.organizerId === state.currentUserId || m.participantIds?.includes(state.currentUserId || '')) && m.date === today);

  const recentAccounts = [...(state.accounts || [])].sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()).slice(0, 5);

  const todayDateStr = new Intl.DateTimeFormat('fa-IR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(new Date());

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50/60 p-3.5 sm:p-5 space-y-4 sm:space-y-5 pb-24 font-premium" dir="rtl">
      {/* Clean Typography Header without duplicate avatar */}
      <div className="pt-1 pb-1" data-tour="header-user">
        <h1 className="text-xl sm:text-2xl font-black text-text-main tracking-tight">
          سلام، {currentUser?.name?.split(' ')[0] || 'همکار گرامی'} عزیز
        </h1>
        <p className="text-xs text-slate-500 font-medium mt-1 flex items-center gap-1.5">
          <Calendar size={13} className="text-primary" />
          <span>{todayDateStr}</span>
        </p>
      </div>

      {/* Action Needed Section */}
      <div data-tour="needs-action" className="space-y-2">
        <h2 className="text-xs font-bold text-slate-700 px-0.5">نیاز به اقدام شما</h2>
        <div className="grid grid-cols-2 gap-2.5">
          <Card 
            className="p-3.5 bg-white border border-slate-100 rounded-2xl shadow-[0_2px_10px_-3px_rgba(0,0,0,0.05)] flex flex-col gap-1.5 cursor-pointer hover:border-red-200 hover:shadow-md transition-all active:scale-[0.98]" 
            onClick={() => navigate('/tasks')}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">وظایف تأخیردار</span>
              <div className="w-7 h-7 rounded-xl bg-red-50 flex items-center justify-center text-red-600">
                <AlertTriangle size={15} />
              </div>
            </div>
            <span className="text-xl font-black text-slate-900 mt-1">{overdueTasks.length}</span>
            <span className="text-[11px] text-slate-400 font-medium">نیازمند پیگیری فوری</span>
          </Card>

          <Card 
            className="p-3.5 bg-white border border-slate-100 rounded-2xl shadow-[0_2px_10px_-3px_rgba(0,0,0,0.05)] flex flex-col gap-1.5 cursor-pointer hover:border-amber-200 hover:shadow-md transition-all active:scale-[0.98]" 
            onClick={() => navigate('/internal_automation')}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600">تأییدیه‌های منتظر</span>
              <div className="w-7 h-7 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                <CheckSquare size={15} />
              </div>
            </div>
            <span className="text-xl font-black text-slate-900 mt-1">{pendingApprovals.length}</span>
            <span className="text-[11px] text-slate-400 font-medium">کارتابل اتوماسیون</span>
          </Card>
        </div>
      </div>

      {/* Today Schedule Section */}
      <div data-tour="today-schedule" className="space-y-2">
        <div className="flex justify-between items-center px-0.5">
          <h2 className="text-xs font-bold text-slate-700">برنامه کاری امروز</h2>
          <button 
            onClick={() => navigate('/calendar')} 
            className="text-[11px] text-primary font-bold cursor-pointer hover:underline flex items-center gap-0.5"
          >
            <span>مشاهده تقویم</span>
            <ChevronLeft size={13} />
          </button>
        </div>

        <div className="space-y-2">
          {todayMeetings.map((m: any) => (
            <div 
              key={m.id} 
              className="p-3 bg-white border border-slate-100 rounded-2xl shadow-[0_2px_8px_-3px_rgba(0,0,0,0.04)] flex items-center gap-3 border-r-4 border-r-primary"
            >
              <div className="flex flex-col items-center justify-center min-w-[48px] bg-slate-50 py-1.5 px-2 rounded-xl text-center">
                <span className="text-xs font-bold text-slate-900">{m.startTime}</span>
                <span className="text-[10px] text-slate-400">{m.endTime}</span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-xs font-bold text-slate-800 truncate">{m.title}</h3>
                <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                  <Clock size={11} className="text-slate-400" />
                  <span>جلسه کاری</span>
                </p>
              </div>
            </div>
          ))}

          {todayActivities.map(a => {
            const acc = state.accounts.find(acc => acc.id === a.accountId);
            return (
              <div 
                key={a.id} 
                className="p-3 bg-white border border-slate-100 rounded-2xl shadow-[0_2px_8px_-3px_rgba(0,0,0,0.04)] flex items-center gap-3 border-r-4 border-r-[#06B6D4]"
              >
                <div className="flex flex-col items-center justify-center min-w-[48px] bg-slate-50 py-1.5 px-2 rounded-xl text-center">
                  <span className="text-xs font-bold text-slate-900">
                    {new Date(a.dateTime).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xs font-bold text-slate-800 truncate">{a.title}</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                    <Building2 size={11} className="text-slate-400" />
                    <span className="truncate">{acc?.name || 'مشتری'}</span>
                  </p>
                </div>
              </div>
            );
          })}

          {todayMeetings.length === 0 && todayActivities.length === 0 && (
            <div className="text-center py-5 px-4 bg-white border border-dashed border-slate-200 rounded-2xl text-xs text-slate-400 font-medium">
              رویداد یا جلسه‌ای برای امروز ثبت نشده است.
            </div>
          )}
        </div>
      </div>

      {/* Recent Customers Section */}
      <div data-tour="customer-worklist" className="space-y-2">
        <div className="flex justify-between items-center px-0.5">
          <h2 className="text-xs font-bold text-slate-700">مشتریان اخیر</h2>
          <button 
            onClick={() => navigate('/accounts')} 
            className="text-[11px] text-primary font-bold cursor-pointer hover:underline flex items-center gap-0.5"
          >
            <span>همه حساب‌ها</span>
            <ChevronLeft size={13} />
          </button>
        </div>

        <div className="space-y-2">
          {recentAccounts.map(acc => (
            <div 
              key={acc.id} 
              className="p-3 bg-white border border-slate-100 rounded-2xl shadow-[0_2px_8px_-3px_rgba(0,0,0,0.04)] flex items-center justify-between cursor-pointer hover:border-slate-200 hover:shadow-md transition-all active:scale-[0.99]" 
              onClick={() => navigate(`/accounts/${acc.id}`)}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-bold text-xs shrink-0">
                  {acc.name ? acc.name.substring(0, 1) : 'م'}
                </div>
                <div className="min-w-0">
                  <h3 className="text-xs font-bold text-slate-900 truncate">{acc.name}</h3>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{acc.phone || 'بدون شماره'}</p>
                </div>
              </div>
              <ChevronLeft size={15} className="text-slate-400 shrink-0" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
