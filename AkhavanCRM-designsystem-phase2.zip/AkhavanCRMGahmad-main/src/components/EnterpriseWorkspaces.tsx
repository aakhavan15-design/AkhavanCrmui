import React, { useState } from 'react';
import { AppState, Case, Campaign, KnowledgeArticle, ID } from '../types';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';
import { CustomDatePicker } from './ui/CustomDatePicker';
import { ShieldAlert, BookOpen, Megaphone, Plus, Building2, Eye, X } from 'lucide-react';
import { generateId, formatAppDate } from '../lib/utils';
import { enqueueJob } from '../lib/automation';
import { emitBusinessEvent } from '../lib/events';
import { EmptyState } from './ui/EmptyState';

interface WorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
  setActiveTab?: (tab: any) => void;
}

// ----------------------------------------------------------------------
// CASES WORKSPACE
// ----------------------------------------------------------------------
export function CasesWorkspace({ state, updateState }: WorkspaceProps) {
  const cases = state.cases || [];
  const [isNewCaseOpen, setIsNewCaseOpen] = useState(false);
  const [caseSubject, setCaseSubject] = useState('');
  const [caseDesc, setCaseDesc] = useState('');
  const [caseAccountId, setCaseAccountId] = useState(state.activeContextAccountId || state.accounts[0]?.id || '');
  const [casePriority, setCasePriority] = useState<'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'>('NORMAL');
  const [formError, setFormError] = useState('');

  const handleCreateCase = () => {
    setFormError('');
    if (!caseSubject.trim()) return setFormError('موضوع پرونده الزامی است.');
    if (!caseAccountId) return setFormError('حساب مشتری مربوطه را انتخاب کنید.');

    const newCase: Case = {
      id: generateId(),
      caseNumber: `CS-${Date.now().toString().slice(-4)}`,
      accountId: caseAccountId,
      subject: caseSubject.trim(),
      description: caseDesc.trim(),
      status: 'NEW',
      priority: casePriority,
      ownerId: state.currentUserId || 'usr_admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.cases) draft.cases = [];
      draft.cases.unshift(newCase);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'CASE_CREATED',
        entityType: 'CASE',
        entityId: newCase.id,
        details: `پرونده خدمات ${newCase.caseNumber} با موضوع "${newCase.subject}" ایجاد شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setCaseSubject('');
    setCaseDesc('');
    setIsNewCaseOpen(false);
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas" dir="rtl">
      <div className="shrink-0 p-4 sm:p-6 pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h2 className="text-lg font-bold text-text-main flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-primary" /> میز خدمات و پشتیبانی مشتریان (Cases)
            </h2>
            <span className="text-xs text-text-secondary">مدیریت تیکت‌ها، شکایات و درخواست‌های پشتیبانی</span>
          </div>
          <Button variant="primary" onClick={() => setIsNewCaseOpen(true)} icon={<Plus className="w-4 h-4"/>}>
            مورد جدید
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto min-h-0 px-4 sm:px-6 pb-24 space-y-3">
        {cases.length > 0 ? cases.map((c: any) => {
          const acc = state.accounts.find(a => a.id === c.accountId);
          return (
            <Card key={c.id} padding="md" className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 hover:shadow-md transition-shadow bg-white border-[#E2E8F0]">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <strong className="text-sm font-bold text-text-main">{c.subject}</strong>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${c.priority === 'URGENT' || c.priority === 'HIGH' ? 'bg-red-50 text-[#991B1B]' : 'bg-canvas text-text-secondary'}`}>
                    {c.priority}
                  </span>
                </div>
                <div className="text-xs text-text-secondary flex items-center gap-3">
                  <span className="font-mono">{c.caseNumber}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1 font-semibold text-text-main">
                    <Building2 size={12} className="text-text-secondary" /> {acc?.name || 'حساب نامشخص'}
                  </span>
                </div>
                {c.description && <p className="text-xs text-text-secondary mt-1 leading-relaxed">{c.description}</p>}
              </div>
              <span className="px-2.5 py-1 text-[10px] font-bold bg-amber-50 text-[#92400E] rounded-lg shrink-0">
                {c.status}
              </span>
            </Card>
          );
        }) : (
          <EmptyState 
            icon={<ShieldAlert className="w-8 h-8 text-text-secondary opacity-50" />} 
            title="موردی یافت نشد" 
            description="هیچ پرونده پشتیبانی در سیستم ثبت نشده است." 
            actionLabel="مورد جدید"
            onAction={() => setIsNewCaseOpen(true)}
          />
        )}
      </div>

      <Modal isOpen={isNewCaseOpen} onClose={() => setIsNewCaseOpen(false)} title="ثبت مورد خدمات / شکایت جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setIsNewCaseOpen(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateCase}>ثبت پرونده</Button></>}>
        <div className="space-y-4 text-xs">
          {formError && <div className="p-2 bg-red-50 text-[#991B1B] rounded-lg font-bold">{formError}</div>}
          <Input label="موضوع پرونده *" value={caseSubject} onChange={e => setCaseSubject(e.target.value)} placeholder="مثال: تاخیر در تحویل بار" />
          <div>
            <label className="block font-bold text-text-main mb-1">حساب تجاری مربوطه *</label>
            <select value={caseAccountId} onChange={e => setCaseAccountId(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none font-medium focus:border-primary">
              {state.accounts.map(a => <option key={a.id} value={a.id}>{a.name} ({a.code || '-'})</option>)}
            </select>
          </div>
          <div>
            <label className="block font-bold text-text-main mb-1">اولویت رسیدگی</label>
            <select value={casePriority} onChange={e => setCasePriority(e.target.value as any)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none focus:border-primary">
              <option value="NORMAL">عادی</option>
              <option value="HIGH">بالا</option>
              <option value="URGENT">فوری / بحرانی</option>
              <option value="LOW">پایین</option>
            </select>
          </div>
          <div>
            <label className="block font-bold text-text-main mb-1">شرح دقیق درخواست یا شکایت</label>
            <textarea rows={3} value={caseDesc} onChange={e => setCaseDesc(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none focus:border-primary" placeholder="توضیحات تکمیلی..." />
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ----------------------------------------------------------------------
// CAMPAIGNS WORKSPACE
// ----------------------------------------------------------------------
export function CampaignsWorkspace({ state, updateState }: WorkspaceProps) {
  const campaigns = state.campaigns || [];
  const [isNewCampaignOpen, setIsNewCampaignOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]);
  const [formError, setFormError] = useState('');

  const handleCreateCampaign = () => {
    setFormError('');
    if (!name.trim()) return setFormError('نام کمپین الزامی است.');

    const newCamp: Campaign = {
      id: generateId(),
      name: name.trim(),
      description: description.trim(),
      targetAudience: targetAudience.trim() || 'عموم مشتریان',
      mode: 'DYNAMIC',
      startDate,
      endDate,
      status: 'ACTIVE',
      ownerId: state.currentUserId || 'usr_admin',
      executionCount: 0,
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.campaigns) draft.campaigns = [];
      draft.campaigns.unshift(newCamp);
    });

    emitBusinessEvent('CAMPAIGN_CREATED', 'CAMPAIGN', newCamp.id, newCamp, state, updateState);
    setName(''); setDescription(''); setTargetAudience(''); setIsNewCampaignOpen(false);
  };

  const handleBroadcastCampaign = (campId: string) => {
    updateState(draft => {
      const c = (draft.campaigns || []).find((item: any) => item.id === campId);
      if (c) {
        c.executionCount = (c.executionCount || 0) + 1;
        if (!draft.notifications) draft.notifications = [];
        draft.notifications.push({
          id: generateId(),
          title: `کمپین "${c.name}" در صف اجرا قرار گرفت`,
          message: `عملیات ارسال پیام به مخاطبان هدف به صف پس‌زمینه ارسال شد.`,
          type: 'INFO',
          read: false,
          createdAt: new Date().toISOString()
        });
      }
    });
    enqueueJob('EVALUATE_DYNAMIC_CAMPAIGN', { campaignId: campId }, state, updateState);
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas" dir="rtl">
      <div className="shrink-0 p-4 sm:p-6 pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h2 className="text-lg font-bold text-text-main flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-primary" /> بازاریابی و کمپین‌ها
            </h2>
            <span className="text-xs text-text-secondary">مدیریت پروموشن‌ها و برنامه‌های بازاریابی</span>
          </div>
          <Button variant="primary" onClick={() => setIsNewCampaignOpen(true)} icon={<Plus className="w-4 h-4"/>}>
            کمپین جدید
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto min-h-0 px-4 sm:px-6 pb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {campaigns.length > 0 ? campaigns.map((c: any) => (
            <Card key={c.id} padding="md" className="flex flex-col justify-between bg-white border-[#E2E8F0]">
              <div>
                <div className="flex justify-between items-start mb-2">
                  <strong className="text-sm font-bold text-text-main">{c.name}</strong>
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-sky-50 text-[#075985] rounded-lg">{c.status}</span>
                </div>
                <p className="text-xs text-text-secondary leading-relaxed">{c.description || 'بدون توضیحات'}</p>
                <div className="mt-3 pt-2 border-t border-[#E2E8F0] text-xs text-text-secondary flex justify-between items-center">
                  <span>مخاطبین هدف: <strong className="text-text-main">{c.targetAudience}</strong></span>
                  {c.startDate && <span className="font-mono text-[10px]">{c.startDate} تا {c.endDate || 'نامحدود'}</span>}
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-[#E2E8F0] flex items-center justify-between">
                <span className="text-[11px] text-text-secondary font-mono">تعداد اجرا: {c.executionCount || 0} نوبت</span>
                <Button size="sm" variant="outline" onClick={() => handleBroadcastCampaign(c.id)}>
                  اجرا در صف پیام‌رسان
                </Button>
              </div>
            </Card>
          )) : (
            <div className="col-span-full">
              <EmptyState 
                icon={<Megaphone className="w-8 h-8 text-text-secondary opacity-50" />} 
                title="کمپینی یافت نشد" 
                description="هیچ کمپین بازاریابی فعالی وجود ندارد." 
                actionLabel="کمپین جدید"
                onAction={() => setIsNewCampaignOpen(true)}
              />
            </div>
          )}
        </div>
      </div>

      <Modal isOpen={isNewCampaignOpen} onClose={() => setIsNewCampaignOpen(false)} title="ایجاد کمپین بازاریابی جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setIsNewCampaignOpen(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateCampaign}>ثبت و انتشار</Button></>}>
        <div className="space-y-4 text-xs">
          {formError && <div className="p-2 bg-red-50 text-[#991B1B] rounded-lg font-bold">{formError}</div>}
          <Input label="نام کمپین *" value={name} onChange={e => setName(e.target.value)} placeholder="مثال: پروموشن نوروزی" />
          <Input label="مخاطبان هدف" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} placeholder="مثال: هایپرمارکت‌ها" />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-text-main mb-1">تاریخ شروع</label>
              <CustomDatePicker value={startDate} onChange={d => setStartDate(d)} />
            </div>
            <div>
              <label className="block font-bold text-text-main mb-1">تاریخ پایان</label>
              <CustomDatePicker value={endDate} onChange={d => setEndDate(d)} />
            </div>
          </div>
          <div>
            <label className="block font-bold text-text-main mb-1">شرح و شرایط کمپین</label>
            <textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none focus:border-primary" placeholder="توضیحات تخفیف‌ها..." />
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ----------------------------------------------------------------------
// KNOWLEDGE WORKSPACE
// ----------------------------------------------------------------------
export function KnowledgeWorkspace({ state, updateState }: WorkspaceProps) {
  const articles = state.articles || [];
  const [isNewArticleOpen, setIsNewArticleOpen] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<KnowledgeArticle | null>(null);
  
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('مالی و اعتبارات');
  const [content, setContent] = useState('');
  const [formError, setFormError] = useState('');

  const handleCreateArticle = () => {
    setFormError('');
    if (!title.trim() || !content.trim()) return setFormError('عنوان و متن مقاله الزامی است.');

    const newArt: KnowledgeArticle = {
      id: generateId(),
      title: title.trim(),
      category: category.trim(),
      content: content.trim(),
      status: 'PUBLISHED',
      authorId: state.currentUserId || 'usr_admin',
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.articles) draft.articles = [];
      draft.articles.unshift(newArt);
    });

    setTitle(''); setContent(''); setIsNewArticleOpen(false);
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas" dir="rtl">
      <div className="shrink-0 p-4 sm:p-6 pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h2 className="text-lg font-bold text-text-main flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" /> پایگاه دانش و دستورالعمل‌ها
            </h2>
            <span className="text-xs text-text-secondary">مقالات آموزشی، بخشنامه‌ها و شیوه‌نامه‌ها</span>
          </div>
          <Button variant="primary" onClick={() => setIsNewArticleOpen(true)} icon={<Plus className="w-4 h-4"/>}>
            مقاله جدید
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto min-h-0 px-4 sm:px-6 pb-24 space-y-3">
        {articles.length > 0 ? articles.map((a: any) => (
          <Card key={a.id} padding="md" onClick={() => setSelectedArticle(a)} className="hover:shadow-md cursor-pointer transition-all hover:border-primary/50 bg-white border-[#E2E8F0]">
            <div className="flex justify-between items-start">
              <strong className="text-sm font-bold text-text-main">{a.title}</strong>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-primary/10 text-primary rounded-md">
                {a.category}
              </span>
            </div>
            <p className="text-xs text-text-secondary mt-1 line-clamp-2 leading-relaxed">{a.content}</p>
            <div className="mt-3 pt-2 border-t border-[#E2E8F0] text-[10px] text-text-secondary font-mono flex justify-between items-center">
              <span>تاریخ انتشار: {formatAppDate(a.createdAt, state.settings?.locale)}</span>
              <span className="text-primary font-bold flex items-center gap-1">مطالعه کامل <Eye size={12} /></span>
            </div>
          </Card>
        )) : (
          <EmptyState 
            icon={<BookOpen className="w-8 h-8 text-text-secondary opacity-50" />} 
            title="مقاله‌ای یافت نشد" 
            description="پایگاه دانش در حال حاضر خالی است." 
            actionLabel="مقاله جدید"
            onAction={() => setIsNewArticleOpen(true)}
          />
        )}
      </div>

      {selectedArticle && (
        <Modal isOpen={!!selectedArticle} onClose={() => setSelectedArticle(null)} title={selectedArticle.title} footer={<Button size="sm" variant="primary" onClick={() => setSelectedArticle(null)}>بستن</Button>}>
          <div className="space-y-4 text-xs">
            <div className="flex justify-between items-center bg-canvas p-2.5 rounded-xl border border-[#E2E8F0]">
              <span className="text-text-secondary font-medium">دسته‌بندی: <strong className="text-text-main">{selectedArticle.category}</strong></span>
              <span className="text-text-secondary font-mono text-[11px]">{formatAppDate(selectedArticle.createdAt, state.settings?.locale)}</span>
            </div>
            <div className="p-4 bg-white rounded-xl border border-[#E2E8F0] text-xs text-text-main leading-loose whitespace-pre-wrap">
              {selectedArticle.content}
            </div>
          </div>
        </Modal>
      )}

      <Modal isOpen={isNewArticleOpen} onClose={() => setIsNewArticleOpen(false)} title="افزودن مقاله و شیوه‌نامه جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setIsNewArticleOpen(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateArticle}>انتشار</Button></>}>
        <div className="space-y-4 text-xs">
          {formError && <div className="p-2 bg-red-50 text-[#991B1B] rounded-lg font-bold">{formError}</div>}
          <Input label="عنوان مقاله / بخشنامه *" value={title} onChange={e => setTitle(e.target.value)} placeholder="مثال: دستورالعمل تخفیف‌ها" />
          <div>
            <label className="block font-bold text-text-main mb-1">دسته‌بندی موضوعی</label>
            <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none font-medium focus:border-primary">
              <option value="مالی و اعتبارات">مالی و اعتبارات</option>
              <option value="فروش و تخفیفات">فروش و تخفیفات</option>
              <option value="لجستیک و تحویل">لجستیک و تحویل</option>
              <option value="روابط مشتریان">روابط مشتریان</option>
              <option value="آموزش عمومی">آموزش عمومی</option>
            </select>
          </div>
          <div>
            <label className="block font-bold text-text-main mb-1">متن کامل مقاله / بخشنامه *</label>
            <textarea rows={5} value={content} onChange={e => setContent(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 outline-none focus:border-primary" placeholder="متن بخشنامه..." />
          </div>
        </div>
      </Modal>
    </div>
  );
}
