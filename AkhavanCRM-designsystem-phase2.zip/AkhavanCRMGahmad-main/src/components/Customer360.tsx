import React, { useState, useMemo } from 'react';
import { 
  Account, AppState, Quote, ID, CustomerTask, Activity, 
  Opportunity, Case, CustomerPayment, CustomerNote, Mention, Priority, OpportunityStage 
} from '../types';
import { 
  ChevronRight, Phone, MapPin, Wallet, FileText, 
  CheckSquare, Clock, Plus, Building2, User, Send, 
  CheckCircle2, ShieldAlert, TrendingUp, History, MessageSquare, 
  Users, GitBranch, ArrowUpRight, AlertTriangle, UserCheck, Calendar, Activity as ActivityIcon
} from 'lucide-react';
import { 
  formatCurrency, generateId, formatAppDate, 
  cleanNumericInput, formatInputCurrency, parsePersianNumber 
} from '../lib/utils';
import { processTaskCollaborationEvents, processEntityMentions } from '../lib/collaboration';
import { Card } from './ui/Card';
import { Avatar } from './ui/Avatar';
import { EmptyState } from './ui/EmptyState';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';
import { CustomDatePicker } from './ui/CustomDatePicker';
import { SecureField } from './ui/SecureField';
import { calculateCustomerRiskScore, calculateDaysOverdue } from '../services/collectionEngine';
import { DynamicFormRenderer } from './shared/DynamicFormRenderer';
import { 
  ACTIVITY_FORM_SCHEMA, 
  NOTE_FORM_SCHEMA, 
  createTaskFormSchema, 
  OPPORTUNITY_FORM_SCHEMA, 
  SERVICE_CASE_SCHEMA, 
  PAYMENT_RECEIPT_SCHEMA 
} from '../services/dynamicFormEngine';

interface Customer360Props {
  customer: Account;
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
  onBack: () => void;
  setActiveTab?: (tab: any) => void;
}

type TabKey = 
  | 'OVERVIEW' 
  | 'TIMELINE' 
  | 'ACTIVITIES' 
  | 'NOTES' 
  | 'QUOTES' 
  | 'OPPORTUNITIES' 
  | 'TASKS' 
  | 'CASES' 
  | 'FINANCE' 
  | 'AUDIT';

export function Customer360({ customer, state, onBack, updateState, setActiveTab }: Customer360Props) {
  const [activeSubTab, setActiveSubTab] = useState<TabKey>('OVERVIEW');

  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isOppModalOpen, setIsOppModalOpen] = useState(false);
  const [isCaseModalOpen, setIsCaseModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  const accountQuotes = (state.quotes || []).filter(q => q.accountId === customer.id || q.customerId === customer.id);
  const accountTasks = (state.tasks || []).filter(t => t.accountId === customer.id || t.customerId === customer.id);
  const accountActivities = (state.activities || []).filter(a => a.accountId === customer.id || a.customerId === customer.id);
  const accountNotes = (state.customerNotes || []).filter((n: any) => n.accountId === customer.id || n.customerId === customer.id);
  const accountPayments = (state.payments || []).filter(p => p.accountId === customer.id || p.customerId === customer.id);
  const accountOpportunities = (state.opportunities || []).filter(o => o.accountId === customer.id);
  const accountCases = (state.cases || []).filter((c: any) => c.accountId === customer.id);
  const accountAuditLogs = (state.auditLogs || []).filter(l => l.entityId === customer.id || (l.details && l.details.includes(customer.name)));
  
  const parentAccount = customer.parentAccountId ? state.accounts?.find(a => a.id === customer.parentAccountId) : null;
  const childAccounts = (state.accounts || []).filter(a => a.parentAccountId === customer.id);
  const route = customer.routeId ? (state.routes || []).find((r: any) => r.id === customer.routeId) : null;

  const totalQuotesValue = accountQuotes.reduce((acc, q) => acc + (q.totalAmount || 0), 0);
  const totalPaid = accountPayments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const currentBalance = Math.max(0, totalQuotesValue - totalPaid);

  const customerInvoices = (state.invoices || []).filter(i => (i.accountId === customer.id || i.customerId === customer.id) && i.status !== 'PAID');
  let customerOverdue = 0;
  let maxOverdueDays = 0;
  customerInvoices.forEach(inv => {
    const days = calculateDaysOverdue(inv.dueDate);
    if (days > 0) {
      const rem = inv.balance !== undefined ? inv.balance : (inv.totalAmount - (inv.paidAmount || 0));
      customerOverdue += rem;
      if (days > maxOverdueDays) maxOverdueDays = days;
    }
  });
  const bouncedChequesCount = (state.cheques || []).filter(c => (c as any).accountId === customer.id && (c.status === 'BOUNCED' || (c as any).status === 'RETURNED')).length;
  const customerRisk = calculateCustomerRiskScore(customer, customerOverdue, maxOverdueDays, bouncedChequesCount);

  const unifiedTimeline = useMemo(() => {
    const list: Array<{
      id: string;
      title: string;
      description?: string;
      date: string;
      type: 'QUOTE' | 'TASK' | 'ACTIVITY' | 'NOTE' | 'PAYMENT' | 'OPPORTUNITY' | 'CASE' | 'AUDIT';
      icon: any;
      color: string;
    }> = [];

    accountQuotes.forEach(q => {
      list.push({
        id: `q_${q.id}`,
        title: `پیش‌فاکتور ${q.quoteNumber}`,
        description: `مبلغ: ${formatCurrency(q.totalAmount)} ریال | وضعیت: ${q.status}`,
        date: q.createdAt,
        type: 'QUOTE',
        icon: FileText,
        color: 'text-primary bg-primary/10'
      });
    });

    accountActivities.forEach(a => {
      list.push({
        id: `act_${a.id}`,
        title: `فعالیت: ${a.title}`,
        description: a.description,
        date: a.dateTime,
        type: 'ACTIVITY',
        icon: ActivityIcon,
        color: 'text-[#0284C7] bg-[#F0F9FF]'
      });
    });

    accountNotes.forEach((n: any) => {
      list.push({
        id: `note_${n.id}`,
        title: 'ثبت سابقه و یادداشت مشتری',
        description: n.content,
        date: n.createdAt,
        type: 'NOTE',
        icon: MessageSquare,
        color: 'text-[#D97706] bg-[#FFFBEB]'
      });
    });

    accountTasks.forEach(t => {
      list.push({
        id: `tsk_${t.id}`,
        title: `وظیفه: ${t.title}`,
        description: `مهلت: ${formatAppDate(t.dueDate, state.settings?.locale)} | وضعیت: ${t.status}`,
        date: t.createdAt,
        type: 'TASK',
        icon: CheckSquare,
        color: 'text-[#166534] bg-[#F0FDF4]'
      });
    });

    accountPayments.forEach(p => {
      list.push({
        id: `pay_${p.id}`,
        title: `وصولی و تسویه: ${formatCurrency(p.amount)} ریال`,
        description: `شیوه پرداخت: ${p.method || 'واریز بانکی'} | وضعیت: ${p.status}`,
        date: p.date,
        type: 'PAYMENT',
        icon: Wallet,
        color: 'text-[#166534] bg-[#DCFCE7]'
      });
    });

    accountOpportunities.forEach(o => {
      list.push({
        id: `opp_${o.id}`,
        title: `فرصت تجاری: ${o.title}`,
        description: `مبلغ: ${formatCurrency(o.amount)} ریال | مرحله: ${o.stage}`,
        date: o.createdAt,
        type: 'OPPORTUNITY',
        icon: TrendingUp,
        color: 'text-primary bg-primary/10'
      });
    });

    accountCases.forEach((c: any) => {
      list.push({
        id: `cs_${c.id}`,
        title: `پرونده خدمات: ${c.subject}`,
        description: `شماره: ${c.caseNumber} | اولویت: ${c.priority} | وضعیت: ${c.status}`,
        date: c.createdAt,
        type: 'CASE',
        icon: ShieldAlert,
        color: 'text-[#991B1B] bg-[#FEF2F2]'
      });
    });

    accountAuditLogs.forEach(l => {
      list.push({
        id: `log_${l.id}`,
        title: `عملیات سیستمی: ${l.action}`,
        description: `${l.details} توسط ${l.actor}`,
        date: l.createdAt,
        type: 'AUDIT',
        icon: History,
        color: 'text-text-secondary bg-canvas'
      });
    });

    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [
    accountQuotes, accountActivities, accountNotes, accountTasks, 
    accountPayments, accountOpportunities, accountCases, accountAuditLogs, state.settings?.locale
  ]);

  const resolveMentions = (selectedIds: string[]): Mention[] => {
    return selectedIds.map(id => {
      const u = state.users?.find(x => x.id === id);
      if (u) return { id, type: 'USER', display: `@${u.name}` };
      const g = (state.groups || []).find(x => x.id === id);
      if (g) return { id, type: 'GROUP', display: `@${g.name}` };
      return { id, type: 'CUSTOMER', display: '@مشتری' };
    });
  };

  const handleDynamicActivitySubmit = (values: Record<string, any>) => {
    const actType = values.activityType || 'CALL';
    const descriptionParts = [
      values.description?.trim(),
      values.visitLocationType ? `[محل ویزیت: ${values.visitLocationType === 'STORE' ? 'فروشگاه' : values.visitLocationType === 'OFFICE' ? 'دفتر مرکزی' : 'انبار'}]` : null,
      values.outcome ? `[نتیجه: ${values.outcome}]` : null
    ].filter(Boolean);

    const newAct: Activity = {
      id: generateId(),
      accountId: customer.id,
      customerId: customer.id,
      type: actType,
      title: String(values.title).trim(),
      description: descriptionParts.join(' - '),
      mentions: [],
      dateTime: new Date().toISOString(),
      ownerId: state.currentUserId || 'usr_sales'
    };

    updateState(draft => {
      if (!draft.activities) draft.activities = [];
      draft.activities.unshift(newAct);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'ACTIVITY_LOGGED',
        entityType: 'ACTIVITY',
        entityId: newAct.id,
        details: `فعالیت ${newAct.type} با عنوان "${newAct.title}" برای حساب ${customer.name} از طریق موتور فرم‌های پویا ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsActivityModalOpen(false);
  };

  const handleDynamicNoteSubmit = (values: Record<string, any>) => {
    const newNote: CustomerNote = {
      id: generateId(),
      accountId: customer.id,
      content: String(values.content).trim(),
      authorId: state.currentUserId || 'usr_sales',
      mentions: [],
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.customerNotes) draft.customerNotes = [];
      draft.customerNotes.unshift(newNote);
      processEntityMentions(customer.name, 'یادداشت مشتری', newNote.mentions, state, draft, 'customers');
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'NOTE_ADDED',
        entityType: 'CUSTOMER_NOTE',
        entityId: newNote.id,
        details: `سابقه جدید [${values.category || 'عمومی'}]${values.isImportant ? ' [پین شده]' : ''} برای حساب ${customer.name} ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsNoteModalOpen(false);
  };

  const handleDynamicTaskSubmit = (values: Record<string, any>) => {
    const newTask: CustomerTask = {
      id: generateId(),
      accountId: customer.id,
      customerId: customer.id,
      title: String(values.title).trim(),
      description: String(values.description || '').trim(),
      dueDate: values.dueDate || new Date().toISOString().split('T')[0],
      status: 'OPEN',
      priority: values.priority || 'NORMAL',
      slaStatus: 'ON_TRACK',
      assigneeType: 'USER',
      assigneeId: values.assigneeId || state.currentUserId || '',
      mentions: [],
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.tasks) draft.tasks = [];
      draft.tasks.unshift(newTask);
      processTaskCollaborationEvents(newTask, state, draft, true);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'TASK_CREATED',
        entityType: 'TASK',
        entityId: newTask.id,
        details: `وظیفه "${newTask.title}" [${values.taskCategory || 'پیگیری'}] برای حساب ${customer.name} از طریق موتور فرم‌های پویا ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsTaskModalOpen(false);
  };

  const handleDynamicOppSubmit = (values: Record<string, any>) => {
    const amt = Number(values.amount) || 0;
    const newOpp: Opportunity = {
      id: generateId(),
      accountId: customer.id,
      title: String(values.title).trim(),
      amount: amt,
      stage: values.stage || 'DISCOVERY',
      expectedCloseDate: values.expectedCloseDate,
      ownerId: state.currentUserId || 'usr_sales',
      createdAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.opportunities) draft.opportunities = [];
      draft.opportunities.unshift(newOpp);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'OPPORTUNITY_CREATED',
        entityType: 'OPPORTUNITY',
        entityId: newOpp.id,
        details: `فرصت تجاری "${newOpp.title}" به ارزش ${amt.toLocaleString('fa-IR')} ریال ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsOppModalOpen(false);
  };

  const handleDynamicCaseSubmit = (values: Record<string, any>) => {
    const newCase: Case = {
      id: generateId(),
      caseNumber: `CS-${Date.now().toString().slice(-4)}`,
      accountId: customer.id,
      subject: String(values.subject).trim(),
      description: `${String(values.description || '').trim()} [دسته‌بندی: ${values.caseType || 'عمومی'}] [مهلت SLA: ${values.slaHours || 24} ساعت]`.trim(),
      status: 'NEW',
      priority: values.priority || 'NORMAL',
      ownerId: state.currentUserId || 'usr_admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    updateState(draft => {
      if (!draft.cases) draft.cases = [];
      draft.cases.unshift(newCase);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'CASE_CREATED',
        entityType: 'CASE',
        entityId: newCase.id,
        details: `پرونده خدمات ${newCase.caseNumber} با موضوع "${newCase.subject}" ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsCaseModalOpen(false);
  };

  const handleDynamicPaymentSubmit = (values: Record<string, any>) => {
    const amt = Number(values.amount) || 0;
    const isCheque = values.method === 'SAYAD_CHEQUE';
    const methodDisplay = isCheque ? 'چک صیادی' : values.method === 'POS' ? 'کارت‌خوان (POS)' : values.method === 'CASH' ? 'وجه نقد' : 'واریز نقدی / حواله';

    const newPayment: CustomerPayment = {
      id: generateId(),
      accountId: customer.id,
      customerId: customer.id,
      amount: amt,
      date: values.date || new Date().toISOString().split('T')[0],
      method: methodDisplay,
      status: isCheque ? 'REGISTERED' : 'CLEARED'
    };

    updateState(draft => {
      if (!draft.payments) draft.payments = [];
      draft.payments.unshift(newPayment as any);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'PAYMENT_RECORDED',
        entityType: 'PAYMENT',
        entityId: newPayment.id,
        details: `وصولی به مبلغ ${amt.toLocaleString('fa-IR')} ریال (${methodDisplay}${values.sayadNumber ? ` - صیاد: ${values.sayadNumber}` : ''}) ثبت شد`,
        actor: state.users?.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });

    setIsPaymentModalOpen(false);
  };

  const handleCreateNewQuote = () => {
    const newQuoteNumber = `QT-${Date.now().toString().slice(-6)}`;
    const newQuoteId = generateId();
    updateState(draft => {
      if (!draft.quotes) draft.quotes = [];
      draft.quotes.unshift({
        id: newQuoteId,
        quoteNumber: newQuoteNumber,
        accountId: customer.id,
        ownerId: state.currentUserId || 'usr_sales',
        status: 'DRAFT',
        lines: [],
        totalAmount: 0,
        marginPercent: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as any);
      draft.activeContextAccountId = customer.id;
    });
    if (setActiveTab) setActiveTab('quotes');
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas">
      
      <div className="shrink-0 px-4 pt-4 pb-2 z-10 bg-canvas">
        <button 
          onClick={onBack} 
          className="flex items-center gap-1.5 text-xs font-bold text-text-secondary hover:text-text-main transition-colors mb-3 cursor-pointer"
        >
          <ChevronRight size={16} /> بازگشت به لیست حساب‌ها
        </button>

        <Card padding="lg" className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center gap-4">
              <Avatar name={customer.name} size="lg" />
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-extrabold text-text-main tracking-tight">{customer.name}</h2>
                  {customer.hierarchyLevel && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-primary/10 text-primary">
                      {customer.hierarchyLevel}
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-text-secondary">
                  <span className="font-mono bg-canvas px-2 py-0.5 rounded text-[11px] font-bold text-text-main">
                    {customer.code || '-'}
                  </span>
                  {customer.phone && (
                    <span className="font-mono flex items-center gap-1">
                      <Phone size={12} /> {customer.phone}
                    </span>
                  )}
                  {route && (
                    <span className="flex items-center gap-1 font-semibold text-primary">
                      <GitBranch size={12} /> مسیر: {route.name}
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 text-xs font-bold rounded-lg ${customer.status === 'ACTIVE' ? 'bg-[#F0FDF4] text-[#166534] border border-[#BBF7D0]' : 'bg-canvas text-text-secondary'}`}>
                {customer.status === 'ACTIVE' ? 'حساب فعال' : customer.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-3 border-t border-[#E2E8F0]">
            <div className="p-2.5 bg-canvas rounded-xl">
              <span className="text-[10px] text-text-secondary font-medium block">مانده بدهی تجاری</span>
              <SecureField state={state} entityType="Account" field="balance">
                {(mode) => (
                  <strong className={`text-sm font-mono font-bold block mt-0.5 ${currentBalance > 0 ? 'text-[#991B1B]' : 'text-text-main'}`}>
                    {mode === 'SEE' ? '***' : formatCurrency(currentBalance)} ریال
                  </strong>
                )}
              </SecureField>
            </div>
            <div className="p-2.5 bg-canvas rounded-xl">
              <span className="text-[10px] text-text-secondary font-medium block">سقف اعتبار مصوب</span>
              <SecureField state={state} entityType="Account" field="creditLimit">
                {(mode) => (
                  <strong className="text-sm font-mono font-bold text-primary block mt-0.5">
                    {mode === 'SEE' ? 'محدود شده' : `${formatCurrency(customer.creditLimit || 0)} ریال`}
                  </strong>
                )}
              </SecureField>
            </div>
            <div className="p-2.5 bg-canvas rounded-xl">
              <span className="text-[10px] text-text-secondary font-medium block">پیش‌فاکتورها</span>
              <strong className="text-sm font-mono font-bold text-text-main block mt-0.5">
                {accountQuotes.length} فقره ({formatCurrency(totalQuotesValue)})
              </strong>
            </div>
            <div className="p-2.5 bg-canvas rounded-xl">
              <span className="text-[10px] text-text-secondary font-medium block">پیگیری‌ها و تسک‌ها</span>
              <strong className="text-sm font-mono font-bold text-text-main block mt-0.5">
                {accountTasks.filter(t => t.status !== 'COMPLETED').length} تسک باز
              </strong>
            </div>
            <div className={`p-2.5 rounded-xl border ${
              customerRisk.level === 'CRITICAL' ? 'bg-red-50/70 border-red-200' :
              customerRisk.level === 'HIGH' ? 'bg-amber-50/70 border-amber-200' :
              'bg-canvas border-slate-200'
            }`}>
              <span className="text-[10px] text-text-secondary font-medium block">ریسک اعتباری و وصول</span>
              <strong className={`text-sm font-mono font-bold block mt-0.5 ${
                customerRisk.level === 'CRITICAL' ? 'text-red-700' :
                customerRisk.level === 'HIGH' ? 'text-amber-700' :
                customerRisk.level === 'MEDIUM' ? 'text-blue-700' : 'text-emerald-700'
              }`}>
                {customerRisk.score}٪ ({
                  customerRisk.level === 'CRITICAL' ? 'بحرانی' :
                  customerRisk.level === 'HIGH' ? 'پرریسک' :
                  customerRisk.level === 'MEDIUM' ? 'متوسط' : 'کم‌ریسک'
                })
              </strong>
            </div>
          </div>

          {parentAccount && (
            <div className="p-2.5 bg-primary/5 border border-primary/20 rounded-xl text-xs flex justify-between items-center text-primary">
              <span className="flex items-center gap-1.5">
                <Building2 size={14} className="text-primary" />
                حساب مادر / دفتر مرکزی: <strong>{parentAccount.name}</strong>
              </span>
              <button 
                onClick={() => updateState(d => { d.activeContextAccountId = parentAccount.id; })}
                className="font-bold text-primary hover:text-primary-hover flex items-center gap-0.5 cursor-pointer"
              >
                مشاهده حساب مادر <ArrowUpRight size={13} />
              </button>
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1 border-t border-[#E2E8F0]">
            <Button size="sm" variant="primary" onClick={() => setIsActivityModalOpen(true)} icon={<ActivityIcon className="w-3.5 h-3.5" />}>
              ثبت فعالیت
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsNoteModalOpen(true)} icon={<MessageSquare className="w-3.5 h-3.5" />}>
              سابقه / یادداشت
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsTaskModalOpen(true)} icon={<CheckSquare className="w-3.5 h-3.5" />}>
              تسک پیگیری
            </Button>
            <Button size="sm" variant="outline" onClick={handleCreateNewQuote} icon={<Plus className="w-3.5 h-3.5" />}>
              صدور پیش‌فاکتور (CPQ)
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsOppModalOpen(true)} icon={<TrendingUp className="w-3.5 h-3.5" />}>
              فرصت جدید
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsCaseModalOpen(true)} icon={<ShieldAlert className="w-3.5 h-3.5 text-amber-600" />}>
              تیکت پشتیبانی
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsPaymentModalOpen(true)} icon={<Wallet className="w-3.5 h-3.5 text-[#166534]" />}>
              ثبت وصولی
            </Button>
          </div>
        </Card>
      </div>

      <div className="shrink-0 px-4 border-b border-[#E2E8F0] overflow-x-auto no-scrollbar">
        <div className="flex gap-6 min-w-max">
          {[
            { id: 'OVERVIEW', label: 'اطلاعات پایه و ساختار' },
            { id: 'TIMELINE', label: `تایم‌لاین جامع (${unifiedTimeline.length})` },
            { id: 'ACTIVITIES', label: `فعالیت‌ها (${accountActivities.length})` },
            { id: 'NOTES', label: `سوابق و یادداشت‌ها (${accountNotes.length})` },
            { id: 'QUOTES', label: `پیش‌فاکتورها (${accountQuotes.length})` },
            { id: 'OPPORTUNITIES', label: `فرصت‌ها (${accountOpportunities.length})` },
            { id: 'TASKS', label: `وظایف (${accountTasks.length})` },
            { id: 'CASES', label: `پشتیبانی (${accountCases.length})` },
            { id: 'FINANCE', label: `مالی و تسویه‌ها (${accountPayments.length})` },
            { id: 'AUDIT', label: `ردپای عملیات (${accountAuditLogs.length})` }
          ].map(t => {
            const isActive = activeSubTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveSubTab(t.id as TabKey)}
                aria-current={isActive ? 'page' : undefined}
                className={`pb-3 text-sm transition-all relative whitespace-nowrap cursor-pointer border-b-[3px] ${isActive ? 'border-primary text-primary font-extrabold' : 'border-transparent text-text-secondary font-medium hover:text-text-main hover:border-[#CBD5E1]'}`}
              >
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 px-4 py-4 pb-12 space-y-4">
        {activeSubTab === 'OVERVIEW' && (
          <div className="space-y-4">
            <Card padding="md" className="space-y-3">
              <h3 className="text-sm font-bold text-text-main flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-primary" /> مخاطبین رسمی حساب (Contacts)
              </h3>
              <div className="divide-y divide-[#E2E8F0]">
                {(customer.contacts || []).map(contact => (
                  <div key={contact.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-text-main font-bold">{contact.name}</strong>
                        {contact.isPrimary && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-primary/10 text-primary">
                            مخاطب اصلی
                          </span>
                        )}
                      </div>
                      <span className="text-text-secondary mt-0.5 block">{contact.title || 'مسئول ارتباط'}</span>
                    </div>
                    <div className="text-left font-mono text-text-main">
                      {contact.phone && <div>{contact.phone}</div>}
                      {contact.email && <div className="text-text-secondary text-[11px]">{contact.email}</div>}
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card padding="md" className="space-y-3">
              <h3 className="text-sm font-bold text-text-main flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-primary" /> ساختار سازمانی و شعب (Hierarchy)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-canvas rounded-xl">
                  <span className="text-text-secondary block text-[11px]">حساب مادر:</span>
                  <span className="font-bold text-text-main mt-0.5 block">
                    {parentAccount ? parentAccount.name : 'این حساب در راس سلسله‌مراتب قرار دارد (Headquarter)'}
                  </span>
                </div>
                <div className="p-3 bg-canvas rounded-xl">
                  <span className="text-text-secondary block text-[11px]">شعب و زیرمجموعه‌ها:</span>
                  <span className="font-bold text-text-main mt-0.5 block">
                    {childAccounts.length > 0 ? `${childAccounts.length} شعبه / فروشگاه ثبت‌شده` : 'فاقد زیرمجموعه'}
                  </span>
                </div>
              </div>

              {childAccounts.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  <span className="text-[11px] font-bold text-text-secondary block">فهرست شعب تابعه:</span>
                  {childAccounts.map(child => (
                    <div key={child.id} className="p-2 border border-[#E2E8F0] rounded-lg flex justify-between items-center text-xs bg-white">
                      <span>{child.name} ({child.code || '-'})</span>
                      <button 
                        onClick={() => updateState(d => { d.activeContextAccountId = child.id; })}
                        className="text-primary hover:text-primary-hover font-bold text-[11px]"
                      >
                        ورود به پرونده ۳۶۰
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card padding="md" className="space-y-3">
              <h3 className="text-sm font-bold text-text-main">مشخصات حقوقی و مالیاتی</h3>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-canvas rounded-xl">
                  <span className="text-text-secondary block text-[11px]">شناسه / کد ملی:</span>
                  <span className="font-mono font-bold text-text-main mt-0.5 block">{customer.nationalId || '-'}</span>
                </div>
                <div className="p-3 bg-canvas rounded-xl">
                  <span className="text-text-secondary block text-[11px]">آدرس کامل ثبت‌شده:</span>
                  <span className="font-medium text-text-main mt-0.5 block">{customer.address || '-'}</span>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeSubTab === 'TIMELINE' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-text-secondary px-1">جریان زمانی یکپارچه رویدادهای مشتری</h3>
            {unifiedTimeline.length > 0 ? (
              <div className="relative border-r-2 border-[#E2E8F0] mr-3 pr-4 space-y-4">
                {unifiedTimeline.map(ev => {
                  const Icon = ev.icon;
                  return (
                    <div key={ev.id} className="relative group">
                      <div className={`absolute -right-[25px] top-1 w-6 h-6 rounded-full flex items-center justify-center border-2 border-white ${ev.color}`}>
                        <Icon size={12} />
                      </div>
                      <div className="p-3 bg-white border border-[#E2E8F0] rounded-xl hover:shadow-[0_2px_10px_rgba(31,33,40,0.04)] transition-all">
                        <div className="flex justify-between items-start">
                          <strong className="text-xs font-bold text-text-main">{ev.title}</strong>
                          <span className="text-[10px] text-text-secondary font-mono">
                            {formatAppDate(ev.date, state.settings?.locale)}
                          </span>
                        </div>
                        {ev.description && (
                          <p className="text-xs text-text-secondary mt-1 leading-relaxed">{ev.description}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <EmptyState icon={<History className="w-8 h-8 text-text-secondary opacity-50" />} title="رویدادی ثبت نشده است" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'ACTIVITIES' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">فعالیت‌های ثبت‌شده ({accountActivities.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsActivityModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                ثبت فعالیت جدید
              </Button>
            </div>
            {accountActivities.length > 0 ? (
              accountActivities.map(a => (
                <Card key={a.id} padding="md" className="space-y-1.5">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#F0F9FF] text-[#075985]">
                        {a.type}
                      </span>
                      <strong className="text-sm font-bold text-text-main">{a.title}</strong>
                    </div>
                    <span className="text-[11px] font-mono text-text-secondary">
                      {formatAppDate(a.dateTime, state.settings?.locale)}
                    </span>
                  </div>
                  {a.description && <p className="text-xs text-text-secondary">{a.description}</p>}
                  {a.mentions && a.mentions.length > 0 && (
                    <div className="flex gap-1 pt-1">
                      {a.mentions.map((m: any) => (
                        <span key={m.id} className="text-[10px] font-mono bg-primary/10 text-primary px-1.5 py-0.5 rounded border border-primary/20">
                          {m.display}
                        </span>
                      ))}
                    </div>
                  )}
                </Card>
              ))
            ) : (
              <EmptyState icon={<ActivityIcon className="w-8 h-8 text-text-secondary opacity-50" />} title="فعالیتی یافت نشد" description="اولین ویزیت، تماس یا جلسه را ثبت کنید." />
            )}
          </div>
        )}

        {activeSubTab === 'NOTES' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">سوابق و یادداشت‌های استراتژیک ({accountNotes.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsNoteModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                ثبت سابقه جدید
              </Button>
            </div>
            {accountNotes.length > 0 ? (
              accountNotes.map((n: any) => {
                const author = state.users?.find(u => u.id === n.authorId);
                return (
                  <Card key={n.id} padding="md" className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-text-main flex items-center gap-1.5">
                        <User size={13} className="text-text-secondary" />
                        {author ? author.name : 'کاربر سیستم'}
                      </span>
                      <span className="text-[10px] font-mono text-text-secondary">
                        {formatAppDate(n.createdAt, state.settings?.locale)}
                      </span>
                    </div>
                    <p className="text-xs text-text-main leading-relaxed bg-canvas p-2.5 rounded-xl border border-[#E2E8F0]">
                      {n.content}
                    </p>
                    {n.mentions && n.mentions.length > 0 && (
                      <div className="flex gap-1">
                        {n.mentions.map((m: any) => (
                          <span key={m.id} className="text-[10px] font-mono bg-[#F0F9FF] text-[#075985] px-1.5 py-0.5 rounded border border-[#BAE6FD]">
                            {m.display}
                          </span>
                        ))}
                      </div>
                    )}
                  </Card>
                );
              })
            ) : (
              <EmptyState icon={<MessageSquare className="w-8 h-8 text-text-secondary opacity-50" />} title="هیچ یادداشتی ثبت نشده است" description="سابقه و جزئیات مذاکرات قبلی را اینجا یادداشت کنید." />
            )}
          </div>
        )}

        {activeSubTab === 'QUOTES' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">پیش‌فاکتورها و پیشنهادهای CPQ ({accountQuotes.length})</h3>
              <Button size="sm" variant="primary" onClick={handleCreateNewQuote} icon={<Plus className="w-3.5 h-3.5" />}>
                صدور پیش‌فاکتور جدید
              </Button>
            </div>
            {accountQuotes.length > 0 ? (
              accountQuotes.map(q => (
                <Card key={q.id} padding="md" className="flex justify-between items-center">
                  <div>
                    <strong className="text-sm font-bold text-text-main font-mono">{q.quoteNumber}</strong>
                    <div className="text-xs text-text-secondary mt-1 font-mono">
                      {formatAppDate(q.createdAt, state.settings?.locale)} | اقلام: {q.lines?.length || 0}
                    </div>
                  </div>
                  <div className="text-left flex items-center gap-3">
                    <div>
                      <strong className="text-sm font-bold text-text-main font-mono block">{formatCurrency(q.totalAmount)} ریال</strong>
                      <span className="text-[10px] text-text-secondary font-mono block">مارجین: {q.marginPercent}٪</span>
                    </div>
                    <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-canvas text-text-secondary">{q.status}</span>
                  </div>
                </Card>
              ))
            ) : (
              <EmptyState icon={<FileText className="w-8 h-8 text-text-secondary opacity-50" />} title="پیش‌فاکتوری ثبت نشده است" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'OPPORTUNITIES' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">فرصت‌های تجاری و پروپوزال‌ها ({accountOpportunities.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsOppModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                ثبت فرصت تجاری
              </Button>
            </div>
            {accountOpportunities.length > 0 ? (
              accountOpportunities.map(opp => (
                <Card key={opp.id} padding="md" className="flex justify-between items-center">
                  <div>
                    <strong className="text-sm font-bold text-text-main">{opp.title}</strong>
                    <div className="text-xs text-text-secondary mt-1 flex items-center gap-2">
                      <span className="font-mono">{formatCurrency(opp.amount)} ریال</span>
                      <span>•</span>
                      <span>بستن احتمالی: {formatAppDate(opp.expectedCloseDate, state.settings?.locale)}</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-primary/10 text-primary">
                    {opp.stage}
                  </span>
                </Card>
              ))
            ) : (
              <EmptyState icon={<TrendingUp className="w-8 h-8 text-text-secondary opacity-50" />} title="فرصت تجاری ثبت نشده است" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'TASKS' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">وظایف و پیگیری‌ها ({accountTasks.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsTaskModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                تعریف وظیفه جدید
              </Button>
            </div>
            {accountTasks.length > 0 ? (
              accountTasks.map(t => {
                let assigneeName = 'ناشناس';
                if (t.assigneeType === 'GROUP') {
                  assigneeName = state.groups?.find(g => g.id === t.assigneeId)?.name || 'گروه نامشخص';
                } else {
                  assigneeName = state.users?.find(u => u.id === t.assigneeId)?.name || 'کارشناس نامشخص';
                }

                return (
                  <Card key={t.id} padding="md" className="flex justify-between items-center">
                    <div>
                      <h4 className="text-sm font-bold text-text-main">{t.title}</h4>
                      {t.description && <p className="text-xs text-text-secondary mt-0.5">{t.description}</p>}
                      <div className="text-xs text-text-secondary mt-1 flex flex-wrap gap-2">
                        <span className="font-mono flex items-center gap-1">
                          <Clock size={12} /> {formatAppDate(t.dueDate, state.settings?.locale)}
                        </span>
                        <span>•</span>
                        <span className="text-primary font-medium">
                          مسئول: {assigneeName} ({t.assigneeType === 'GROUP' ? 'تیمی' : 'فردی'})
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-1 rounded bg-canvas text-text-secondary">{t.status}</span>
                  </Card>
                );
              })
            ) : (
              <EmptyState icon={<CheckSquare className="w-8 h-8 text-text-secondary opacity-50" />} title="تسک بازی وجود ندارد" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'CASES' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">تیکت‌ها و شکایات خدمات مشتری ({accountCases.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsCaseModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                ثبت مورد خدمات
              </Button>
            </div>
            {accountCases.length > 0 ? (
              accountCases.map((c: any) => (
                <Card key={c.id} padding="md" className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-text-main">{c.subject}</h4>
                    <span className="text-xs text-text-secondary font-mono mt-1 block">شماره: {c.caseNumber}</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-1 rounded bg-canvas text-text-secondary">{c.status}</span>
                </Card>
              ))
            ) : (
              <EmptyState icon={<ShieldAlert className="w-8 h-8 text-text-secondary opacity-50" />} title="بدون سابقه پشتیبانی" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'FINANCE' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-xs font-bold text-text-secondary">اسناد دریافت و وصولی‌ها ({accountPayments.length})</h3>
              <Button size="sm" variant="primary" onClick={() => setIsPaymentModalOpen(true)} icon={<Plus className="w-3.5 h-3.5" />}>
                ثبت تسویه جدید
              </Button>
            </div>
            {accountPayments.length > 0 ? (
              accountPayments.map(p => (
                <Card key={p.id} padding="sm" className="flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-text-main">{p.method || 'واریز نقدی'}</span>
                    <span className="text-text-secondary font-mono block text-[11px] mt-0.5">{formatAppDate(p.date, state.settings?.locale)}</span>
                  </div>
                  <div className="text-left font-mono">
                    <span className="font-bold text-primary block">{formatCurrency(p.amount)} ریال</span>
                    <span className="text-[10px] text-text-secondary font-semibold">{p.status}</span>
                  </div>
                </Card>
              ))
            ) : (
              <EmptyState icon={<Wallet className="w-8 h-8 text-text-secondary opacity-50" />} title="سند پرداختی یافت نشد" description="" />
            )}
          </div>
        )}

        {activeSubTab === 'AUDIT' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-text-secondary px-1">تاریخچه تغییرات و رخدادهای سیستمی (Audit Trail)</h3>
            {accountAuditLogs.length > 0 ? (
              accountAuditLogs.map(l => (
                <Card key={l.id} padding="sm" className="text-xs space-y-1">
                  <div className="flex justify-between text-text-secondary font-mono text-[10px]">
                    <span className="font-bold text-text-main">{l.action}</span>
                    <span>{formatAppDate(l.createdAt, state.settings?.locale)}</span>
                  </div>
                  <p className="text-text-main">{l.details}</p>
                  <span className="text-[10px] text-text-secondary block">مجری: {l.actor}</span>
                </Card>
              ))
            ) : (
              <EmptyState icon={<History className="w-8 h-8 text-text-secondary opacity-50" />} title="لاگی یافت نشد" description="" />
            )}
          </div>
        )}
      </div>

      {/* Action Modals Powered by Central Dynamic Form Engine */}
      {isActivityModalOpen && (
        <Modal 
          isOpen={isActivityModalOpen} 
          onClose={() => setIsActivityModalOpen(false)}
          title="ثبت فعالیت و تعامل با مشتری (موتور فرم‌های پویا)"
        >
          <DynamicFormRenderer
            schema={ACTIVITY_FORM_SCHEMA}
            initialValues={{
              activityType: 'CALL',
              outcome: 'FOLLOW_UP',
              visitLocationType: 'STORE'
            }}
            onSubmit={handleDynamicActivitySubmit}
            onCancel={() => setIsActivityModalOpen(false)}
            submitLabel="ثبت و ذخیره فعالیت"
          />
        </Modal>
      )}

      {isNoteModalOpen && (
        <Modal
          isOpen={isNoteModalOpen}
          onClose={() => setIsNoteModalOpen(false)}
          title="ثبت سابقه و یادداشت مشتری (موتور فرم‌های پویا)"
        >
          <DynamicFormRenderer
            schema={NOTE_FORM_SCHEMA}
            initialValues={{
              category: 'GENERAL',
              isImportant: false
            }}
            onSubmit={handleDynamicNoteSubmit}
            onCancel={() => setIsNoteModalOpen(false)}
            submitLabel="ذخیره سابقه و یادداشت"
          />
        </Modal>
      )}

      {isTaskModalOpen && (
        <Modal
          isOpen={isTaskModalOpen}
          onClose={() => setIsTaskModalOpen(false)}
          title="تعریف وظیفه پیگیری (تسک) با موتور فرم‌های پویا"
        >
          <DynamicFormRenderer
            schema={createTaskFormSchema(state.users || [])}
            initialValues={{
              priority: 'NORMAL',
              dueDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
              assigneeId: state.currentUserId || state.users?.[0]?.id || '',
              taskCategory: 'FOLLOW_UP'
            }}
            onSubmit={handleDynamicTaskSubmit}
            onCancel={() => setIsTaskModalOpen(false)}
            submitLabel="ایجاد وظیفه پیگیری"
          />
        </Modal>
      )}

      {isOppModalOpen && (
        <Modal
          isOpen={isOppModalOpen}
          onClose={() => setIsOppModalOpen(false)}
          title="ثبت فرصت تجاری جدید (موتور فرم‌های پویا)"
        >
          <DynamicFormRenderer
            schema={OPPORTUNITY_FORM_SCHEMA}
            initialValues={{
              stage: 'DISCOVERY',
              probability: '50',
              expectedCloseDate: new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]
            }}
            onSubmit={handleDynamicOppSubmit}
            onCancel={() => setIsOppModalOpen(false)}
            submitLabel="ثبت فرصت تجاری"
          />
        </Modal>
      )}

      {isCaseModalOpen && (
        <Modal
          isOpen={isCaseModalOpen}
          onClose={() => setIsCaseModalOpen(false)}
          title="ثبت پرونده خدمات و پشتیبانی (موتور فرم‌های پویا)"
        >
          <DynamicFormRenderer
            schema={SERVICE_CASE_SCHEMA}
            initialValues={{
              priority: 'NORMAL',
              caseType: 'LOGISTICS',
              slaHours: '24'
            }}
            onSubmit={handleDynamicCaseSubmit}
            onCancel={() => setIsCaseModalOpen(false)}
            submitLabel="ثبت پرونده و تیکت"
          />
        </Modal>
      )}

      {isPaymentModalOpen && (
        <Modal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          title="ثبت سند وصولی و دریافت وجه (موتور فرم‌های پویا)"
        >
          <DynamicFormRenderer
            schema={PAYMENT_RECEIPT_SCHEMA}
            initialValues={{
              method: 'TRANSFER',
              date: new Date().toISOString().split('T')[0]
            }}
            onSubmit={handleDynamicPaymentSubmit}
            onCancel={() => setIsPaymentModalOpen(false)}
            submitLabel="ثبت سند وصولی"
          />
        </Modal>
      )}

    </div>
  );
}
