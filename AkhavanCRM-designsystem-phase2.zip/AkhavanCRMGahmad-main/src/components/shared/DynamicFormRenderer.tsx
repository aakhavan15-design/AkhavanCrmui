import React, { useState, useEffect } from 'react';
import { 
  DynamicFormSchema, 
  DynamicFormField, 
  shouldFieldDisplay, 
  validateSingleField, 
  validateEntireForm 
} from '../../services/dynamicFormEngine';
import { CustomDatePicker } from '../ui/CustomDatePicker';
import { Button } from '../ui/Button';
import { AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';

interface DynamicFormRendererProps {
  schema: DynamicFormSchema;
  initialValues?: Record<string, any>;
  onSubmit: (values: Record<string, any>) => void;
  onCancel?: () => void;
  submitLabel?: string;
  cancelLabel?: string;
  isSubmitting?: boolean;
}

export function DynamicFormRenderer({
  schema,
  initialValues = {},
  onSubmit,
  onCancel,
  submitLabel = 'ثبت و ذخیره فرم',
  cancelLabel = 'انصراف',
  isSubmitting = false
}: DynamicFormRendererProps) {
  // فرم ولیوز بر اساس دیفالت‌های فیلدها و اینیشال ولیوز
  const [formValues, setFormValues] = useState<Record<string, any>>(() => {
    const vals: Record<string, any> = { ...initialValues };
    schema.fields.forEach(f => {
      if (vals[f.name] === undefined && f.defaultValue !== undefined) {
        vals[f.name] = f.defaultValue;
      }
    });
    return vals;
  });

  useEffect(() => {
    const vals: Record<string, any> = { ...initialValues };
    schema.fields.forEach(f => {
      if (vals[f.name] === undefined && f.defaultValue !== undefined) {
        vals[f.name] = f.defaultValue;
      }
    });
    setFormValues(vals);
    setTouched({});
    setErrors({});
  }, [schema.id, JSON.stringify(initialValues)]);

  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleFieldChange = (field: DynamicFormField, rawValue: any) => {
    let value = rawValue;

    // پاکسازی برای فیلدهای عددی و ریالی
    if (field.type === 'currency' || field.type === 'number') {
      if (typeof rawValue === 'string') {
        value = rawValue.replace(/,/g, '');
      }
    }

    const updatedValues = { ...formValues, [field.name]: value };
    setFormValues(updatedValues);

    // اعتبارسنجی بلادرنگ فیلد تغییریافته
    if (touched[field.name]) {
      const err = validateSingleField(field, value, updatedValues);
      setErrors(prev => {
        const next = { ...prev };
        if (err) next[field.name] = err;
        else delete next[field.name];
        return next;
      });
    }
  };

  const handleBlur = (field: DynamicFormField) => {
    setTouched(prev => ({ ...prev, [field.name]: true }));
    const err = validateSingleField(field, formValues[field.name], formValues);
    setErrors(prev => {
      const next = { ...prev };
      if (err) next[field.name] = err;
      else delete next[field.name];
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // مارک کردن تمامی فیلدها به عنوان تاچ‌شده
    const allTouched: Record<string, boolean> = {};
    schema.fields.forEach(f => { allTouched[f.name] = true; });
    setTouched(allTouched);

    const validation = validateEntireForm(schema, formValues);
    setErrors(validation.errors);

    if (validation.isValid) {
      onSubmit(formValues);
    }
  };

  // فرمت سه‌رقم سه‌رقم برای مبالغ ریالی
  const formatCurrencyDisplay = (val: any) => {
    if (val === undefined || val === null || val === '') return '';
    const num = Number(String(val).replace(/,/g, ''));
    return isNaN(num) ? val : num.toLocaleString('fa-IR');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" dir="rtl">
      {schema.description && (
        <div className="p-3 bg-primary/5 rounded-xl border border-primary/20 text-xs text-text-secondary flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <span>{schema.description}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {schema.fields.map(field => {
          // بررسی شرط نمایش
          if (!shouldFieldDisplay(field, formValues)) {
            return null;
          }

          const isFullWidth = field.colSpan === 2;
          const fieldError = touched[field.name] ? errors[field.name] : null;
          const val = formValues[field.name];

          return (
            <div 
              key={field.id} 
              className={`space-y-1.5 ${isFullWidth ? 'md:col-span-2' : 'md:col-span-1'}`}
            >
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-text-main flex items-center gap-1">
                  <span>{field.label}</span>
                  {field.validation?.required && (
                    <span className="text-red-500 font-bold">*</span>
                  )}
                  {field.unit && (
                    <span className="text-[10px] text-text-secondary font-normal">({field.unit})</span>
                  )}
                </label>
                {field.description && (
                  <span className="text-[10px] text-text-secondary">{field.description}</span>
                )}
              </div>

              {/* رندرهای مختلف بر اساس نوع فیلد */}
              {field.type === 'text' || field.type === 'email' || field.type === 'phone' || field.type === 'nationalCode' ? (
                <input
                  type={field.type === 'email' ? 'email' : 'text'}
                  value={val ?? ''}
                  onChange={e => handleFieldChange(field, e.target.value)}
                  onBlur={() => handleBlur(field)}
                  placeholder={field.placeholder}
                  readOnly={field.readOnly}
                  dir={field.type === 'phone' || field.type === 'email' || field.type === 'nationalCode' ? 'ltr' : 'rtl'}
                  className={`w-full bg-canvas border rounded-xl p-2.5 text-xs text-text-main focus:outline-none transition-all ${
                    fieldError 
                      ? 'border-red-500 focus:border-red-500 focus:ring-1 focus:ring-red-500/20' 
                      : 'border-border/80 focus:border-primary focus:ring-1 focus:ring-primary/20'
                  }`}
                />
              ) : field.type === 'currency' ? (
                <div className="relative">
                  <input
                    type="text"
                    value={formatCurrencyDisplay(val)}
                    onChange={e => handleFieldChange(field, e.target.value)}
                    onBlur={() => handleBlur(field)}
                    placeholder={field.placeholder}
                    dir="ltr"
                    className={`w-full bg-canvas border rounded-xl p-2.5 text-xs font-bold text-text-main text-left pl-12 focus:outline-none transition-all ${
                      fieldError 
                        ? 'border-red-500 focus:border-red-500' 
                        : 'border-border/80 focus:border-primary'
                    }`}
                  />
                  <div className="absolute left-3 top-2.5 text-[11px] font-bold text-text-secondary pointer-events-none">
                    ریال
                  </div>
                </div>
              ) : field.type === 'number' ? (
                <input
                  type="number"
                  value={val ?? ''}
                  onChange={e => handleFieldChange(field, e.target.value)}
                  onBlur={() => handleBlur(field)}
                  placeholder={field.placeholder}
                  dir="ltr"
                  className={`w-full bg-canvas border rounded-xl p-2.5 text-xs text-text-main focus:outline-none transition-all ${
                    fieldError ? 'border-red-500' : 'border-border/80 focus:border-primary'
                  }`}
                />
              ) : field.type === 'textarea' ? (
                <textarea
                  value={val ?? ''}
                  onChange={e => handleFieldChange(field, e.target.value)}
                  onBlur={() => handleBlur(field)}
                  placeholder={field.placeholder}
                  rows={3}
                  className={`w-full bg-canvas border rounded-xl p-2.5 text-xs text-text-main focus:outline-none transition-all ${
                    fieldError ? 'border-red-500' : 'border-border/80 focus:border-primary'
                  }`}
                />
              ) : field.type === 'select' ? (
                <select
                  value={val ?? ''}
                  onChange={e => handleFieldChange(field, e.target.value)}
                  onBlur={() => handleBlur(field)}
                  className={`w-full bg-canvas border rounded-xl p-2.5 text-xs text-text-main font-medium focus:outline-none transition-all ${
                    fieldError ? 'border-red-500' : 'border-border/80 focus:border-primary'
                  }`}
                >
                  <option value="" disabled>-- انتخاب کنید --</option>
                  {field.options?.map(opt => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              ) : field.type === 'jalaliDate' ? (
                <CustomDatePicker
                  value={val ?? ''}
                  onChange={dateStr => handleFieldChange(field, dateStr)}
                  placeholder={field.placeholder || 'انتخاب تاریخ شمسی'}
                />
              ) : field.type === 'boolean' ? (
                <label className="flex items-center gap-3 p-3 bg-canvas/50 rounded-xl border border-border/60 cursor-pointer hover:bg-canvas transition-colors">
                  <input
                    type="checkbox"
                    checked={Boolean(val)}
                    onChange={e => handleFieldChange(field, e.target.checked)}
                    className="w-4 h-4 text-primary rounded-sm border-border focus:ring-primary/20 accent-primary"
                  />
                  <span className="text-xs font-medium text-text-main select-none">{field.placeholder || field.label}</span>
                </label>
              ) : null}

              {/* نمایش خطای اعتبارسنجی */}
              {fieldError && (
                <div className="flex items-center gap-1 text-[11px] text-red-500 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{fieldError}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* اکشن‌های دکمه فرم */}
      <div className="pt-4 border-t border-border flex items-center justify-end gap-2">
        {onCancel && (
          <Button 
            type="button" 
            variant="ghost" 
            size="sm" 
            onClick={onCancel}
            disabled={isSubmitting}
          >
            {cancelLabel}
          </Button>
        )}
        <Button 
          type="submit" 
          variant="primary" 
          size="sm" 
          disabled={isSubmitting}
          className="flex items-center gap-1.5"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isSubmitting ? 'در حال ذخیره‌سازی...' : submitLabel}</span>
        </Button>
      </div>
    </form>
  );
}
