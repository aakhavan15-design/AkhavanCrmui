import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  FileText, CheckSquare, Search, TrendingUp, Bell, Building2, Plus, UserCheck,
  X, Menu, CalendarDays, Home, ChevronLeft, Wallet, FileSpreadsheet
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AppState } from '../types';
import { Avatar } from './ui/Avatar';
import { IconButton } from './ui/Button';
import { NavigationDrawer } from './NavigationDrawer';
import { NavDock } from './NavDock';
import { RBACService } from '../lib/rbac';
import { QuoteWizardModal } from './QuoteWizardModal';

interface LayoutProps {
  children: React.ReactNode;
  onOpenSearch?: () => void;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
  state?: AppState;
  updateState?: (updater: (draft: AppState) => AppState | void) => void;
}

export function Layout({
  children, onOpenSearch, unreadNotificationsCount = 0, onOpenNotifications, state, updateState
}: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [navDrawerOpen, setNavDrawerOpen] = useState(false);
  const [isQuoteWizardOpen, setIsQuoteWizardOpen] = useState(false);

  const currentUser = state?.users?.find(u => u.id === state?.currentUserId);
  const rbac = state ? new RBACService(state) : null;
  const canAccess = (tab: string) => rbac ? rbac.canAccessWorkspace(tab as any) : true;

  const activeCustomer = state?.accounts?.find(a => a.id === state?.activeContextAccountId);
  const path = location.pathname === '/' ? 'home' : location.pathname.split('/')[1];

  useEffect(() => {
    if (!quickAddOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setQuickAddOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [quickAddOpen]);

  const handleNav = (id: string) => {
    navigate(id === 'home' ? '/' : `/${id}`);
    setNavDrawerOpen(false);
  };

  // تب‌های دسکتاپ (قرص‌های بالای صفحه). gate = کلید RBAC؛ بدون gate همان رفتار قبلی (بدون محدودیت)
  const topTabs: { id: string; label: string; gate?: string }[] = [
    { id: 'home', label: 'خانه' },
    { id: 'dashboard', label: 'داشبورد' },
    { id: 'accounts', label: 'مشتریان' },
    { id: 'opportunities', label: 'فرصت‌ها', gate: 'opportunities' },
    { id: 'tasks', label: 'وظایف' },
    { id: 'calendar', label: 'تقویم' },
    { id: 'finance', label: 'مالی', gate: 'finance' },
    { id: 'reports', label: 'گزارش‌ها' },
  ].filter(t => !t.gate || canAccess(t.gate));

  // نوار شناور پایین (موبایل/تبلت): ۲ + ۲ تب دور دکمه مرکزی
  const dockLeft = [{ id: 'home', label: 'خانه', icon: Home }, { id: 'accounts', label: 'مشتریان', icon: Building2 }];
  const dockRight = [{ id: 'tasks', label: 'وظایف', icon: CheckSquare }, { id: 'calendar', label: 'تقویم', icon: CalendarDays }];

  const DockItem = ({ id, label, icon: Icon }: { id: string; label: string; icon: React.ElementType }) => {
    const on = path === id;
    return (
      <button
        onClick={() => handleNav(id)}
        aria-current={on ? 'page' : undefined}
        className="flex flex-1 cursor-pointer flex-col items-center justify-center gap-0.5 rounded-full py-1 focus-visible:outline-2 focus-visible:outline-accent"
      >
        <span className={cn('grid h-9 w-9 place-items-center rounded-full transition-all duration-300',
          on ? 'bg-primary text-white shadow-lux' : 'text-text-secondary')}>
          <Icon strokeWidth={on ? 2.4 : 1.75} className="h-[18px] w-[18px]" />
        </span>
        <span className={cn('text-[10px] leading-none', on ? 'font-extrabold text-text-main' : 'font-medium text-text-secondary')}>{label}</span>
      </button>
    );
  };

  const quickItems = [
    { id: 'quote', icon: FileText, label: 'صدور پیش‌فاکتور', hero: true, action: () => { setQuickAddOpen(false); setIsQuoteWizardOpen(true); } },
    canAccess('quotes') && { id: 'quotes_list', icon: FileSpreadsheet, label: 'لیست پیش‌فاکتورها', action: () => { setQuickAddOpen(false); navigate('/quotes'); } },
    canAccess('finance') && { id: 'finance', icon: Wallet, label: 'امور مالی و وصولی', action: () => { setQuickAddOpen(false); navigate('/finance'); } },
    canAccess('leads') && { id: 'leads', icon: UserCheck, label: 'سرنخ جدید', action: () => { setQuickAddOpen(false); navigate('/leads'); } },
    canAccess('opportunities') && { id: 'opps', icon: TrendingUp, label: 'فرصت تجاری', action: () => { setQuickAddOpen(false); navigate('/opportunities'); } },
    canAccess('tasks') && { id: 'tasks', icon: CheckSquare, label: 'تسک پیگیری', action: () => { setQuickAddOpen(false); navigate('/tasks'); } },
  ].filter(Boolean) as { id: string; icon: React.ElementType; label: string; hero?: boolean; action: () => void }[];

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-text-main font-premium" dir="rtl">
      <div
        className={cn(
          'app-bg relative z-10 flex h-full w-full origin-left flex-col overflow-hidden transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]',
          navDrawerOpen ? 'pointer-events-none scale-[0.92] rounded-[2rem] opacity-70 shadow-2xl' : 'scale-100 rounded-none'
        )}
      >
        {/* ---------- نوار بالا ---------- */}
        <header className="z-30 flex shrink-0 items-center gap-3 px-3 pb-2 pt-[calc(env(safe-area-inset-top,0px)+10px)] sm:px-5">
          <div className="flex items-center gap-2.5">
            <IconButton aria-label="منوی اصلی" onClick={() => setNavDrawerOpen(true)}><Menu className="h-5 w-5" /></IconButton>
            <button onClick={() => navigate('/')} aria-label="صفحه اصلی" className="hidden cursor-pointer items-center gap-2.5 sm:flex">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-primary text-base font-extrabold text-white shadow-lux">ا</span>
              <span className="text-[13px] font-extrabold leading-tight tracking-tight text-text-main">AKHAVAN CRM</span>
            </button>
          </div>

          <nav aria-label="ناوبری اصلی" className="hidden flex-1 justify-center lg:flex">
            <div className="glass flex items-center gap-0.5 rounded-full p-1">
              {topTabs.map(t => {
                const on = path === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => handleNav(t.id)}
                    aria-current={on ? 'page' : undefined}
                    className={cn(
                      'h-10 cursor-pointer rounded-full px-4 text-xs transition-all duration-200 focus-visible:outline-2 focus-visible:outline-accent',
                      on ? 'bg-primary font-bold text-white shadow-lux' : 'font-medium text-text-secondary hover:bg-white/70 hover:text-text-main'
                    )}
                  >
                    {t.label}
                  </button>
                );
              })}
            </div>
          </nav>
          <div className="flex-1 lg:hidden" />

          <div className="flex items-center gap-2">
            <IconButton aria-label="جستجو" onClick={onOpenSearch}><Search className="h-[18px] w-[18px]" /></IconButton>
            <IconButton aria-label="اعلان‌ها" onClick={onOpenNotifications}>
              <Bell className="h-[18px] w-[18px]" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -end-1 -top-1 min-w-5 rounded-full bg-coral px-1.5 py-0.5 text-center font-mono text-[9px] font-bold text-white shadow-sm ring-2 ring-white">
                  {unreadNotificationsCount}
                </span>
              )}
            </IconButton>
            <button onClick={() => navigate('/profile')} aria-label="پروفایل" className="glass relative cursor-pointer rounded-full p-0.5">
              <Avatar name={currentUser?.name || 'کاربر'} size="sm" />
              <span className="absolute bottom-0 end-0 h-3 w-3 rounded-full border-2 border-white bg-status-healthy" />
            </button>
          </div>
        </header>

        <NavDock />

        {/* ---------- محتوا ---------- */}
        <main className="w-full flex-1 overflow-y-auto">
          <div className="mx-auto min-h-full w-full max-w-5xl pb-[calc(env(safe-area-inset-bottom,0px)+118px)] lg:max-w-6xl lg:pe-24 lg:pb-28">
            {activeCustomer && path === 'accounts' && (
              <div className="flex items-center gap-1.5 px-4 pb-1 pt-2 text-xs">
                <ChevronLeft className="h-4 w-4 text-text-secondary" />
                <span className="font-medium text-text-secondary">مشتری:</span>
                <div className="glass flex items-center gap-1.5 rounded-full py-0.5 pe-1 ps-3">
                  <span className="max-w-[180px] truncate text-[11px] font-extrabold text-text-main">{activeCustomer.name}</span>
                  <button
                    aria-label="خروج از زمینه مشتری"
                    onClick={() => updateState && updateState(d => { d.activeContextAccountId = null; d.activeContextCustomerId = null; })}
                    className="grid h-6 w-6 cursor-pointer place-items-center rounded-full text-text-secondary hover:bg-white hover:text-text-main"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              </div>
            )}
            {children}
          </div>
        </main>

        {/* ---------- نوار شناور پایین (موبایل/تبلت) ---------- */}
        <nav aria-label="ناوبری سریع" className="fixed inset-x-3 bottom-[calc(env(safe-area-inset-bottom,0px)+12px)] z-40 mx-auto max-w-md lg:hidden">
          <div className="glass-strong flex h-16 items-center rounded-full px-2">
            {dockLeft.map(i => <DockItem key={i.id} {...i} />)}
            <div className="w-[72px] shrink-0" aria-hidden />
            {dockRight.map(i => <DockItem key={i.id} {...i} />)}
          </div>
        </nav>

        {/* دکمه افزودن سریع: وسط نوار در موبایل، گوشه پایین-چپ در دسکتاپ */}
        <button
          onClick={() => setQuickAddOpen(p => !p)}
          aria-label="افزودن سریع"
          aria-expanded={quickAddOpen}
          className={cn(
            'fixed z-50 grid h-[60px] w-[60px] cursor-pointer place-items-center rounded-full text-white transition-transform active:scale-95',
            'bg-linear-to-b from-[#34353B] to-primary shadow-lux ring-4 ring-white/70',
            'bottom-[calc(env(safe-area-inset-bottom,0px)+30px)] left-1/2 -translate-x-1/2 lg:bottom-8 lg:left-8 lg:translate-x-0',
            'focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent'
          )}
        >
          <Plus strokeWidth={2.4} className={cn('h-7 w-7 transition-transform duration-300', quickAddOpen && 'rotate-45')} />
        </button>

        {/* ---------- برگه افزودن سریع ---------- */}
        {quickAddOpen && (
          <div className="fixed inset-0 z-[45] flex flex-col justify-end" role="dialog" aria-modal="true" aria-label="افزودن سریع">
            <div className="fixed inset-0 bg-text-main/35 backdrop-blur-sm" onClick={() => setQuickAddOpen(false)} />
            <div className="glass-strong relative mx-auto w-full max-w-lg rounded-t-[32px] p-6 pb-[calc(env(safe-area-inset-bottom,0px)+96px)] animate-in slide-in-from-bottom duration-300 lg:mb-24 lg:rounded-[32px] lg:pb-6">
              <div className="mx-auto mb-5 h-1.5 w-12 rounded-full bg-text-main/10" />
              <div className="grid grid-cols-3 gap-3">
                {quickItems.map(item => (
                  <button key={item.id} onClick={item.action} className="group flex cursor-pointer flex-col items-center gap-2 rounded-3xl p-2 transition-colors hover:bg-white/70">
                    <span className={cn(
                      'grid h-14 w-14 place-items-center rounded-full transition-transform group-active:scale-95',
                      item.hero ? 'bg-primary text-white shadow-lux' : 'glass text-text-main'
                    )}>
                      <item.icon strokeWidth={2} className="h-6 w-6" />
                    </span>
                    <span className="text-center text-[11px] font-bold leading-tight text-text-main">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <NavigationDrawer isOpen={navDrawerOpen} onClose={() => setNavDrawerOpen(false)} state={state} />

      {updateState && state && (
        <QuoteWizardModal isOpen={isQuoteWizardOpen} onClose={() => setIsQuoteWizardOpen(false)} state={state} updateState={updateState} onQuoteCreated={() => navigate('/quotes')} />
      )}
    </div>
  );
}
