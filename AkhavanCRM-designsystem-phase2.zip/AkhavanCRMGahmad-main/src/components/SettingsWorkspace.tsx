import React, { useState } from 'react';
import { 
  AppState, IndustryProfile, UserGroup, DevicePermissionType, VisibilityScope, 
  AIAgent, MessagingChannel, MessagingLog, AIAgentLog 
} from '../types';
import { Card } from './ui/Card';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { 
  Building2, Shield, Link2, CheckCircle2, 
  Globe, Smartphone, Lock, AlertTriangle, Download, GitMerge,
  Users, Plus, Trash2, Edit2, UserCheck, UserPlus, Settings2,
  Bot, Zap, Send, ShieldAlert, Cpu, RefreshCw, MessageSquare, 
  Radio, Check, Calendar, ToggleLeft, ToggleRight, Sliders, ChevronDown
} from 'lucide-react';
import { findDuplicateAccounts, mergeAccounts, exportCsv } from '../lib/enterprise';
import { generateId } from '../lib/utils';
import { PERMISSION_LABELS } from '../lib/rbac';

interface SettingsWorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
}

export function SettingsWorkspace({ state, updateState }: SettingsWorkspaceProps) {
  const [tab, setTab] = useState<'ORG' | 'USERS' | 'GROUPS' | 'LOCALE' | 'INTEGRATIONS' | 'AGENTS'>('ORG');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // RBAC states
  const [userSubTab, setUserSubTab] = useState<'LIST' | 'ROLES' | 'PERMISSIONS'>('LIST');
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleScope, setNewRoleScope] = useState<VisibilityScope>('OWNER');
  const [newRoleWorkspace, setNewRoleWorkspace] = useState('dashboard');
  const [selectedDevicePerms, setSelectedDevicePerms] = useState<DevicePermissionType[]>([]);

  const [showUserModal, setShowUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserLogin, setNewUserLogin] = useState('');
  const [newUserRoleId, setNewUserRoleId] = useState('');
  const [newUserPermSetId, setNewUserPermSetId] = useState('');

  // AI & Messaging Simulator states
  const [selectedAgentId, setSelectedAgentId] = useState<string>('agent-sales');
  const [editingAgentPrompt, setEditingAgentPrompt] = useState<string>('');
  const [isEditingPrompt, setIsEditingPrompt] = useState(false);

  // Messaging Dispatcher Form
  const [testChannelId, setTestChannelId] = useState<string>('eitaa');
  const [testRecipient, setTestRecipient] = useState<string>('09121112233');
  const [testMessage, setTestMessage] = useState<string>('درود، پیش‌فاکتور جدید برای شرکت ارسال گردید.');
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [pingStatusMsg, setPingStatusMsg] = useState<string | null>(null);

  // Channel edit modal
  const [editingChannel, setEditingChannel] = useState<MessagingChannel | null>(null);

  const agents: AIAgent[] = state.agents || [
    {
      id: 'agent-sales',
      name: 'دستیار هوشمند فروش و جذب سرنخ',
      type: 'SALES',
      role: 'پایش و پیگیری خودکار فرصت‌های تجاری و سرنخ‌های جدید',
      active: true,
      requiresHumanApproval: false,
      allowedTools: ['createTask', 'searchAccounts', 'calculateQuote'],
      prompt: 'پاسخگویی سریع به سرنخ‌های ورودی، اولویت‌بندی تماس‌ها و هماهنگی جلسات دمو',
      autonomyLevel: 85,
      description: 'تسهیل چرخه تبدیل سرنخ به مشتری و یادآوری پیگیری‌های فروش'
    },
    {
      id: 'agent-collection',
      name: 'دستیار پایش مطالبات و وصولی',
      type: 'COLLECTION',
      role: 'پایش سررسید چک‌ها، اخطار فاکتورهای معوق و هشدار برگشتی',
      active: true,
      requiresHumanApproval: true,
      allowedTools: ['createTask', 'searchAccounts'],
      prompt: 'ارسال یادآوری پیامکی و بومی پیش از موعد سررسید چک و ارجاع موارد پرریسک به سرپرست مالی',
      autonomyLevel: 70,
      description: 'پیشگیری از نکول مطالبات با اخطارهای محترمانه چندمرحله‌ای'
    },
    {
      id: 'agent-pricing',
      name: 'دستیار تحلیل قیمت و مظنه (CPQ)',
      type: 'PRICING',
      role: 'تحلیل حاشیه سود، اعتبارسنجی تخفیف‌های پلکانی و پیشنهاد پکیج',
      active: true,
      requiresHumanApproval: true,
      allowedTools: ['calculateQuote', 'negotiateTerms'],
      prompt: 'بررسی حداقل کف حاشیه سود مصوب و پیشنهاد بهترین شیوه پرداخت نقدی/اقساطی',
      autonomyLevel: 60,
      description: 'تضمین سودآوری در پیش‌فاکتورها و جلوگیری از نقض سیاست‌های قیمت‌گذاری'
    }
  ];

  const channels: MessagingChannel[] = state.messagingChannels || [
    { id: 'eitaa', name: 'پیام‌رسان ایتا (Eitaa)', type: 'EITAA', active: true, status: 'CONNECTED', botToken: 'bot_eitaa_akhavan_9921', webhookUrl: 'https://eitaa.com/api/v1/webhook/crm', autoReply: true, latencyMs: 120 },
    { id: 'rubika', name: 'سوپراپلیکیشن روبیکا (Rubika)', type: 'RUBIKA', active: true, status: 'CONNECTED', botToken: 'rubika_auth_882194', webhookUrl: 'https://messengerg2c6.iranlms.ir/v1/bot', autoReply: false, latencyMs: 95 },
    { id: 'bale', name: 'پیام‌رسان بانکی بله (Bale)', type: 'BALE', active: true, status: 'CONNECTED', botToken: 'bot_bale_crm_34807', webhookUrl: 'https://ble.ir/api/v2/bot/webhook', autoReply: true, latencyMs: 110 },
    { id: 'kavenegar', name: 'درگاه پیامک خدماتی (کاوه‌نگار)', type: 'SMS', active: true, status: 'CONNECTED', botToken: 'kav_api_771829', webhookUrl: 'https://api.kavenegar.com/v1/sms/send', autoReply: true, latencyMs: 180 },
    { id: 'telegram', name: 'تلگرام بات (Telegram)', type: 'TELEGRAM', active: false, status: 'DISCONNECTED', botToken: '', webhookUrl: '', autoReply: false, latencyMs: 0 },
    { id: 'custom_webhook', name: 'وب‌هوک سفارشی سازمانی', type: 'WEBHOOK', active: true, status: 'CONNECTED', botToken: 'wh_secret_8912', webhookUrl: 'https://api.mycompany.ir/crm/events', autoReply: false, latencyMs: 65 }
  ];

  const messagingLogs: MessagingLog[] = state.messagingLogs || [];
  const agentLogs: AIAgentLog[] = state.agentLogs || [];
  const aiKillSwitch = !!state.settings?.aiKillSwitch;

  const currentLocale = state.settings?.locale || {
    rtl: true,
    language: 'fa',
    calendar: 'jalali',
    currency: 'IRR',
    timezone: 'Asia/Tehran',
    firstDayOfWeek: 6,
    numberFormat: 'persian'
  };

  const handleCreateRole = () => {
    if (!newRoleName.trim()) return;
    updateState(draft => {
      if (!draft.roles) draft.roles = [];
      draft.roles.push({
        id: generateId(),
        name: newRoleName.trim(),
        visibilityScope: newRoleScope,
        defaultWorkspace: newRoleWorkspace as any,
        requiredDevicePermissions: selectedDevicePerms
      });
    });
    setShowRoleModal(false);
    setNewRoleName('');
    setSelectedDevicePerms([]);
  };

  const handleCreateUser = () => {
    if (!newUserName.trim() || !newUserLogin.trim() || !newUserRoleId || !newUserPermSetId) return;
    updateState(draft => {
      draft.users.push({
        id: generateId(),
        name: newUserName.trim(),
        username: newUserLogin.trim(),
        roleId: newUserRoleId,
        permissionSetId: newUserPermSetId,
        active: true,
        onboardingCompleted: false
      });
    });
    setShowUserModal(false);
    setNewUserName('');
    setNewUserLogin('');
    setNewUserRoleId('');
    setNewUserPermSetId('');
  };

  const toggleModule = (key: keyof AppState['settings']['orgConfig'], checked: boolean) => {
    updateState(draft => {
      if (!draft.settings) draft.settings = {};
      if (!draft.settings.orgConfig) draft.settings.orgConfig = {};
      draft.settings.orgConfig[key] = checked as never;
    });
  };

  const toggleKillSwitch = () => {
    updateState(draft => {
      if (!draft.settings) draft.settings = {};
      draft.settings.aiKillSwitch = !aiKillSwitch;
      if (!draft.agentLogs) draft.agentLogs = [];
      draft.agentLogs.push({
        id: generateId(),
        agentId: 'system',
        trigger: 'MANUAL_OVERRIDE',
        actionProposed: !aiKillSwitch ? 'KILL_SWITCH_ENGAGED' : 'KILL_SWITCH_DISENGAGED',
        actionTaken: !aiKillSwitch ? 'STOP_ALL_AGENTS' : 'RESUME_ALL_AGENTS',
        status: 'EXECUTED',
        timestamp: new Date().toISOString(),
        reason: !aiKillSwitch ? 'کلید قطع اضطراری توسط راهبر سیستم فعال گردید.' : 'کلید قطع اضطراری غیرفعال و کارکرد دستیاران از سر گرفته شد.'
      });
    });
  };

  const handleUpdateLocale = (updates: Partial<typeof currentLocale>) => {
    updateState(draft => {
      if (!draft.settings) draft.settings = {};
      draft.settings.locale = {
        ...currentLocale,
        ...updates
      };
    });
  };

  const handleToggleAgentActive = (agentId: string) => {
    updateState(draft => {
      if (!draft.agents) draft.agents = agents;
      const target = draft.agents.find(a => a.id === agentId);
      if (target) {
        target.active = !target.active;
      }
    });
  };

  const handleToggleAgentHumanApproval = (agentId: string) => {
    updateState(draft => {
      if (!draft.agents) draft.agents = agents;
      const target = draft.agents.find(a => a.id === agentId);
      if (target) {
        target.requiresHumanApproval = !target.requiresHumanApproval;
      }
    });
  };

  const handleToggleAgentTool = (agentId: string, tool: string) => {
    updateState(draft => {
      if (!draft.agents) draft.agents = agents;
      const target = draft.agents.find(a => a.id === agentId);
      if (target) {
        if (target.allowedTools.includes(tool)) {
          target.allowedTools = target.allowedTools.filter(t => t !== tool);
        } else {
          target.allowedTools.push(tool);
        }
      }
    });
  };

  const handleSaveAgentPrompt = (agentId: string) => {
    updateState(draft => {
      if (!draft.agents) draft.agents = agents;
      const target = draft.agents.find(a => a.id === agentId);
      if (target) {
        target.prompt = editingAgentPrompt;
      }
    });
    setIsEditingPrompt(false);
  };

  const handleTestPingChannel = (channelId: string) => {
    const latency = Math.floor(Math.random() * 80) + 40;
    updateState(draft => {
      if (!draft.messagingChannels) draft.messagingChannels = channels;
      const ch = draft.messagingChannels.find(c => c.id === channelId);
      if (ch) {
        ch.status = 'CONNECTED';
        ch.lastPing = new Date().toISOString();
        ch.latencyMs = latency;
      }
    });
    setPingStatusMsg(`اتصال به ${channels.find(c => c.id === channelId)?.name || 'درگاه'} تایید شد (تاخیر پاسخ: ${latency}ms)`);
    setTimeout(() => setPingStatusMsg(null), 3000);
  };

  const handleToggleChannelActive = (channelId: string) => {
    updateState(draft => {
      if (!draft.messagingChannels) draft.messagingChannels = channels;
      const ch = draft.messagingChannels.find(c => c.id === channelId);
      if (ch) {
        ch.active = !ch.active;
      }
    });
  };

  const handleSendTestMessage = () => {
    if (!testMessage.trim() || !testRecipient.trim()) return;
    setIsSendingTest(true);

    const channel = channels.find(c => c.id === testChannelId);
    const trackingCode = `${testChannelId.slice(0, 3).toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`;

    updateState(draft => {
      if (!draft.messagingLogs) draft.messagingLogs = [];
      draft.messagingLogs.unshift({
        id: generateId(),
        channelId: testChannelId,
        direction: 'OUTBOUND',
        sender: 'سامانه CRM اخوان',
        recipient: testRecipient.trim(),
        content: testMessage.trim(),
        status: 'DELIVERED',
        timestamp: new Date().toISOString(),
        trackingId: trackingCode
      });
    });

    // Simulate automatic client / bot interaction
    setTimeout(() => {
      setIsSendingTest(false);
      updateState(draft => {
        if (!draft.messagingLogs) draft.messagingLogs = [];
        
        const autoReplies: Record<string, string> = {
          eitaa: 'پیام دریافت شد. متشکرم، مدارک تکمیلی را در اسرع وقت ارسال می‌کنم.',
          rubika: 'سلام؛ تاییدیه دریافت شد. در صورت امکان زمان جلسه دمو را پیامک کنید.',
          bale: 'با تشکر از واحد مالی اخوان؛ واریزی انجام شد و رسید ارسال گردید.',
          kavenegar: 'پیامک اعتبارسنجی با شناسه تحویل مخابرات ۱۰۰٪ ثبت گردید.',
          custom_webhook: 'Webhook payload received: HTTP 200 OK - Processed by CRM agent'
        };

        const replyContent = autoReplies[testChannelId] || 'پاسخ خودکار درگاه دریافت شد.';

        draft.messagingLogs.unshift({
          id: generateId(),
          channelId: testChannelId,
          direction: 'INBOUND',
          sender: testRecipient.trim(),
          recipient: channel?.name || 'CRM',
          content: replyContent,
          status: 'RECEIVED',
          timestamp: new Date().toISOString(),
          trackingId: `ACK-${Math.floor(10000 + Math.random() * 90000)}`
        });

        if (!draft.settings?.aiKillSwitch) {
          if (!draft.agentLogs) draft.agentLogs = [];
          draft.agentLogs.unshift({
            id: generateId(),
            agentId: 'agent-sales',
            trigger: 'MESSAGE_RECEIVED',
            actionProposed: 'createTask',
            actionTaken: 'createTask',
            status: 'EXECUTED',
            timestamp: new Date().toISOString(),
            reason: `پاسخ دریافتی از ${channel?.name || 'کانال بومی'} پردازش شد و تسک پیگیری ثبت گردید.`
          });
        }
      });
    }, 700);
  };

  const handleApproveAgentAction = (logId: string) => {
    updateState(draft => {
      if (!draft.agentLogs) return;
      const log = draft.agentLogs.find(l => l.id === logId);
      if (log) {
        log.status = 'EXECUTED';
        log.actionTaken = log.actionProposed;
        log.reason = 'اقدام توسط ناظر انسانی در پنل تنظیمات تأیید و اجرا شد.';
      }
    });
  };

  const duplicates = findDuplicateAccounts(state.accounts || []);

  const handleExportAccounts = () => {
    const csv = exportCsv(state.accounts || [], ['id', 'name', 'code', 'phone', 'address', 'creditLimit', 'nationalId']);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `accounts_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setExportNotice('فایل اکسپورت با موفقیت تولید و دانلود شد.');
    setTimeout(() => setExportNotice(null), 3000);
  };

  const selectedAgent = agents.find(a => a.id === selectedAgentId) || agents[0];

  return (
    <div className="flex-1 overflow-auto bg-canvas p-4 sm:p-6 space-y-4" dir="rtl">
      {/* Navigation Tabs Header */}
      <div className="flex gap-2 border-b border-[#E2E8F0] pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'ORG', label: 'ساختار سازمان' },
          { id: 'AGENTS', label: 'دستیاران AI و پیام‌رسان‌های بومی' },
          { id: 'LOCALE', label: 'تقویم شمسی و بومی‌سازی' },
          { id: 'USERS', label: 'امنیت و دسترسی (RBAC)' },
          { id: 'GROUPS', label: 'گروه‌ها و تیم‌های کاری' },
          { id: 'INTEGRATIONS', label: 'یکپارچه‌سازی و کاتالوگ' }
        ].map(t => {
          const isActive = tab === t.id;
          return (
            <button 
              key={t.id}
              onClick={() => setTab(t.id as any)} 
              aria-current={isActive ? 'page' : undefined}
              className={`px-4 py-2 text-sm rounded-xl transition-all whitespace-nowrap cursor-pointer border ${isActive ? 'bg-primary/10 text-primary border-primary/20 font-extrabold shadow-sm' : 'bg-white text-text-secondary border-transparent hover:bg-canvas font-medium'}`}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* ===================== TAB: AGENTS & MESSAGING GATEWAYS ===================== */}
      {tab === 'AGENTS' && (
        <div className="space-y-5">
          {/* Emergency Kill Switch Banner */}
          <Card padding="lg" className={`border-2 transition-all ${aiKillSwitch ? 'bg-red-50/60 border-red-300' : 'bg-white border-[#E2E8F0]'}`}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-start gap-3">
                <div className={`p-3 rounded-2xl ${aiKillSwitch ? 'bg-red-500 text-white shadow-md' : 'bg-primary/10 text-primary'}`}>
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-base text-text-main">کلید قطع اضطراری هوش مصنوعی (AI Kill-Switch)</h3>
                    <span className={`px-2.5 py-0.5 text-xs font-black rounded-full ${aiKillSwitch ? 'bg-red-600 text-white' : 'bg-emerald-100 text-emerald-800'}`}>
                      {aiKillSwitch ? 'فعال - کلیه پردازش‌های خودکار متوقف' : 'عادی - دستیاران در مدار'}
                    </span>
                  </div>
                  <p className="text-xs text-text-secondary mt-1 leading-relaxed">
                    با فعال‌سازی این کلید، تمامی اقدامات و ابزارهای خودکار دستیاران در سرتاسر CRM (ارسال پیامک، تولید وظایف، پیشنهادات CPQ) بلافاصله متوقف می‌گردند.
                  </p>
                </div>
              </div>
              <button
                onClick={toggleKillSwitch}
                className={`px-5 py-2.5 rounded-xl font-black text-xs cursor-pointer transition-all shadow-sm flex items-center gap-2 ${
                  aiKillSwitch 
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                    : 'bg-red-600 hover:bg-red-700 text-white'
                }`}
              >
                <Zap className="w-4 h-4" />
                {aiKillSwitch ? 'غیرفعال‌سازی کلید اضطراری (بازگشت به مدار)' : 'قطع اضطراری کلیه دستیارها'}
              </button>
            </div>
          </Card>

          {/* AI Agents Registry */}
          <Card padding="lg" className="bg-white border-[#E2E8F0] space-y-4">
            <div className="flex justify-between items-center border-b border-[#E2E8F0] pb-3">
              <div>
                <h3 className="font-bold text-base text-text-main flex items-center gap-2">
                  <Bot className="w-5 h-5 text-primary" /> دستیاران هوشمند سازمانی (Agent Registry)
                </h3>
                <span className="text-xs text-text-secondary">پیکربندی سطح خودمختاری، ابزارهای مجاز و سیاست‌های تأیید ناظر انسانی (Human-in-the-Loop)</span>
              </div>
              <span className="text-xs font-bold text-primary bg-primary/10 px-3 py-1 rounded-xl font-mono">
                {agents.filter(a => a.active).length} از {agents.length} فعال
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {agents.map(ag => {
                const isSelected = selectedAgentId === ag.id;
                return (
                  <div 
                    key={ag.id} 
                    onClick={() => {
                      setSelectedAgentId(ag.id);
                      setEditingAgentPrompt(ag.prompt);
                      setIsEditingPrompt(false);
                    }}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected 
                        ? 'border-primary bg-primary/5 shadow-sm' 
                        : 'border-[#E2E8F0] bg-canvas hover:border-slate-300'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <strong className="text-sm font-bold text-text-main block">{ag.name}</strong>
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-lg ${ag.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>
                        {ag.active ? 'فعال' : 'غیرفعال'}
                      </span>
                    </div>
                    <p className="text-xs text-text-secondary line-clamp-2 mb-3">{ag.role}</p>
                    <div className="flex justify-between items-center text-[11px] border-t border-slate-200/60 pt-2 text-text-secondary">
                      <span>خودمختاری: <strong className="text-text-main font-mono">{ag.autonomyLevel}%</strong></span>
                      <span className={ag.requiresHumanApproval ? 'text-amber-700 font-bold' : 'text-emerald-700'}>
                        {ag.requiresHumanApproval ? 'نیازمند تأیید ناظر' : 'خودمختار'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Agent Detailed Config Editor */}
            {selectedAgent && (
              <div className="p-4 bg-canvas rounded-2xl border border-[#E2E8F0] space-y-4 mt-2">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-200 pb-3">
                  <div>
                    <h4 className="font-extrabold text-sm text-text-main flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-primary" /> تنظیمات رفتاری: {selectedAgent.name}
                    </h4>
                    <span className="text-[11px] text-text-secondary">{selectedAgent.description}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggleAgentActive(selectedAgent.id)}
                      className={`px-3 py-1 text-xs font-bold rounded-xl cursor-pointer transition-colors ${
                        selectedAgent.active ? 'bg-emerald-600 text-white' : 'bg-slate-300 text-slate-700'
                      }`}
                    >
                      {selectedAgent.active ? 'فعال' : 'غیرفعال'}
                    </button>
                    <button
                      onClick={() => handleToggleAgentHumanApproval(selectedAgent.id)}
                      className={`px-3 py-1 text-xs font-bold rounded-xl cursor-pointer transition-colors ${
                        selectedAgent.requiresHumanApproval ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {selectedAgent.requiresHumanApproval ? 'نظارت انسانی (فعال)' : 'نظارت انسانی (خاموش)'}
                    </button>
                  </div>
                </div>

                {/* Allowed Tools Checkboxes */}
                <div>
                  <label className="block font-bold text-xs text-text-main mb-2">ابزارهای اجرایی مجاز (Allowed Tools):</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'createTask', label: 'تولید وظیفه و پیگیری (createTask)' },
                      { id: 'searchAccounts', label: 'جستجو در حساب‌ها (searchAccounts)' },
                      { id: 'calculateQuote', label: 'محاسبه و ارزیابی مظنه (calculateQuote)' },
                      { id: 'negotiateTerms', label: 'پیشنهاد شرایط تسویه (negotiateTerms)' }
                    ].map(tool => {
                      const isAllowed = selectedAgent.allowedTools.includes(tool.id);
                      return (
                        <label 
                          key={tool.id} 
                          className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer text-xs transition-all ${
                            isAllowed ? 'bg-white border-primary text-text-main font-bold shadow-xs' : 'bg-canvas border-slate-200 text-slate-500'
                          }`}
                        >
                          <input 
                            type="checkbox" 
                            checked={isAllowed} 
                            onChange={() => handleToggleAgentTool(selectedAgent.id, tool.id)}
                            className="w-4 h-4 accent-primary rounded" 
                          />
                          <span>{tool.label}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* System Prompt Instructions Editor */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-bold text-xs text-text-main">پرامپت و دستورالعمل رفتاری ایجنت (System Prompt):</label>
                    {!isEditingPrompt ? (
                      <button 
                        onClick={() => {
                          setEditingAgentPrompt(selectedAgent.prompt);
                          setIsEditingPrompt(true);
                        }} 
                        className="text-xs text-primary font-bold hover:underline cursor-pointer flex items-center gap-1"
                      >
                        <Edit2 className="w-3.5 h-3.5" /> ویرایش دستورالعمل
                      </button>
                    ) : (
                      <div className="flex gap-2">
                        <button onClick={() => setIsEditingPrompt(false)} className="text-xs text-slate-500 font-bold hover:underline cursor-pointer">انصراف</button>
                        <button onClick={() => handleSaveAgentPrompt(selectedAgent.id)} className="text-xs bg-primary text-white px-3 py-1 rounded-lg font-bold cursor-pointer">ذخیره پرامپت</button>
                      </div>
                    )}
                  </div>
                  {isEditingPrompt ? (
                    <textarea 
                      value={editingAgentPrompt} 
                      onChange={e => setEditingAgentPrompt(e.target.value)} 
                      rows={3} 
                      className="w-full bg-white border border-primary p-3 rounded-xl text-xs outline-none focus:ring-1 ring-primary"
                    />
                  ) : (
                    <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs text-text-main leading-relaxed">
                      {selectedAgent.prompt}
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>

          {/* Native Messaging Gateways Section */}
          <Card padding="lg" className="bg-white border-[#E2E8F0] space-y-4">
            <div className="flex justify-between items-center border-b border-[#E2E8F0] pb-3">
              <div>
                <h3 className="font-bold text-base text-text-main flex items-center gap-2">
                  <Radio className="w-5 h-5 text-primary" /> درگاه‌های پیام‌رسان بومی و وب‌هوک (Messaging Adapters)
                </h3>
                <span className="text-xs text-text-secondary">اتصال مستقیم به ایتا، روبیکا، بله، کاوه‌نگار و خطوط پیامک خدماتی با شبیه‌ساز زنده</span>
              </div>
              {pingStatusMsg && (
                <div className="p-2 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 animate-in fade-in">
                  {pingStatusMsg}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {channels.map(ch => {
                const isConnected = ch.status === 'CONNECTED';
                return (
                  <div key={ch.id} className="p-4 rounded-2xl border border-[#E2E8F0] bg-canvas flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <strong className="text-sm font-bold text-text-main block">{ch.name}</strong>
                        <span className="text-[10px] font-mono text-text-secondary block mt-0.5">{ch.webhookUrl ? ch.webhookUrl.slice(0, 32) + '...' : 'بدون وب‌هوک'}</span>
                      </div>
                      <span className={`px-2 py-0.5 text-[10px] font-black rounded-full ${isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>
                        {isConnected ? 'متصل' : 'قطع'}
                      </span>
                    </div>

                    <div className="text-[11px] text-text-secondary space-y-1 bg-white p-2.5 rounded-xl border border-slate-200/60 font-mono">
                      <div className="flex justify-between">
                        <span>تاخیر (Ping):</span>
                        <strong className="text-text-main">{ch.latencyMs || 0}ms</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>پاسخ خودکار:</span>
                        <strong className={ch.autoReply ? 'text-emerald-700' : 'text-slate-400'}>{ch.autoReply ? 'فعال' : 'خاموش'}</strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-200/60">
                      <button
                        onClick={() => handleTestPingChannel(ch.id)}
                        className="flex-1 py-1.5 bg-white border border-[#E2E8F0] hover:bg-slate-50 text-xs font-bold text-text-main rounded-xl cursor-pointer flex items-center justify-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-primary" /> تست اتصال
                      </button>
                      <button
                        onClick={() => handleToggleChannelActive(ch.id)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-xl cursor-pointer transition-colors ${
                          ch.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {ch.active ? 'فعال' : 'غیرفعال'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Interactive Test Message Dispatcher */}
          <Card padding="lg" className="bg-white border-[#E2E8F0] space-y-4">
            <h3 className="font-bold text-base text-text-main flex items-center gap-2">
              <Send className="w-5 h-5 text-primary" /> شبیه‌ساز تعاملی ارسال و دریافت پیام تستی (Interactive Dispatcher)
            </h3>
            <p className="text-xs text-text-secondary">
              ارسال پیام تستی از طریق درگاه‌های بومی (ایتا، بله، روبیکا، کاوه‌نگار) با شبیه‌سازی پاسخ خودکار مشتری و ثبت فوری در رویدادنگار محلی.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-text-main mb-1">درگاه فرستنده:</label>
                <select 
                  value={testChannelId} 
                  onChange={e => setTestChannelId(e.target.value)} 
                  className="w-full bg-canvas border border-[#E2E8F0] p-2.5 rounded-xl text-xs font-bold outline-none"
                >
                  {channels.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-text-main mb-1">شماره یا شناسه دریافت‌کننده:</label>
                <Input 
                  value={testRecipient} 
                  onChange={e => setTestRecipient(e.target.value)} 
                  placeholder="09121112233 یا @username" 
                  dir="ltr" 
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-text-main mb-1">متن پیام تستی:</label>
              <textarea 
                value={testMessage} 
                onChange={e => setTestMessage(e.target.value)} 
                rows={2} 
                placeholder="متن پیام ارسالی به مشتری..." 
                className="w-full bg-canvas border border-[#E2E8F0] p-3 rounded-xl text-xs outline-none focus:ring-1 ring-primary"
              />
            </div>

            <div className="flex justify-end">
              <Button 
                variant="primary" 
                size="sm" 
                onClick={handleSendTestMessage} 
                disabled={isSendingTest}
                icon={<Send className="w-4 h-4" />}
              >
                {isSendingTest ? 'در حال ارسال و شبیه‌سازی پاسخ...' : 'ارسال پیام تستی و تولید پاسخ هوشمند'}
              </Button>
            </div>
          </Card>

          {/* Live Dispatch & Agent Activity Logs */}
          <Card padding="lg" className="bg-white border-[#E2E8F0] space-y-4">
            <div className="flex justify-between items-center border-b border-[#E2E8F0] pb-2">
              <h3 className="font-bold text-base text-text-main flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" /> رویدادنگار زنده پیام‌ها و لاگ هوش مصنوعی (Live Event Logs)
              </h3>
              <span className="text-xs text-text-secondary font-mono">{messagingLogs.length} پیام ثبت‌شده</span>
            </div>

            {/* Messaging Logs Table */}
            <div className="overflow-x-auto max-h-64 no-scrollbar">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="text-text-secondary border-b border-[#E2E8F0] text-[11px] font-bold">
                    <th className="pb-2">زمان</th>
                    <th className="pb-2">درگاه</th>
                    <th className="pb-2">جهت</th>
                    <th className="pb-2">طرف پیام</th>
                    <th className="pb-2">متن</th>
                    <th className="pb-2">کد رهگیری</th>
                    <th className="pb-2 text-left">وضعیت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {messagingLogs.map(log => {
                    const ch = channels.find(c => c.id === log.channelId);
                    return (
                      <tr key={log.id} className="hover:bg-canvas">
                        <td className="py-2.5 font-mono text-[11px] text-text-secondary">
                          {new Date(log.timestamp).toLocaleTimeString('fa-IR')}
                        </td>
                        <td className="py-2.5 font-bold text-text-main">
                          {ch?.name || log.channelId}
                        </td>
                        <td className="py-2.5">
                          <span className={`px-2 py-0.5 text-[10px] font-black rounded-lg ${log.direction === 'OUTBOUND' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                            {log.direction === 'OUTBOUND' ? 'ارسال به بیرون' : 'دریافتی از کاربر'}
                          </span>
                        </td>
                        <td className="py-2.5 font-mono text-xs text-text-main">
                          {log.direction === 'OUTBOUND' ? log.recipient : log.sender}
                        </td>
                        <td className="py-2.5 text-xs text-text-main max-w-xs truncate" title={log.content}>
                          {log.content}
                        </td>
                        <td className="py-2.5 font-mono text-[10px] text-text-secondary">
                          {log.trackingId || '-'}
                        </td>
                        <td className="py-2.5 text-left">
                          <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                            {log.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                  {messagingLogs.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center py-6 text-slate-400">هیچ پیامی ثبت نشده است. از فرم بالا پیام تستی ارسال کنید.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Agent Operational Logs */}
            {agentLogs.length > 0 && (
              <div className="pt-4 border-t border-[#E2E8F0]">
                <h4 className="font-bold text-xs text-text-main mb-2 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-primary" /> سابقه اقدامات ایجنت‌ها و درخواست‌های تأیید (Audit Queue):
                </h4>
                <div className="space-y-2">
                  {agentLogs.slice(0, 5).map(alog => (
                    <div key={alog.id} className="p-3 bg-canvas rounded-xl border border-slate-200 flex justify-between items-center text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-text-main">{alog.agentId}</strong>
                          <span className="text-text-secondary font-mono text-[11px]">[{alog.trigger}]</span>
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded-lg ${
                            alog.status === 'EXECUTED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {alog.status === 'EXECUTED' ? 'اجرا شده' : 'نیازمند تأیید ناظر'}
                          </span>
                        </div>
                        <p className="text-[11px] text-text-secondary mt-0.5">{alog.reason || alog.actionProposed}</p>
                      </div>
                      {alog.status === 'AWAITING_APPROVAL' && (
                        <button 
                          onClick={() => handleApproveAgentAction(alog.id)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                        >
                          تأیید اقدام
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Card>
        </div>
      )}

      {/* ===================== TAB: LOCALE, CALENDAR & HARDWARE ===================== */}
      {tab === 'LOCALE' && (
        <div className="space-y-5">
          <Card padding="lg" className="space-y-5 bg-white border-[#E2E8F0]">
            <div className="flex justify-between items-center border-b border-[#E2E8F0] pb-3">
              <div>
                <h3 className="font-bold text-lg text-text-main flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" /> تنظیمات تقویم شمسی و بومی‌سازی (Calendar & Locale)
                </h3>
                <span className="text-xs text-text-secondary">پیکربندی سیستم تاریخ، روز آغازین هفته، فرمت ارقام و منطقه زمانی کاری سامانه</span>
              </div>
              <div className="px-3 py-1 bg-emerald-50 text-emerald-800 font-bold text-xs rounded-xl border border-emerald-200">
                تقویم فعال: {currentLocale.calendar === 'jalali' ? 'هجری شمسی (جلالی)' : 'میلادی (Gregorian)'}
              </div>
            </div>

            {/* Quick Live Preview of Date */}
            <div className="p-4 bg-primary/5 rounded-2xl border border-primary/20 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
              <div>
                <span className="font-bold text-text-main block text-sm">پیش‌نمایش زنده تاریخ و زمان سامانه:</span>
                <span className="text-text-secondary mt-0.5 block">
                  {currentLocale.calendar === 'jalali' 
                    ? `امروز: ${new Date().toLocaleDateString('fa-IR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}` 
                    : `Today: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`}
                </span>
              </div>
              <span className="font-mono font-bold text-xs text-primary bg-white px-3 py-1.5 rounded-xl border border-primary/30 shadow-xs">
                منطقه زمانی: {currentLocale.timezone || 'Asia/Tehran'} (+03:30)
              </span>
            </div>

            {/* Locale Configurations Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
              {/* Calendar Switcher */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">نوع تقویم اصلی (Calendar System):</label>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => handleUpdateLocale({ calendar: 'jalali' })}
                    className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                      currentLocale.calendar === 'jalali' ? 'bg-primary text-white border-primary' : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    هجری شمسی (پیش‌فرض)
                  </button>
                  <button 
                    onClick={() => handleUpdateLocale({ calendar: 'gregorian' })}
                    className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                      currentLocale.calendar === 'gregorian' ? 'bg-primary text-white border-primary' : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    میلادی (Gregorian)
                  </button>
                </div>
              </div>

              {/* Start day of week */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">روز آغازین هفته کاری:</label>
                <select 
                  value={currentLocale.firstDayOfWeek ?? 6} 
                  onChange={e => handleUpdateLocale({ firstDayOfWeek: Number(e.target.value) })}
                  className="w-full bg-white border border-[#E2E8F0] p-2.5 rounded-xl font-bold outline-none"
                >
                  <option value={6}>شنبه (استاندارد ایران و منطقه)</option>
                  <option value={0}>یکشنبه (Sunday)</option>
                  <option value={1}>دوشنبه (Monday)</option>
                </select>
              </div>

              {/* Direction LTR / RTL */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">جهت چیدمان صفحه (Direction):</label>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => handleUpdateLocale({ rtl: true })}
                    className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                      currentLocale.rtl ? 'bg-primary text-white border-primary' : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    راست به چپ (RTL)
                  </button>
                  <button 
                    onClick={() => handleUpdateLocale({ rtl: false })}
                    className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                      !currentLocale.rtl ? 'bg-primary text-white border-primary' : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    چپ به راست (LTR)
                  </button>
                </div>
              </div>

              {/* Language */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">زبان سامانه (Language):</label>
                <select 
                  value={currentLocale.language || 'fa'} 
                  onChange={e => handleUpdateLocale({ language: e.target.value })}
                  className="w-full bg-white border border-[#E2E8F0] p-2.5 rounded-xl font-bold outline-none"
                >
                  <option value="fa">فارسی (Persian)</option>
                  <option value="en">English (انگلیسی)</option>
                </select>
              </div>

              {/* Number format */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">فرمت نمایش ارقام و مبالغ:</label>
                <select 
                  value={currentLocale.numberFormat || 'persian'} 
                  onChange={e => handleUpdateLocale({ numberFormat: e.target.value })}
                  className="w-full bg-white border border-[#E2E8F0] p-2.5 rounded-xl font-bold outline-none"
                >
                  <option value="persian">ارقام فارسی (۱۲۳٬۴۵۶)</option>
                  <option value="latin">ارقام لاتین (123,456)</option>
                </select>
              </div>

              {/* Currency */}
              <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                <label className="font-bold text-text-main block">واحد پول رسمی سازمان:</label>
                <select 
                  value={currentLocale.currency || 'IRR'} 
                  onChange={e => handleUpdateLocale({ currency: e.target.value })}
                  className="w-full bg-white border border-[#E2E8F0] p-2.5 rounded-xl font-bold outline-none"
                >
                  <option value="IRR">ریال ایران (IRR)</option>
                  <option value="TOMAN">تومان</option>
                  <option value="USD">دلار آمریکا (USD)</option>
                </select>
              </div>
            </div>
          </Card>

          {/* Device Permissions Card */}
          <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
            <h4 className="font-bold text-sm text-text-main flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-primary" /> وضعیت دسترسی‌های دستگاه همراه (Device Permissions)
            </h4>
            <p className="text-xs text-text-secondary">برای ثبت دقیق مکان ویزیت‌ها، پیوست عکس و دریافت اعلان‌ها:</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {[
                { key: 'LOCATION', label: 'موقعیت مکانی (GPS)' },
                { key: 'CAMERA', label: 'دوربین و گالری' },
                { key: 'MICROPHONE', label: 'میکروفون و ویس' },
                { key: 'NOTIFICATIONS', label: 'اعلان‌های سیستم' }
              ].map(item => {
                const isGranted = !!state.grantedDevicePermissions?.[item.key as DevicePermissionType];
                return (
                  <div key={item.key} className="p-3 bg-canvas rounded-xl border border-[#E2E8F0] flex flex-col justify-between gap-2">
                    <span className="font-bold text-text-main">{item.label}</span>
                    <button 
                      onClick={() => {
                        updateState(draft => {
                          if (!draft.grantedDevicePermissions) {
                            draft.grantedDevicePermissions = { LOCATION: false, CAMERA: false, MICROPHONE: false, NOTIFICATIONS: false };
                          }
                          draft.grantedDevicePermissions[item.key as DevicePermissionType] = !isGranted;
                        });
                      }}
                      className={`px-2.5 py-1 text-[11px] font-bold rounded-lg cursor-pointer transition-colors ${isGranted ? 'bg-[#F0FDF4] text-[#166534]' : 'bg-red-50 text-[#991B1B]'}`}
                    >
                      {isGranted ? 'فعال و تایید شده' : 'غیرفعال (کلیک برای فعال‌سازی)'}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-2">
              <Button 
                variant="primary" 
                size="sm"
                onClick={() => {
                  updateState(draft => {
                    draft.grantedDevicePermissions = { LOCATION: true, CAMERA: true, MICROPHONE: true, NOTIFICATIONS: true };
                  });
                }}
              >
                تأیید و فعال‌سازی یکباره کلیه دسترسی‌ها
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* ===================== TAB: ORG CONFIG ===================== */}
      {tab === 'ORG' && (
        <div className="space-y-4">
          <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
            <h3 className="font-bold text-lg text-text-main flex items-center gap-2">
              <Building2 className="w-5 h-5 text-primary" /> پیکربندی ماژول‌های سازمانی
            </h3>
            <p className="text-xs text-text-secondary mb-4">
              فعال‌سازی یا غیرفعال‌سازی مفاهیم سازمانی. داشبورد و فیلترها بر اساس این تنظیمات تغییر می‌کنند.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-4 bg-canvas rounded-xl border border-[#E2E8F0]">
                <div>
                  <span className="font-semibold text-text-main block text-sm">سرنخ‌ها (Leads)</span>
                </div>
                <input type="checkbox" checked={state.settings?.orgConfig?.enableLeadManagement ?? true} onChange={e => toggleModule('enableLeadManagement', e.target.checked)} className="w-5 h-5 accent-primary rounded cursor-pointer" />
              </div>
              <div className="flex items-center justify-between p-4 bg-canvas rounded-xl border border-[#E2E8F0]">
                <div>
                  <span className="font-semibold text-text-main block text-sm">فرصت‌ها و پایپ‌لاین (Opportunities)</span>
                </div>
                <input type="checkbox" checked={state.settings?.orgConfig?.enableOpportunities ?? true} onChange={e => toggleModule('enableOpportunities', e.target.checked)} className="w-5 h-5 accent-primary rounded cursor-pointer" />
              </div>
              <div className="flex items-center justify-between p-4 bg-canvas rounded-xl border border-[#E2E8F0]">
                <div>
                  <span className="font-semibold text-text-main block text-sm">پیش‌فاکتورها (CPQ & Quotes)</span>
                </div>
                <input type="checkbox" checked={state.settings?.orgConfig?.enableQuotes ?? true} onChange={e => toggleModule('enableQuotes', e.target.checked)} className="w-5 h-5 accent-primary rounded cursor-pointer" />
              </div>
              <div className="flex items-center justify-between p-4 bg-canvas rounded-xl border border-[#E2E8F0]">
                <div>
                  <span className="font-semibold text-text-main block text-sm">امور مالی و وصولی (Finance)</span>
                </div>
                <input type="checkbox" checked={state.settings?.orgConfig?.enableFinance ?? true} onChange={e => toggleModule('enableFinance', e.target.checked)} className="w-5 h-5 accent-primary rounded cursor-pointer" />
              </div>
            </div>
          </Card>

          <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold text-base text-text-main flex items-center gap-2">
                  <GitMerge className="w-5 h-5 text-primary" /> پایش کیفیت داده و ادغام حساب‌های تکراری
                </h3>
                <span className="text-xs text-text-secondary">شناسایی خودکار شماره تماس‌های تکراری و ادغام قطعی رکوردها با حفظ تاریخچه</span>
              </div>
              <button 
                onClick={handleExportAccounts}
                className="px-3 py-1.5 bg-white border border-[#E2E8F0] hover:bg-canvas text-text-main text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4 text-primary" /> استخراج اکسل/CSV
              </button>
            </div>

            {exportNotice && (
              <div className="p-3 bg-primary/10 border border-primary/20 text-primary text-xs rounded-xl font-medium">
                {exportNotice}
              </div>
            )}

            {duplicates.length === 0 ? (
              <div className="p-4 bg-[#F0FDF4] border border-[#BBF7D0] rounded-xl flex items-center gap-3 text-[#166534] text-xs">
                <CheckCircle2 className="w-5 h-5 text-[#16A34A] shrink-0" />
                <span>تمام حساب‌های مشتریان دارای شماره تماس یکتا هستند و هیچ تکراری شناسایی نشد.</span>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3 bg-[#FFFBEB] border border-[#FDE68A] rounded-xl flex items-center gap-2 text-[#92400E] text-xs">
                  <AlertTriangle className="w-4 h-4 text-[#D97706] shrink-0" />
                  <span>{duplicates.length} مورد تداخل شماره تماس شناسایی شد.</span>
                </div>
                {duplicates.map(d => (
                  <div key={d.primary.id} className="p-3 border border-[#E2E8F0] rounded-xl bg-canvas flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                    <div>
                      <span className="font-bold text-text-main text-sm">{d.primary.name}</span>
                      <span className="text-xs text-text-secondary block font-mono">تلفن: {d.primary.phone}</span>
                      <span className="text-[11px] text-[#92400E]">حساب‌های تکراری هم‌شماره: {d.duplicates.map(x => x.name).join('، ')}</span>
                    </div>
                    {d.duplicates.map(dup => (
                      <button 
                        key={dup.id}
                        onClick={() => mergeAccounts(d.primary.id, dup.id, state, updateState)}
                        className="px-3 py-1.5 bg-[#D97706] hover:bg-[#B45309] text-white font-bold text-xs rounded-lg transition-colors cursor-pointer"
                      >
                        ادغام {dup.name} در {d.primary.name}
                      </button>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      )}

      {/* ===================== TAB: USERS & RBAC ===================== */}
      {tab === 'USERS' && (
        <Card padding="lg" className="bg-white border-[#E2E8F0]">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg text-text-main flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" /> مدیریت ساختار دسترسی (RBAC Admin)
            </h3>
          </div>
          
          <div className="flex gap-2 border-b border-[#E2E8F0] pb-2 mb-4">
            {[
              { id: 'LIST', label: 'کاربران سیستم' },
              { id: 'ROLES', label: 'نقش‌ها (Roles - SEE)' },
              { id: 'PERMISSIONS', label: 'پروفایل مجوز (Permissions - DO)' }
            ].map(t => {
              const isActive = userSubTab === t.id;
              return (
                <button 
                  key={t.id}
                  onClick={() => setUserSubTab(t.id as any)} 
                  aria-current={isActive ? 'page' : undefined}
                  className={`px-4 py-1.5 text-xs rounded-lg cursor-pointer border ${isActive ? 'bg-primary/10 text-primary border-primary/20 font-extrabold' : 'bg-canvas text-text-secondary border-transparent hover:bg-white font-medium'}`}
                >
                  {t.label}
                </button>
              );
            })}
          </div>

          {userSubTab === 'LIST' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <Button variant="primary" size="sm" onClick={() => setShowUserModal(true)} icon={<UserPlus className="w-4 h-4"/>}>کاربر جدید</Button>
              </div>
              <div className="space-y-2">
                {state.users.map(u => {
                  const pSet = (state.permissionSets || []).find(p => p.id === u.permissionSetId);
                  const role = (state.roles || []).find(r => r.id === u.roleId);
                  const parentRole = role?.parentId ? (state.roles || []).find(r => r.id === role.parentId) : null;
                  return (
                    <div key={u.id} className="p-3 border border-[#E2E8F0] rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-3 bg-canvas">
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-sm text-text-main">{u.name}</strong>
                          <span className="text-xs text-text-secondary font-mono">(@{u.username})</span>
                          {u.id === state.currentUserId && (
                            <span className="px-2 py-0.5 bg-primary/10 text-primary text-[10px] font-bold rounded-full">کاربر جاری</span>
                          )}
                        </div>
                        <div className="text-xs text-text-secondary mt-1 flex flex-wrap gap-2">
                          <span>پروفایل: <strong className="text-primary">{pSet?.name || 'تعریف‌نشده'}</strong></span>
                          <span>•</span>
                          <span>محدوده دید: <strong className="text-[#075985] font-mono">{role?.name || role?.visibilityScope} ({role?.visibilityScope})</strong></span>
                          {parentRole && (
                            <>
                              <span>•</span>
                              <span className="text-text-secondary">گزارش به: <strong className="text-text-main">{parentRole.name}</strong></span>
                            </>
                          )}
                        </div>
                      </div>
                      <button onClick={() => updateState(draft => { draft.currentUserId = u.id; })} className={`text-xs px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-colors ${u.id === state.currentUserId ? 'bg-primary text-white' : 'bg-white border border-[#E2E8F0] text-text-main hover:bg-canvas'}`}>
                        {u.id === state.currentUserId ? 'فعال' : 'تغییر کاربر'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {userSubTab === 'ROLES' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <Button variant="primary" size="sm" onClick={() => setShowRoleModal(true)} icon={<Plus className="w-4 h-4"/>}>نقش سازمانی جدید</Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(state.roles || []).map(r => (
                  <div key={r.id} className="p-4 border border-[#E2E8F0] rounded-xl bg-canvas space-y-2">
                    <div className="flex justify-between items-start">
                      <strong className="text-sm font-bold text-text-main">{r.name}</strong>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-primary/10 text-primary font-bold">
                        {r.visibilityScope}
                      </span>
                    </div>
                    <div className="text-xs text-text-secondary">
                      فضای کاری پیش‌فرض: <strong className="text-text-main font-mono">{r.defaultWorkspace || 'home'}</strong>
                    </div>
                    {r.requiredDevicePermissions && r.requiredDevicePermissions.length > 0 && (
                      <div className="pt-2 border-t border-[#E2E8F0] text-[10px] text-text-secondary">
                        <span>دسترسی‌های الزامی دستگاه: </span>
                        <span className="font-bold text-[#991B1B]">{r.requiredDevicePermissions.join('، ')}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {userSubTab === 'PERMISSIONS' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(state.permissionSets || []).map(ps => (
                <div key={ps.id} className="p-3 bg-white border border-[#E2E8F0] rounded-xl">
                  <strong className="text-sm font-bold text-text-main block">{ps.name}</strong>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {ps.permissions.map(perm => (
                      <span key={perm} className="text-[10px] font-mono px-1.5 py-0.5 bg-canvas text-text-secondary rounded border border-[#E2E8F0]">
                        {PERMISSION_LABELS[perm as keyof typeof PERMISSION_LABELS] || perm}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* ===================== TAB: GROUPS ===================== */}
      {tab === 'GROUPS' && (
        <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
          <h3 className="font-bold text-lg text-text-main flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" /> گروه‌ها و تیم‌های سازمانی
          </h3>
          <p className="text-xs text-text-secondary">
            مدیریت تیم‌های فروش، پشتیبانی، گروه‌های پروژه و سطوح ارجاع کار
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {(state.groups || []).map(g => {
              const manager = state.users.find(u => u.id === g.managerId);
              return (
                <div key={g.id} className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
                  <div className="flex justify-between items-center">
                    <strong className="text-sm font-bold text-text-main">{g.name}</strong>
                    <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary font-bold rounded-lg font-mono">
                      {g.memberIds.length} عضو
                    </span>
                  </div>
                  {g.description && <p className="text-xs text-text-secondary">{g.description}</p>}
                  <div className="text-xs text-text-secondary pt-2 border-t border-[#E2E8F0] flex justify-between">
                    <span>مدیر تیم: <strong className="text-text-main">{manager?.name || '-'}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* ===================== TAB: INTEGRATIONS ===================== */}
      {tab === 'INTEGRATIONS' && (
        <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
          <h3 className="font-bold text-lg text-text-main flex items-center gap-2">
            <Link2 className="w-5 h-5 text-primary" /> وضعیت کاتالوگ و پایگاه داده محلی (Offline Storage)
          </h3>
          <div className="space-y-3 text-xs">
            <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] flex justify-between items-center">
              <div>
                <strong className="text-sm font-bold text-text-main block">کاتالوگ کالاها و خدمات (CPQ External Products)</strong>
                <span className="text-text-secondary mt-0.5 block">{state.externalProducts?.length || 0} قلم کالای فعال بارگذاری شده است.</span>
              </div>
              <span className="px-2.5 py-1 bg-[#F0FDF4] text-[#166534] text-xs font-bold rounded-lg">همگام با حافظه محلی</span>
            </div>
            <div className="p-4 bg-canvas rounded-xl border border-[#E2E8F0] flex justify-between items-center">
              <div>
                <strong className="text-sm font-bold text-text-main block">صف آفلاین و ماندگاری IndexedDB</strong>
                <span className="text-text-secondary mt-0.5 block">تمام تغییرات مشتریان، سفارشات و تسک‌ها در IndexedDB مرورگر ذخیره و پایدار می‌شوند.</span>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setExportNotice('حافظه محلی با موفقیت بازبینی و به‌روزرسانی شد.');
                  setTimeout(() => setExportNotice(null), 2500);
                }}
              >
                بررسی یکپارچگی داده‌ها
              </Button>
            </div>
            {exportNotice && <div className="p-3 bg-primary/10 text-primary rounded-xl font-bold">{exportNotice}</div>}
          </div>
        </Card>
      )}

      {/* Modals for Role and User */}
      {showRoleModal && (
        <Modal isOpen={showRoleModal} onClose={() => setShowRoleModal(false)} title="تعریف نقش سازمانی جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setShowRoleModal(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateRole}>ثبت نقش</Button></>}>
          <div className="space-y-4 text-xs">
            <Input label="عنوان نقش سازمانی *" value={newRoleName} onChange={e => setNewRoleName(e.target.value)} placeholder="مثال: سرپرست فروش منطقه شمال" required />
            <div>
              <label className="block font-bold mb-1 text-text-main">محدوده دسترسی اطلاعاتی (Visibility Scope) *</label>
              <select value={newRoleScope} onChange={e => setNewRoleScope(e.target.value as VisibilityScope)} className="w-full bg-canvas border border-[#E2E8F0] p-2.5 rounded-xl outline-none font-bold">
                <option value="ORG">تمام سازمان (ORG)</option>
                <option value="BRANCH">شعبه سازمانی (BRANCH)</option>
                <option value="TERRITORY">قلمرو جغرافیایی (TERRITORY)</option>
                <option value="TEAM">تیم کاری (TEAM)</option>
                <option value="OWNER">فقط رکوردهای شخصی (OWNER)</option>
              </select>
            </div>
            <div>
              <label className="block font-bold mb-1 text-text-main">فضای کاری پیش‌فرض *</label>
              <select value={newRoleWorkspace} onChange={e => setNewRoleWorkspace(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] p-2.5 rounded-xl outline-none font-bold">
                <option value="dashboard">داشبورد مدیریتی</option>
                <option value="accounts">حساب‌ها و مشتریان</option>
                <option value="tasks">وظایف و پیگیری‌ها</option>
                <option value="quotes">پیش‌فاکتورها و CPQ</option>
                <option value="leads">سرنخ‌های فروش</option>
              </select>
            </div>
          </div>
        </Modal>
      )}

      {showUserModal && (
        <Modal isOpen={showUserModal} onClose={() => setShowUserModal(false)} title="تعریف کاربر جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setShowUserModal(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateUser}>ثبت کاربر</Button></>}>
          <div className="space-y-4 text-xs">
            <Input label="نام و نام خانوادگی *" value={newUserName} onChange={e => setNewUserName(e.target.value)} placeholder="مثال: مهدی حسینی" required />
            <Input label="نام کاربری (کد پرسنلی) *" value={newUserLogin} onChange={e => setNewUserLogin(e.target.value)} placeholder="مثال: m.hosseini" required dir="ltr" />
            <div>
              <label className="block font-bold mb-1 text-text-main">نقش سازمانی (Role - SEE) *</label>
              <select value={newUserRoleId} onChange={e => setNewUserRoleId(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] p-2.5 rounded-xl outline-none font-bold">
                <option value="">انتخاب نقش سازمانی...</option>
                {(state.roles || []).map(r => <option key={r.id} value={r.id}>{r.name} ({r.visibilityScope})</option>)}
              </select>
            </div>
            <div>
              <label className="block font-bold mb-1 text-text-main">پروفایل عملیاتی (Permission Set - DO) *</label>
              <select value={newUserPermSetId} onChange={e => setNewUserPermSetId(e.target.value)} className="w-full bg-canvas border border-[#E2E8F0] p-2.5 rounded-xl outline-none font-bold">
                <option value="">انتخاب پروفایل دسترسی...</option>
                {(state.permissionSets || []).map(ps => <option key={ps.id} value={ps.id}>{ps.name}</option>)}
              </select>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
