import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState, UserGroup, GroupMessage, Mention, ID } from '../types';
import { generateId, formatAppDate } from '../lib/utils';
import { processMessageMentions } from '../lib/collaboration';
import { Users, Send, Building2, CheckSquare, Search, Plus, MessageCircle, Paperclip, CheckCheck, UserPlus, FileText, TrendingUp, ShieldAlert, Activity } from 'lucide-react';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Modal } from './ui/Modal';
import { Avatar } from './ui/Avatar';
import { RBACService } from '../lib/rbac';
import { AttachmentManager } from './ui/AttachmentManager';

interface GroupsWorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
  setActiveTab?: (tab: any) => void;
}

export function GroupsWorkspace({ state, updateState }: GroupsWorkspaceProps) {
  const navigate = useNavigate();
  const currentUserId = state.currentUserId || '';
  const rbac = new RBACService(state);
  const isAdmin = rbac.hasPermission('internal.manage') || rbac.hasPermission('settings.manage');

  const myGroups = (state.groups || []).filter(g => isAdmin || g.memberIds.includes(currentUserId));
  
  const [activeGroupId, setActiveGroupId] = useState<string | null>(() => myGroups.length > 0 ? myGroups[0].id : null);
  const [messageInput, setMessageInput] = useState('');
  
  const [showAttachModal, setShowAttachModal] = useState(false);
  const [attachedEntity, setAttachedEntity] = useState<{ type: 'ACCOUNT' | 'TASK' | 'QUOTE' | 'OPPORTUNITY' | 'CASE' | 'REQUEST'; id: ID; display: string } | undefined>(undefined);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  
  const [showMembersModal, setShowMembersModal] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);

  const activeGroup = (state.groups || []).find(g => g.id === activeGroupId);
  const activeMessages = (state.messages || [])
    .filter((m: any) => m.groupId === activeGroupId)
    .sort((a: any, b: any) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  useEffect(() => {
    if (activeGroupId && currentUserId) {
      const hasUnread = (state.messages || []).some((m: any) => m.groupId === activeGroupId && !m.readBy?.includes(currentUserId));
      if (!hasUnread) return;

      updateState((draft: AppState) => {
        if (!draft.messages) draft.messages = [];
        draft.messages.forEach((m: any) => {
          if (m.groupId === activeGroupId && !m.readBy?.includes(currentUserId)) {
            m.readBy.push(currentUserId);
          }
        });
      });
    }
  }, [activeGroupId, state.messages, currentUserId, updateState]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeMessages.length, activeGroupId]);

  const handleSendMessage = () => {
    if ((!messageInput.trim() && !attachedEntity) || !activeGroup) return;

    const mentions: Mention[] = [];
    const words = messageInput.split(' ');
    words.forEach(w => {
      if (w.startsWith('@')) {
        const query = w.substring(1).toLowerCase();
        const user = state.users.find(u => u.username?.toLowerCase() === query || u.name?.toLowerCase().includes(query));
        if (user) mentions.push({ id: user.id, type: 'USER', display: `@${user.name}` });
      }
    });

    const newMsg: GroupMessage = {
      id: generateId(),
      groupId: activeGroup.id,
      senderId: currentUserId,
      content: messageInput.trim(),
      mentions,
      relatedEntity: attachedEntity,
      createdAt: new Date().toISOString(),
      readBy: [currentUserId]
    };

    updateState((draft: AppState) => {
      if (!draft.messages) draft.messages = [];
      draft.messages.push(newMsg);
      processMessageMentions(newMsg, activeGroup.name, state, draft);
    });

    setMessageInput('');
    setAttachedEntity(undefined);
  };

  const handleCreateGroup = () => {
    if (!newGroupName.trim()) return;
    const newGroup: UserGroup = {
      id: generateId(),
      name: newGroupName.trim(),
      description: newGroupDesc.trim(),
      managerId: currentUserId,
      memberIds: [...new Set([...selectedMembers, currentUserId])],
      active: true
    };
    updateState((draft: AppState) => {
      if (!draft.groups) draft.groups = [];
      draft.groups.push(newGroup as any);
    });
    setNewGroupName(''); 
    setNewGroupDesc(''); 
    setSelectedMembers([]); 
    setShowCreateModal(false);
    setActiveGroupId(newGroup.id);
  };

  const handleToggleMember = (userId: string) => {
    if (!activeGroup) return;
    updateState((draft: AppState) => {
      const group = (draft.groups || []).find(g => g.id === activeGroup.id);
      if (!group) return;
      if (group.memberIds.includes(userId)) {
        if (group.memberIds.length > 1) {
          group.memberIds = group.memberIds.filter(id => id !== userId);
        }
      } else {
        group.memberIds.push(userId);
      }
    });
  };

  const navigateToEntity = (entity: { type: string; id: ID }) => {
    if (entity.type === 'ACCOUNT') {
      updateState(d => { d.activeContextAccountId = entity.id; d.activeContextCustomerId = entity.id; });
      navigate(`/accounts/${entity.id}`);
    } else if (entity.type === 'TASK') {
      navigate('/tasks');
    } else if (entity.type === 'QUOTE') {
      navigate('/quotes');
    } else if (entity.type === 'OPPORTUNITY') {
      navigate('/opportunities');
    } else if (entity.type === 'CASE') {
      navigate('/cases');
    } else if (entity.type === 'REQUEST') {
      navigate('/internal_automation');
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 h-full bg-canvas" dir="rtl">
      <div className="shrink-0 bg-canvas px-4 pt-4 pb-2 space-y-4 z-10 border-b border-[#E2E8F0]">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-extrabold text-text-main tracking-tight flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" /> گروه‌ها و تعاملات سازمانی
            </h2>
            <span className="text-xs text-text-secondary">گفتگوی گروهی، منشن همکاران و اتصال مستقیم به داده‌های CRM</span>
          </div>
          {isAdmin && (
            <Button variant="primary" onClick={() => setShowCreateModal(true)} icon={<Plus className="w-4 h-4"/>}>
              گروه جدید
            </Button>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row gap-4 min-h-0 p-4 pb-20 md:pb-6">
        <div className="w-full md:w-80 flex flex-col bg-white border border-[#E2E8F0] rounded-2xl overflow-hidden shrink-0 shadow-sm">
          <div className="p-3 bg-canvas border-b border-[#E2E8F0] font-bold text-xs text-text-main flex items-center justify-between">
            <span>گروه‌های شما</span>
            <span className="text-xs text-text-secondary font-mono">{myGroups.length} گروه</span>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {myGroups.length > 0 ? myGroups.map(g => {
              const unreadCount = (state.messages || []).filter((m: any) => m.groupId === g.id && !m.readBy?.includes(currentUserId)).length;
              const isSelected = g.id === activeGroupId;
              return (
                <button 
                  key={g.id} 
                  onClick={() => setActiveGroupId(g.id)}
                  className={`w-full text-right p-3 rounded-xl flex justify-between items-center transition-all cursor-pointer border ${isSelected ? 'bg-primary/5 border-primary/20 shadow-sm' : 'hover:bg-canvas border-transparent'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${isSelected ? 'bg-primary/10 text-primary' : 'bg-canvas text-text-secondary'}`}>
                      <Users size={16} />
                    </div>
                    <div>
                      <strong className={`text-xs block truncate max-w-[140px] ${isSelected ? 'font-extrabold text-text-main' : 'font-bold text-text-main'}`}>{g.name}</strong>
                      <span className="text-[10px] text-text-secondary block mt-0.5">{g.memberIds.length} عضو</span>
                    </div>
                  </div>
                  {unreadCount > 0 && (
                    <span className="bg-red-500 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">
                      {unreadCount}
                    </span>
                  )}
                </button>
              );
            }) : (
              <div className="p-6 text-center text-xs text-text-secondary">عضو هیچ گروه کاری نیستید.</div>
            )}
          </div>
        </div>

        <div className="flex-1 flex flex-col bg-white border border-[#E2E8F0] rounded-2xl overflow-hidden shadow-sm">
          {activeGroup ? (
            <>
              <div className="p-3.5 border-b border-[#E2E8F0] bg-canvas flex items-center justify-between shadow-sm z-10">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-bold">
                    <Users size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-text-main">{activeGroup.name}</h3>
                    <span className="text-[11px] text-text-secondary block truncate max-w-md">{activeGroup.description || 'گروه گفتگوی تیمی CRM'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-text-secondary hidden sm:inline">{activeGroup.memberIds.length} عضو</span>
                  <Button size="sm" variant="outline" onClick={() => setShowMembersModal(true)} icon={<UserPlus size={14}/>}>
                    اعضا
                  </Button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-canvas/40" ref={scrollRef}>
                {activeMessages.length > 0 ? activeMessages.map((m: any) => {
                  const isMe = m.senderId === currentUserId;
                  const sender = state.users.find(u => u.id === m.senderId);
                  
                  return (
                    <div key={m.id} className={`flex gap-2.5 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                      <Avatar name={sender?.name || 'کاربر'} size="sm" className="mt-1 shrink-0" />
                      <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[80%]`}>
                        <div className="flex items-center gap-2 mb-1 px-1">
                          <span className="text-[10px] font-bold text-text-secondary">{isMe ? 'شما' : sender?.name}</span>
                          <span className="text-[9px] font-mono text-text-secondary">{formatAppDate(m.createdAt, state.settings?.locale)}</span>
                        </div>

                        <div className={`p-3.5 rounded-2xl text-xs leading-relaxed ${isMe ? 'bg-primary text-white rounded-tr-none shadow-sm' : 'bg-white border border-[#E2E8F0] text-text-main rounded-tl-none shadow-sm'}`}>
                          {m.content}

                          {m.relatedEntity && (
                            <button
                              type="button"
                              onClick={() => navigateToEntity(m.relatedEntity!)}
                              className={`mt-2 p-2 rounded-xl flex items-center gap-2 w-full text-right transition-colors cursor-pointer border ${isMe ? 'bg-primary-hover border-white/20 text-white' : 'bg-canvas border-[#E2E8F0] text-text-main hover:bg-[#EAECEF]'}`}
                            >
                              {m.relatedEntity.type === 'ACCOUNT' && <Building2 size={14} className="shrink-0 text-amber-500" />}
                              {m.relatedEntity.type === 'TASK' && <CheckSquare size={14} className="shrink-0 text-amber-600" />}
                              {m.relatedEntity.type === 'QUOTE' && <FileText size={14} className="shrink-0 text-[#0284C7]" />}
                              {m.relatedEntity.type === 'OPPORTUNITY' && <TrendingUp size={14} className="shrink-0 text-[#0284C7]" />}
                              {m.relatedEntity.type === 'CASE' && <ShieldAlert size={14} className="shrink-0 text-red-500" />}
                              {m.relatedEntity.type === 'REQUEST' && <Activity size={14} className="shrink-0 text-primary" />}
                              <span className="text-[11px] font-bold truncate">مشاهده رکورد: {m.relatedEntity.display}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                }) : (
                  <div className="h-full flex items-center justify-center text-text-secondary text-xs flex-col gap-2 py-12">
                    <MessageCircle size={36} className="opacity-20" />
                    <p className="font-semibold">اینجا پیام یا گفتگویی ثبت نشده است.</p>
                    <p className="text-[10px] text-text-secondary">برای شروع ارتباط تیمی، پیام خود را در کادر زیر بنویسید.</p>
                  </div>
                )}
              </div>

              <div className="p-3 border-t border-[#E2E8F0] bg-white space-y-2">
                {attachedEntity && (
                  <div className="bg-primary/10 border border-primary/20 px-3 py-1.5 rounded-xl text-xs flex justify-between items-center">
                    <span className="text-primary font-bold flex items-center gap-1.5">
                      <Paperclip size={13} /> رکورد ضمیمه‌شده: {attachedEntity.display}
                    </span>
                    <button type="button" onClick={() => setAttachedEntity(undefined)} className="text-text-secondary hover:text-text-main text-xs font-bold cursor-pointer">حذف</button>
                  </div>
                )}

                <div className="flex gap-2 items-center">
                  <button 
                    type="button" 
                    onClick={() => setShowAttachModal(true)}
                    className="p-2.5 text-text-secondary hover:text-primary hover:bg-canvas rounded-xl transition-colors cursor-pointer border border-[#E2E8F0]"
                    title="اتصال به رکورد CRM"
                  >
                    <Paperclip size={18} />
                  </button>

                  <input 
                    type="text" 
                    value={messageInput}
                    onChange={e => setMessageInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                    placeholder="پیام خود را بنویسید (از @ برای منشن استفاده نمایید)..."
                    className="flex-1 bg-canvas border border-[#E2E8F0] rounded-xl px-4 py-2.5 outline-none focus:border-primary text-xs font-medium transition-all"
                  />

                  <Button variant="primary" onClick={handleSendMessage} icon={<Send size={16}/>} className="px-4">
                    ارسال
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-text-secondary text-xs space-y-3 p-6 text-center">
              <span>برای شروع، یک گروه از فهرست انتخاب کنید یا گروه کاری جدید بسازید.</span>
              <Button variant="primary" size="sm" onClick={() => setShowCreateModal(true)} icon={<Plus size={14}/>}>
                ایجاد گروه جدید
              </Button>
            </div>
          )}
        </div>
      </div>

      {showCreateModal && (
        <Modal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} title="ایجاد گروه کاری جدید" footer={<><Button variant="ghost" size="sm" onClick={() => setShowCreateModal(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleCreateGroup}>ثبت گروه</Button></>}>
          <div className="space-y-4 text-xs">
            <Input label="نام گروه *" value={newGroupName} onChange={e => setNewGroupName(e.target.value)} placeholder="مثال: تیم فروش برتر" required />
            <div>
              <label className="block font-bold text-text-main mb-1">شرح و هدف گروه</label>
              <textarea value={newGroupDesc} onChange={e => setNewGroupDesc(e.target.value)} className="w-full border border-[#E2E8F0] p-2.5 rounded-xl bg-canvas outline-none focus:border-primary" rows={2} placeholder="توضیحات کوتاه..." />
            </div>
            <div>
              <label className="block font-bold text-text-main mb-1">انتخاب اعضا</label>
              <select multiple value={selectedMembers} onChange={e => setSelectedMembers(Array.from(e.target.selectedOptions, (o: HTMLOptionElement) => o.value))} className="w-full border border-[#E2E8F0] p-2.5 rounded-xl bg-canvas outline-none focus:border-primary h-32">
                {state.users.filter(u => u.id !== currentUserId).map(u => (
                  <option key={u.id} value={u.id}>{u.name} (@{u.username})</option>
                ))}
              </select>
            </div>
          </div>
        </Modal>
      )}

      {showMembersModal && activeGroup && (
        <Modal isOpen={showMembersModal} onClose={() => setShowMembersModal(false)} title={`اعضای گروه: ${activeGroup.name}`} footer={<Button variant="primary" size="sm" onClick={() => setShowMembersModal(false)}>بستن</Button>}>
          <div className="space-y-3 text-xs max-h-80 overflow-y-auto">
            {state.users.map(u => {
              const isMember = activeGroup.memberIds.includes(u.id);
              return (
                <div key={u.id} className="flex justify-between items-center p-2.5 bg-canvas rounded-xl border border-[#E2E8F0]">
                  <div className="flex items-center gap-2">
                    <Avatar name={u.name} size="sm" />
                    <div>
                      <strong className="block text-text-main">{u.name}</strong>
                      <span className="text-[10px] text-text-secondary">@{u.username}</span>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant={isMember ? "outline" : "primary"}
                    onClick={() => handleToggleMember(u.id)}
                  >
                    {isMember ? "حذف عضویت" : "افزودن به گروه"}
                  </Button>
                </div>
              );
            })}
          </div>
        </Modal>
      )}

      {showAttachModal && (
        <Modal isOpen={showAttachModal} onClose={() => setShowAttachModal(false)} title="ضمیمه کردن رکورد CRM به گفتگو" footer={<Button variant="ghost" size="sm" onClick={() => setShowAttachModal(false)}>انصراف</Button>}>
          <div className="space-y-3 text-xs max-h-80 overflow-y-auto">
            <span className="text-text-secondary block mb-2">مشتریان و رکوردهای فعال شما:</span>
            
            {(state.accounts || []).slice(0, 5).map(acc => (
              <button 
                key={acc.id}
                onClick={() => {
                  setAttachedEntity({ type: 'ACCOUNT', id: acc.id, display: `مشتری: ${acc.name}` });
                  setShowAttachModal(false);
                }}
                className="w-full p-2.5 bg-canvas hover:bg-primary/5 rounded-xl border border-[#E2E8F0] text-right flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Building2 size={16} className="text-primary shrink-0"/>
                <strong className="text-text-main">{acc.name}</strong>
              </button>
            ))}

            {(state.tasks || []).slice(0, 5).map(tsk => (
              <button 
                key={tsk.id}
                onClick={() => {
                  setAttachedEntity({ type: 'TASK', id: tsk.id, display: `تسک: ${tsk.title}` });
                  setShowAttachModal(false);
                }}
                className="w-full p-2.5 bg-canvas hover:bg-amber-50 rounded-xl border border-[#E2E8F0] text-right flex items-center gap-2 transition-colors cursor-pointer"
              >
                <CheckSquare size={16} className="text-amber-600 shrink-0"/>
                <strong className="text-text-main">{tsk.title}</strong>
              </button>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}
