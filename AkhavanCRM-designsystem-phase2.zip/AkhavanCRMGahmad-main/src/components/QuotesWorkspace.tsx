import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppState, Quote, QuoteLine, ID, ExternalProduct, PriceWaterfallBreakdown } from '../types';
import { generateId, formatCurrency, cleanNumericInput, formatInputCurrency, parsePersianNumber, formatAppDate } from '../lib/utils';
import { calculateQuoteLineMargin, calculatePriceWaterfall } from '../lib/cpqEngine';
import { emitBusinessEvent } from '../lib/events';
import { Card } from './ui/Card';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { FileText, Send, CheckCircle2, AlertTriangle, Plus, Trash2, ArrowRight, Printer, Sparkles, Building2, Layers, ChevronDown, BarChart2 } from 'lucide-react';
import { CustomerInvoicePrint } from './PrintLayouts';
import { ProfitModal } from './ProfitModal';
import { QuoteWizardModal } from './QuoteWizardModal';

interface QuotesWorkspaceProps {
  state: AppState;
  updateState: (updater: (draft: AppState) => AppState | void) => void;
  setActiveTab?: (tab: any) => void;
}

export function QuotesWorkspace({ state, updateState, setActiveTab }: QuotesWorkspaceProps) {
  const navigate = useNavigate();
  const [activeQuoteId, setActiveQuoteId] = useState<ID | null>(() => {
    return state.quotes[0]?.id || null;
  });
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isBundleModalOpen, setIsBundleModalOpen] = useState(false);
  const [isProfitModalOpen, setIsProfitModalOpen] = useState(false);
  const [waterfallBreakdown, setWaterfallBreakdown] = useState<{ title: string; breakdown: PriceWaterfallBreakdown } | null>(null);
  const [selectedAccountId, setSelectedAccountId] = useState<ID>(state.activeContextAccountId || state.accounts[0]?.id || '');
  const [selectedProductId, setSelectedProductId] = useState<ID>(state.externalProducts[0]?.id || '');
  const [lineQuantity, setLineQuantity] = useState<string>('1');
  const [linePrice, setLinePrice] = useState<string>(() => String(state.externalProducts[0]?.basePrice || ''));

  const activeQuote = state.quotes.find(q => q.id === activeQuoteId) || state.quotes[0];
  const threshold = state.settings?.quoteApprovalMarginThreshold || 15;

  const handleCreateDraftQuote = () => {
    const accId = state.activeContextAccountId || state.accounts[0]?.id;
    if (!accId) {
      alert('ابتدا حداقل یک حساب یا مشتری در سیستم تعریف کنید.');
      return;
    }
    const newId = generateId();
    const newQuoteNumber = `QT-${Date.now().toString().slice(-6)}`;
    updateState(draft => {
      const newQuote: Quote = {
        id: newId,
        quoteNumber: newQuoteNumber,
        accountId: accId,
        ownerId: state.currentUserId || 'usr_admin',
        status: 'DRAFT',
        lines: [],
        versions: [{
          versionNumber: 1,
          totalAmount: 0,
          marginPercent: 0,
          createdAt: new Date().toISOString(),
          createdBy: state.currentUserId || 'usr_admin'
        }],
        totalAmount: 0,
        marginPercent: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      draft.quotes.unshift(newQuote);
      if (!draft.auditLogs) draft.auditLogs = [];
      draft.auditLogs.push({
        id: generateId(),
        action: 'QUOTE_CREATED',
        entityType: 'QUOTE',
        entityId: newId,
        details: `پیش‌فاکتور جدید ${newQuoteNumber} ایجاد شد`,
        actor: state.users.find(u => u.id === state.currentUserId)?.name || 'System',
        createdAt: new Date().toISOString()
      });
    });
    setActiveQuoteId(newId);
  };

  const handleAddLine = () => {
    if (!activeQuote) return;
    const prod = state.externalProducts.find(p => p.id === selectedProductId);
    if (!prod) return;

    const unitPrice = parsePersianNumber(linePrice) || prod.basePrice;
    const quantity = Math.max(1, parsePersianNumber(lineQuantity) || 1);
    const costPrice = prod.costPrice;
    const lineTotal = unitPrice * quantity;

    updateState(draft => {
      const q = draft.quotes.find(item => item.id === activeQuote.id);
      if (!q) return;

      const newLine: QuoteLine = {
        id: generateId(),
        productId: prod.id,
        quantity,
        unitPrice,
        costPrice,
        lineTotal
      };
      q.lines.push(newLine);

      const totalAmount = q.lines.reduce((sum, l) => sum + l.lineTotal, 0);
      const totalCost = q.lines.reduce((sum, l) => sum + (l.costPrice * l.quantity), 0);
      const totalProfit = totalAmount - totalCost;
      const marginPercent = totalAmount > 0 ? Math.round((totalProfit / totalAmount) * 1000) / 10 : 0;

      q.totalAmount = totalAmount;
      q.marginPercent = marginPercent;
      q.updatedAt = new Date().toISOString();
    });

    setIsAddModalOpen(false);
  };

  const handleAddBundle = (bundleId: ID) => {
    if (!activeQuote) return;
    const bundle = (state.productBundles || []).find((b: any) => b.id === bundleId);
    if (!bundle) return;

    updateState(draft => {
      const q = draft.quotes.find(item => item.id === activeQuote.id);
      if (!q) return;

      bundle.productIds.forEach((prodId: string) => {
        const prod = state.externalProducts.find(p => p.id === prodId);
        if (prod) {
          const discountMultiplier = (100 - bundle.discountPercent) / 100;
          const discountedPrice = Math.round(prod.basePrice * discountMultiplier);
          q.lines.push({
            id: generateId(),
            productId: prod.id,
            quantity: 1,
            unitPrice: discountedPrice,
            costPrice: prod.costPrice,
            lineTotal: discountedPrice,
            appliedTiers: [bundle.name]
          });
        }
      });

      const totalAmount = q.lines.reduce((sum, l) => sum + l.lineTotal, 0);
      const totalCost = q.lines.reduce((sum, l) => sum + (l.costPrice * l.quantity), 0);
      const totalProfit = totalAmount - totalCost;
      const marginPercent = totalAmount > 0 ? Math.round((totalProfit / totalAmount) * 1000) / 10 : 0;

      q.totalAmount = totalAmount;
      q.marginPercent = marginPercent;
      q.updatedAt = new Date().toISOString();
    });

    setIsBundleModalOpen(false);
  };

  const handleOpenLineWaterfall = (line: QuoteLine) => {
    const prod = state.externalProducts.find(p => p.id === line.productId);
    if (!prod) return;
    const contract = (state.contracts || []).find((c: any) => c.accountId === activeQuote.accountId);
    const rebate = contract?.rebatePercent || 0;
    const tier = (state.volumeTiers || []).find((vt: any) => vt.productId === prod.id && line.quantity >= vt.minQuantity);
    const volumeDiscountPercent = tier ? tier.discountPercent : 0;

    const breakdown = calculatePriceWaterfall({
      basePrice: prod.basePrice,
      quantity: line.quantity,
      costPrice: prod.costPrice,
      negotiatedUnitPrice: line.unitPrice,
      appliedVolumeDiscountPercent: volumeDiscountPercent,
      contractRebatePercent: rebate
    });

    setWaterfallBreakdown({
      title: `تحلیل آبشاری قیمت: ${prod.name}`,
      breakdown
    });
  };

  const handleRemoveLine = (lineId: ID) => {
    if (!activeQuote) return;
    updateState(draft => {
      const q = draft.quotes.find(item => item.id === activeQuote.id);
      if (!q) return;
      q.lines = q.lines.filter(l => l.id !== lineId);

      const totalAmount = q.lines.reduce((sum, l) => sum + l.lineTotal, 0);
      const totalCost = q.lines.reduce((sum, l) => sum + (l.costPrice * l.quantity), 0);
      const totalProfit = totalAmount - totalCost;
      const marginPercent = totalAmount > 0 ? Math.round((totalProfit / totalAmount) * 1000) / 10 : 0;

      q.totalAmount = totalAmount;
      q.marginPercent = marginPercent;
      q.updatedAt = new Date().toISOString();
    });
  };

  const handleAction = (action: 'REQUEST_APPROVAL' | 'APPROVE' | 'ACCEPT' | 'REJECT' | 'HANDOFF') => {
    if (!activeQuote) return;
    updateState(draft => {
      const quote = draft.quotes.find(q => q.id === activeQuote.id);
      if (!quote) return;

      if (action === 'REQUEST_APPROVAL') {
        quote.status = 'PENDING_APPROVAL';
        if (!draft.notifications) draft.notifications = [];
        draft.notifications.push({
          id: generateId(),
          title: `درخواست تایید پیش‌فاکتور ${quote.quoteNumber}`,
          message: `مارجین پیش‌فاکتور (${quote.marginPercent}٪) کمتر از حد آستانه (${threshold}٪) است و نیازمند تایید است.`,
          type: 'WARNING',
          read: false,
          createdAt: new Date().toISOString(),
          linkTab: 'quotes'
        });
      }

      if (action === 'APPROVE') {
        quote.status = 'APPROVED';
        if (!draft.notifications) draft.notifications = [];
        draft.notifications.push({
          id: generateId(),
          title: `پیش‌فاکتور ${quote.quoteNumber} تایید شد`,
          message: `مدیریت پیش‌فاکتور را با مارجین ${quote.marginPercent}٪ تایید کرد.`,
          type: 'SUCCESS',
          read: false,
          createdAt: new Date().toISOString(),
          linkTab: 'quotes'
        });
      }

      if (action === 'ACCEPT') {
        quote.status = 'ACCEPTED';
        
        // Auto-generate invoice if not exists
        if (!draft.invoices) draft.invoices = [];
        const existingInv = draft.invoices.find(i => i.invoiceNumber === `INV-${quote.quoteNumber.replace('QT-', '')}`);
        if (!existingInv) {
          const invId = generateId();
          const invNum = `INV-${quote.quoteNumber.replace('QT-', '')}`;
          const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
          
          draft.invoices.unshift({
            id: invId,
            invoiceNumber: invNum,
            accountId: quote.accountId || '',
            customerId: quote.accountId || '',
            totalAmount: quote.totalAmount,
            paidAmount: 0,
            balance: quote.totalAmount,
            status: 'UNPAID',
            date: new Date().toISOString().split('T')[0],
            dueDate,
            items: (quote.lines || []).map(l => ({
              id: generateId(),
              description: `${l.productName} (${l.productCode})`,
              quantity: l.quantity,
              unitPrice: l.unitPrice,
              total: l.totalPrice
            }))
          });

          // Update customer balance
          const customer = draft.accounts?.find(a => a.id === quote.accountId);
          if (customer) {
            customer.balance = (customer.balance || 0) + quote.totalAmount;
          }

          if (!draft.timelineEvents) draft.timelineEvents = [];
          draft.timelineEvents.unshift({
            id: generateId(),
            customerId: quote.accountId || '',
            type: 'INVOICE',
            title: `صدور خودکار فاکتور رسمی ${invNum}`,
            description: `فاکتور رسمی به مبلغ ${quote.totalAmount.toLocaleString('fa-IR')} ریال از روی پیش‌فاکتور ${quote.quoteNumber} صادر شد.`,
            dateTime: new Date().toISOString()
          });

          if (!draft.auditLogs) draft.auditLogs = [];
          draft.auditLogs.unshift({
            id: generateId(),
            action: 'INVOICE_GENERATED_FROM_QUOTE',
            entityType: 'INVOICE',
            entityId: invId,
            details: `فاکتور رسمی ${invNum} بر اساس تایید پیش‌فاکتور ${quote.quoteNumber} ایجاد گردید.`,
            actor: 'System / User',
            createdAt: new Date().toISOString()
          });
        }
      }

      if (action === 'REJECT') {
        quote.status = 'REJECTED';
      }

      if (action === 'HANDOFF') {
        quote.status = 'HANDOFF_EXTERNAL';
        quote.externalOrderId = `EXT-${Date.now().toString().slice(-6)}`;
        
        const productCosts: Record<string, number> = {};
        const productBasePrices: Record<string, number> = {};
        quote.lines.forEach(l => {
          const ext = state.externalProducts.find(p => p.id === l.productId);
          if (ext) {
            productCosts[l.productId] = ext.costPrice;
            productBasePrices[l.productId] = ext.basePrice;
          }
        });
        quote.pricingSnapshot = {
          capturedAt: new Date().toISOString(),
          rulesApplied: ['STD_DISCOUNT_TIER1'],
          productCosts,
          productBasePrices
        };

        if (!draft.auditLogs) draft.auditLogs = [];
        draft.auditLogs.push({
          id: generateId(),
          action: 'QUOTE_HANDOFF',
          entityType: 'QUOTE',
          entityId: quote.id,
          details: `تحویل به سیستم ثبت سفارشات مرکزی انجام شد با شماره ارجاع ${quote.externalOrderId} و قفل اسنپ‌شات قیمت`,
          actor: 'System',
          createdAt: new Date().toISOString()
        });
        if (!draft.notifications) draft.notifications = [];
        draft.notifications.push({
          id: generateId(),
          title: `سفارش به سیستم خارجی تحویل شد`,
          message: `پیش‌فاکتور ${quote.quoteNumber} با شماره پیگیری ${quote.externalOrderId} به واحد انبار و لجستیک ارسال گردید و اسنپ‌شات قیمت قفل شد.`,
          type: 'INFO',
          read: false,
          createdAt: new Date().toISOString(),
          linkTab: 'quotes'
        });
      }
      quote.updatedAt = new Date().toISOString();
    });

    if (action === 'APPROVE') {
      emitBusinessEvent('QUOTE_APPROVED', 'QUOTE', activeQuote.id, activeQuote, state, updateState);
    }
    if (action === 'HANDOFF') {
      emitBusinessEvent('QUOTE_HANDOFF', 'QUOTE', activeQuote.id, activeQuote, state, updateState);
    }
  };

  const handleConvertToInvoice = () => {
    if (!activeQuote) return;
    const invId = generateId();
    const invNum = `INV-${activeQuote.quoteNumber.replace('QT-', '')}`;
    const invoiceItems = activeQuote.lines.map(line => {
      const prod = state.externalProducts.find(p => p.id === line.productId);
      return {
        id: generateId(),
        description: prod?.name || `کالای کد ${line.productId}`,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        total: line.lineTotal
      };
    });

    updateState(draft => {
      if (!draft.invoices) draft.invoices = [];
      const newInvoice = {
        id: invId,
        invoiceNumber: invNum,
        accountId: activeQuote.accountId || '',
        customerId: activeQuote.accountId || '',
        totalAmount: activeQuote.totalAmount,
        paidAmount: 0,
        balance: activeQuote.totalAmount,
        status: 'UNPAID' as const,
        date: new Date().toISOString(),
        dueDate: new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0],
        items: invoiceItems
      };
      draft.invoices.unshift(newInvoice);

      const acc = (draft.accounts || []).find(a => a.id === activeQuote.accountId);
      if (acc) {
        acc.balance = (acc.balance || 0) + activeQuote.totalAmount;
        acc.totalRevenue = (acc.totalRevenue || 0) + activeQuote.totalAmount;
      }

      const q = draft.quotes.find(item => item.id === activeQuote.id);
      if (q) {
        q.status = 'ACCEPTED';
        (q as any).invoicedId = invId;
      }

      if (!draft.notifications) draft.notifications = [];
      draft.notifications.push({
        id: generateId(),
        title: `فاکتور رسمی صادر شد`,
        message: `پیش‌فاکتور ${activeQuote.quoteNumber} با موفقیت به فاکتور رسمی مالی ${invNum} تبدیل گردید.`,
        type: 'SUCCESS',
        read: false,
        createdAt: new Date().toISOString(),
        linkTab: 'finance'
      });
    });

    navigate('/finance');
  };

  const getStatusBadge = (status: Quote['status']) => {
    switch (status) {
      case 'DRAFT': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-canvas text-text-secondary">پیش‌نویس (DRAFT)</span>;
      case 'PENDING_APPROVAL': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-50 text-[#92400E]">در انتظار تایید مدیریت</span>;
      case 'APPROVED': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-sky-50 text-[#075985]">تایید شده توسط مدیریت</span>;
      case 'SENT': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-primary/10 text-primary">ارسال به مشتری</span>;
      case 'ACCEPTED': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-[#F0FDF4] text-[#166534]">تایید نهایی مشتری</span>;
      case 'REJECTED': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-red-50 text-[#991B1B]">رد شده</span>;
      case 'HANDOFF_EXTERNAL': return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-primary/20 text-primary-hover">ارسال به ERP (تحویل نهایی)</span>;
      default: return <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-100 text-slate-600">{status}</span>;
    }
  };

  return (
    <div className="flex-1 overflow-auto bg-canvas p-4 sm:p-6 space-y-4" dir="rtl">
      <Card padding="md" className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white border-[#E2E8F0]">
        <div>
          <h2 className="text-lg font-bold text-text-main flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" /> میز پیش‌فاکتورها و پروپوزال‌های تجاری (CPQ)
          </h2>
          <span className="text-xs text-text-secondary block mt-0.5">
            پیکربندی قیمت، درخواست تاییدیه مارجین، و انتقال به سیستم ثبت سفارش خارجی
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="primary" onClick={() => setIsWizardOpen(true)} className="shadow-sm" icon={<Sparkles className="w-4 h-4" />}>
            صدور پیش‌فاکتور با ویزارد
          </Button>
          <Button variant="outline" onClick={handleCreateDraftQuote} icon={<Plus className="w-4 h-4" />}>
            پیش‌نویس سریع
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-text-secondary px-1">لیست پیش‌فاکتورها ({state.quotes.length})</h3>
          {state.quotes.map(q => {
            const acc = state.accounts.find(a => a.id === q.accountId);
            const isSelected = activeQuote?.id === q.id;
            return (
              <Card 
                key={q.id} 
                padding="md" 
                onClick={() => setActiveQuoteId(q.id)}
                className={`cursor-pointer transition-all border ${isSelected ? 'border-[#CBD5E1] bg-canvas shadow-sm' : 'border-transparent hover:bg-canvas bg-white'}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <strong className="text-sm font-bold text-text-main font-mono">{q.quoteNumber}</strong>
                    <div className="text-xs text-text-secondary mt-1 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-text-secondary" />
                      <span>{acc?.name || 'حساب نامشخص'}</span>
                    </div>
                  </div>
                  {getStatusBadge(q.status)}
                </div>
                <div className="flex justify-between items-center mt-3 pt-2 border-t border-[#E2E8F0] text-xs">
                  <span className="text-text-secondary">ارزش کل:</span>
                  <span className="font-bold font-mono text-text-main">{formatCurrency(q.totalAmount)} ریال</span>
                </div>
              </Card>
            );
          })}
        </div>

        <div className="lg:col-span-2 space-y-4">
          {activeQuote ? (
            <Card padding="lg" className="space-y-4 bg-white border-[#E2E8F0]">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 border-b border-[#E2E8F0] gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-text-main font-mono">{activeQuote.quoteNumber}</h3>
                    {getStatusBadge(activeQuote.status)}
                  </div>
                  <div className="text-xs text-text-secondary mt-1 flex flex-wrap gap-3">
                    <span>حساب: <strong className="cursor-pointer hover:text-primary" onClick={() => navigate(`/accounts/${activeQuote.accountId}`)}>{state.accounts.find(a => a.id === activeQuote.accountId)?.name}</strong></span>
                    <span>•</span>
                    <span>تاریخ: <strong className="font-mono">{formatAppDate(activeQuote.createdAt, state.settings?.locale)}</strong></span>
                    {activeQuote.externalOrderId && (
                      <span className="text-primary font-bold font-mono">شناسه سفارش خارجی: {activeQuote.externalOrderId}</span>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {activeQuote.status === 'DRAFT' && (
                    <>
                      <Button size="sm" variant="outline" onClick={() => handleAction('REQUEST_APPROVAL')}>
                        درخواست تایید مدیریت
                      </Button>
                      <Button size="sm" variant="primary" onClick={() => handleAction('APPROVE')}>
                        تایید قیمت
                      </Button>
                    </>
                  )}

                  {activeQuote.status === 'PENDING_APPROVAL' && (
                    <>
                      <Button size="sm" variant="success" onClick={() => handleAction('APPROVE')} icon={<CheckCircle2 className="w-3.5 h-3.5" />}>
                        تایید نهایی مدیریت
                      </Button>
                      <Button size="sm" variant="danger" onClick={() => handleAction('REJECT')}>
                        رد پیش‌فاکتور
                      </Button>
                    </>
                  )}

                  {activeQuote.status === 'APPROVED' && (
                    <Button size="sm" variant="primary" onClick={() => handleAction('ACCEPT')} icon={<CheckCircle2 className="w-3.5 h-3.5" />}>
                      ثبت تاییدیه مشتری
                    </Button>
                  )}

                  {(activeQuote.status === 'ACCEPTED' || activeQuote.status === 'HANDOFF_EXTERNAL') && (
                    <>
                      <Button size="sm" variant="success" className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleConvertToInvoice} icon={<FileText className="w-3.5 h-3.5" />}>
                        صدور فاکتور قطعی در بخش مالی
                      </Button>
                      {activeQuote.status === 'ACCEPTED' && (
                        <Button size="sm" variant="primary" className="bg-primary hover:bg-primary-hover text-white" onClick={() => handleAction('HANDOFF')} icon={<Send className="w-3.5 h-3.5" />}>
                          ارسال به سیستم فروش (Handoff)
                        </Button>
                      )}
                    </>
                  )}

                  <button onClick={() => setIsProfitModalOpen(true)} className="p-2 text-primary hover:text-primary-hover bg-primary/10 hover:bg-primary/20 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors" title="تحلیل اقتصادی و حاشیه سود">
                    <BarChart2 className="w-4 h-4" />
                    <span className="hidden sm:inline">تحلیل سود</span>
                  </button>

                  <button onClick={() => window.print()} className="p-2 text-text-secondary hover:text-text-main bg-canvas hover:bg-[#EAECEF] rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors" title="چاپ پیش‌فاکتور">
                    <Printer className="w-4 h-4" />
                    <span className="hidden sm:inline">چاپ</span>
                  </button>
                </div>
              </div>

              {activeQuote.marginPercent < threshold && activeQuote.lines.length > 0 && activeQuote.status === 'DRAFT' && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-[#92400E] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#92400E] shrink-0" />
                  <span>
                    مارجین ناخالص این پیش‌فاکتور ({activeQuote.marginPercent}٪) کمتر از کف مجاز سازمانی ({threshold}٪) است. پیش از نهایی‌سازی نیازمند درخواست مجوز و تایید مدیر بازرگانی است.
                  </span>
                </div>
              )}

              {activeQuote.pricingSnapshot && (
                <div className="p-3 bg-primary/10 text-primary text-xs rounded-xl border border-primary/20 flex items-center gap-2 font-medium">
                  <span className="font-mono font-bold">⚠️ این سند به سیستم انبار/سفارشات ارسال شده و وضعیت قیمت‌گذاری آن در زمان تایید (Snapshot) قفل و فریز گردیده است.</span>
                </div>
              )}

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-xs font-bold text-text-main">اقلام پیش‌فاکتور ({activeQuote.lines.length})</h4>
                  {activeQuote.status === 'DRAFT' && (
                    <div className="flex items-center gap-2">
                      {(state.productBundles || []).length > 0 && (
                        <button onClick={() => setIsBundleModalOpen(true)} className="text-xs text-primary font-bold hover:text-primary-hover flex items-center gap-1 cursor-pointer bg-primary/10 px-2.5 py-1 rounded-lg border border-primary/20">
                          <Layers className="w-3.5 h-3.5" /> افزودن بسته ترکیبی (Bundle)
                        </button>
                      )}
                      <button onClick={() => { const prod = state.externalProducts[0]; if (prod) { setSelectedProductId(prod.id); setLinePrice(String(prod.basePrice)); setLineQuantity('1'); } setIsAddModalOpen(true); }} className="text-xs text-[#166534] font-bold hover:text-[#14532D] flex items-center gap-1 cursor-pointer bg-[#F0FDF4] px-2.5 py-1 rounded-lg border border-[#BBF7D0]">
                        <Plus className="w-3.5 h-3.5" /> افزودن کالا از کاتالوگ
                      </button>
                    </div>
                  )}
                </div>

                <div className="border border-[#E2E8F0] rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-right">
                    <thead className="bg-canvas border-b border-[#E2E8F0] text-text-secondary font-semibold">
                      <tr>
                        <th className="p-3">شرح کالا (از سیستم خارجی)</th>
                        <th className="p-3">تعداد</th>
                        <th className="p-3">قیمت واحد (ریال)</th>
                        <th className="p-3">قیمت تمام‌شده</th>
                        <th className="p-3">مبلغ کل</th>
                        <th className="p-3 text-center">آبشار قیمت (CPQ)</th>
                        {activeQuote.status === 'DRAFT' && <th className="p-3 text-center">حذف</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E2E8F0]">
                      {activeQuote.lines.length > 0 ? (
                        activeQuote.lines.map(line => {
                          const prod = state.externalProducts.find(p => p.id === line.productId);
                          const marginInfo = calculateQuoteLineMargin(line, prod, threshold);
                          return (
                            <tr key={line.id} className="hover:bg-canvas/50">
                              <td className="p-3 font-semibold text-text-main">
                                <div className="flex items-center gap-1.5">
                                  <span>{prod?.name || 'کالای نامشخص'}</span>
                                  {line.appliedTiers && line.appliedTiers.length > 0 && (
                                    <span className="text-[10px] bg-primary/10 text-primary font-bold px-1.5 py-0.2 rounded">
                                      {line.appliedTiers.join(', ')}
                                    </span>
                                  )}
                                </div>
                                <span className="block text-[10px] text-text-secondary font-mono">{prod?.sku}</span>
                              </td>
                              <td className="p-3 font-mono font-bold">{line.quantity}</td>
                              <td className="p-3 font-mono">{formatCurrency(line.unitPrice)}</td>
                              <td className="p-3 font-mono text-text-secondary">{formatCurrency(line.costPrice)}</td>
                              <td className="p-3 font-mono font-bold text-primary">{formatCurrency(line.lineTotal)}</td>
                              <td className="p-3 text-center">
                                <button onClick={() => handleOpenLineWaterfall(line)} className="px-2 py-0.5 text-[11px] font-bold rounded-md bg-canvas hover:bg-[#EAECEF] text-text-main inline-flex items-center gap-1 transition-colors cursor-pointer" title="نمایش ریز محاسبات آبشاری قیمت">
                                  <BarChart2 size={12} className="text-primary" /> {marginInfo.marginPercent}٪
                                </button>
                              </td>
                              {activeQuote.status === 'DRAFT' && (
                                <td className="p-3 text-center">
                                  <button onClick={() => handleRemoveLine(line.id)} className="p-1 text-text-secondary hover:text-[#991B1B] rounded transition-colors cursor-pointer">
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              )}
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={7} className="p-6 text-center text-text-secondary">
                            هنوز کالایی به این پیش‌فاکتور افزوده نشده است.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-canvas p-4 rounded-xl border border-[#E2E8F0] grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div>
                  <span className="text-[11px] text-text-secondary block">مبلغ کل پیش‌فاکتور:</span>
                  <strong className="text-base font-bold font-mono text-text-main">
                    {formatCurrency(activeQuote.totalAmount)} ریال
                  </strong>
                </div>
                <div>
                  <span className="text-[11px] text-text-secondary block">حاشیه سود ناخالص (مارجین):</span>
                  <strong className={`text-base font-bold font-mono ${activeQuote.marginPercent < threshold ? 'text-[#92400E]' : 'text-[#166534]'}`}>
                    {activeQuote.marginPercent}٪
                  </strong>
                </div>
                <div>
                  <span className="text-[11px] text-text-secondary block">وضعیت مجوز مارجین:</span>
                  <span className="text-xs font-bold text-text-main">
                    {activeQuote.marginPercent >= threshold ? 'مجاز و بدون نیاز به تایید' : 'نیازمند تایید سرپرست فروش'}
                  </span>
                </div>
              </div>
            </Card>
          ) : (
            <Card padding="lg" className="text-center text-text-secondary py-12 bg-white border-[#E2E8F0] space-y-3">
              <p className="text-xs">یک پیش‌فاکتور از فهرست انتخاب کنید یا پیش‌فاکتور جدید صادر نمایید.</p>
              <div className="flex justify-center gap-2">
                <Button variant="primary" size="sm" onClick={() => setIsWizardOpen(true)} icon={<Sparkles className="w-3.5 h-3.5" />}>
                  صدور با ویزارد
                </Button>
                <Button variant="outline" size="sm" onClick={handleCreateDraftQuote} icon={<Plus className="w-3.5 h-3.5" />}>
                  پیش‌نویس سریع
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      {isAddModalOpen && (
        <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="افزودن قلم کالا به پیش‌فاکتور" footer={<><Button variant="ghost" size="sm" onClick={() => setIsAddModalOpen(false)}>انصراف</Button><Button variant="primary" size="sm" onClick={handleAddLine}>ثبت در پیش‌فاکتور</Button></>}>
          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-text-main mb-1">انتخاب کالا از کاتالوگ ERP</label>
              <select value={selectedProductId} onChange={e => { setSelectedProductId(e.target.value); const prod = state.externalProducts.find(p => p.id === e.target.value); if (prod) setLinePrice(String(prod.basePrice)); }} className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 font-medium outline-none focus:border-primary">
                {state.externalProducts.map(p => (
                  <option key={p.id} value={p.id}>{p.name} - قیمت پایه: {formatCurrency(p.basePrice)} ریال</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-text-main mb-1">تعداد</label>
                <input type="text" value={lineQuantity} onChange={e => setLineQuantity(cleanNumericInput(e.target.value))} placeholder="مثال: 10" className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 font-mono outline-none focus:border-primary" dir="ltr" />
              </div>
              <div>
                <label className="block font-bold text-text-main mb-1">قیمت توافقی واحد (ریال)</label>
                <input type="text" value={formatInputCurrency(linePrice)} onChange={e => setLinePrice(cleanNumericInput(e.target.value))} placeholder="قیمت به ریال" className="w-full bg-canvas border border-[#E2E8F0] rounded-xl p-2.5 font-mono outline-none focus:border-primary" dir="ltr" />
              </div>
            </div>
          </div>
        </Modal>
      )}

      {isBundleModalOpen && (
        <Modal isOpen={isBundleModalOpen} onClose={() => setIsBundleModalOpen(false)} title="انتخاب و درج بسته ترکیبی محصولات (CPQ Bundle)" footer={<Button variant="ghost" size="sm" onClick={() => setIsBundleModalOpen(false)}>بستن</Button>}>
          <div className="space-y-3 text-xs">
            <p className="text-text-secondary">با انتخاب بسته، تمام اقلام زیرمجموعه آن همراه با درصد تخفیف ویژه پکیج به پیش‌فاکتور اضافه می‌شوند.</p>
            <div className="space-y-2">
              {(state.productBundles || []).map((b: any) => (
                <div key={b.id} className="p-3 bg-canvas border border-[#E2E8F0] rounded-xl flex justify-between items-center">
                  <div>
                    <strong className="text-sm font-bold text-text-main block">{b.name}</strong>
                    <span className="text-[11px] text-primary font-bold block mt-0.5">تخفیف پکیج: {b.discountPercent}٪ | اقلام شامل: {b.productIds.length} قلم کالا</span>
                  </div>
                  <Button size="sm" variant="primary" onClick={() => handleAddBundle(b.id)}>افزودن به پیش‌فاکتور</Button>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      )}

      {waterfallBreakdown && (
        <Modal isOpen={!!waterfallBreakdown} onClose={() => setWaterfallBreakdown(null)} title={waterfallBreakdown.title} footer={<Button variant="primary" size="sm" onClick={() => setWaterfallBreakdown(null)}>بستن</Button>}>
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-canvas rounded-xl border border-[#E2E8F0] space-y-2">
              <div className="flex justify-between items-center py-1 border-b border-[#E2E8F0]">
                <span className="text-text-secondary">۱. قیمت پایه کاتالوگ (Base Price):</span>
                <span className="font-mono font-bold">{formatCurrency(waterfallBreakdown.breakdown.basePrice)} ریال</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#E2E8F0] text-[#92400E]">
                <span>۲. تخفیف پلکانی تیراژ (Volume Tier Discount):</span>
                <span className="font-mono font-bold">- {formatCurrency(waterfallBreakdown.breakdown.volumeDiscount)} ریال</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#E2E8F0] text-primary">
                <span>۳. تخفیف بسته ترکیبی (Bundle Discount):</span>
                <span className="font-mono font-bold">- {formatCurrency(waterfallBreakdown.breakdown.bundleDiscount)} ریال</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#E2E8F0] text-[#0284C7]">
                <span>۴. ریبیت قرارداد سالانه (Contract Rebate):</span>
                <span className="font-mono font-bold">- {formatCurrency(waterfallBreakdown.breakdown.contractRebate)} ریال</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#E2E8F0] text-[#991B1B]">
                <span>۵. تخفیف توافقی مذاکره (Negotiated Discount):</span>
                <span className="font-mono font-bold">- {formatCurrency(waterfallBreakdown.breakdown.negotiatedDiscount)} ریال</span>
              </div>
              <div className="flex justify-between items-center py-2 bg-[#F0FDF4] px-2 rounded-lg text-[#166534] font-bold">
                <span>۶. قیمت خالص فاکتور (Net Price):</span>
                <span className="font-mono text-sm">{formatCurrency(waterfallBreakdown.breakdown.netPrice)} ریال</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 p-3 bg-white rounded-xl font-mono text-center border border-[#E2E8F0]">
              <div>
                <span className="text-[11px] text-text-secondary block">بهای تمام‌شده کل:</span>
                <span className="font-bold text-text-main">{formatCurrency(waterfallBreakdown.breakdown.costPrice)} ریال</span>
              </div>
              <div>
                <span className="text-[11px] text-text-secondary block">مارجین ناخالص:</span>
                <span className={`font-bold ${waterfallBreakdown.breakdown.grossMarginPercent < threshold ? 'text-[#92400E]' : 'text-[#166534]'}`}>
                  {waterfallBreakdown.breakdown.grossMarginPercent}٪ ({formatCurrency(waterfallBreakdown.breakdown.grossMarginAmount)} ریال)
                </span>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {isProfitModalOpen && activeQuote && (
        <ProfitModal state={state} quote={activeQuote} onClose={() => setIsProfitModalOpen(false)} />
      )}

      <QuoteWizardModal isOpen={isWizardOpen} onClose={() => setIsWizardOpen(false)} state={state} updateState={updateState} onQuoteCreated={(newId) => { setActiveQuoteId(newId); navigate('/quotes'); }} />

      {activeQuote && (
        <CustomerInvoicePrint state={state} quote={activeQuote} />
      )}
    </div>
  );
}
