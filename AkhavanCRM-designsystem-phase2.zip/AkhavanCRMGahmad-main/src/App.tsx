import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAppStore } from './lib/storage';
import { playNotificationSound } from './lib/sound';
import { useWorkflowEngine } from './hooks/useWorkflowEngine';
import { Layout } from './components/Layout';
import { HomeWorkspace } from './components/HomeWorkspace';
import { DashboardWorkspace } from './components/DashboardWorkspace';
import { LeadsWorkspace } from './components/LeadsWorkspace';
import { CustomersWorkspace } from './components/CustomersWorkspace';
import { NegotiationsWorkspace } from './components/NegotiationsWorkspace';
import { QuotesWorkspace } from './components/QuotesWorkspace';
import { TasksWorkspace } from './components/TasksWorkspace';
import { FinanceWorkspace } from './components/FinanceWorkspace';
import { ReportsWorkspace } from './components/ReportsWorkspace';
import { SettingsWorkspace } from './components/SettingsWorkspace';
import { ActivitiesWorkspace } from './components/ActivitiesWorkspace';
import { CasesWorkspace, CampaignsWorkspace, KnowledgeWorkspace } from './components/EnterpriseWorkspaces';
import { InternalAutomationWorkspace } from './components/InternalAutomationWorkspace';
import { GroupsWorkspace } from './components/GroupsWorkspace';
import { CalendarWorkspace } from './components/CalendarWorkspace';
import { ProfileWorkspace } from './workspaces/ProfileWorkspace';
import { CommandPalette } from './components/CommandPalette';
import { OnboardingTour } from './components/OnboardingTour';
import { SideDrawer } from './components/ui/Modal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { requestDevicePermissions } from './lib/permissions';
import { AlertTriangle, ShieldCheck } from 'lucide-react';

function AppContent() {
  const { state, updateState, error } = useAppStore();
  const location = useLocation();
  const navigate = useNavigate();
  
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [permissionsSynced, setPermissionsSynced] = useState(false);

  useWorkflowEngine(state, updateState);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (state?.settings?.locale) {
      document.documentElement.dir = state.settings.locale.rtl ? 'rtl' : 'ltr';
      document.documentElement.lang = state.settings.locale.language;
    }
  }, [state?.settings?.locale?.rtl, state?.settings?.locale?.language]);

  useEffect(() => {
    if (!state) return;
    const currentCount = state.notifications?.length || 0;
    const prevCount = parseInt(sessionStorage.getItem('notifCount') || '0', 10);
    
    if (prevCount > 0 && currentCount > prevCount) {
      if (state.settings?.privacy?.soundEnabled) playNotificationSound();
    }
    sessionStorage.setItem('notifCount', currentCount.toString());
  }, [state?.notifications?.length, state?.settings?.privacy?.soundEnabled]);

  useEffect(() => {
    const syncPerms = async () => {
      if (navigator.permissions && navigator.permissions.query) {
        try {
          const geo = await navigator.permissions.query({ name: 'geolocation' as any });
          const notif = await navigator.permissions.query({ name: 'notifications' as any });
          
          updateState(draft => {
            if (!draft.grantedDevicePermissions) draft.grantedDevicePermissions = { LOCATION: false, CAMERA: false, MICROPHONE: false, NOTIFICATIONS: false };
            draft.grantedDevicePermissions.LOCATION = geo.state === 'granted';
            draft.grantedDevicePermissions.NOTIFICATIONS = notif.state === 'granted';
          });
        } catch (e) {
          console.warn('Permission query failed', e);
        }
      }
      setPermissionsSynced(true);
    };
    syncPerms();
  }, [updateState]);

  const handleNotificationClick = (n: any) => {
    updateState(draft => {
      const notif = draft.notifications?.find((x: any) => x.id === n.id);
      if (notif) notif.read = true;
    });
    setIsNotificationsOpen(false);

    if (n.linkTab) {
      const routeMap: Record<string, string> = {
        home: '/',
        accounts: '/accounts',
        tasks: '/tasks',
        quotes: '/quotes',
        finance: '/finance',
        internal_automation: '/internal_automation',
        groups: '/groups'
      };
      navigate(routeMap[n.linkTab] || `/${n.linkTab}`);
    }
  };

  if (error) return <div className="p-8 text-center text-[#991B1B] font-bold bg-[#FEF2F2] h-screen flex items-center justify-center" dir="rtl">{error}</div>;
  if (!state || !permissionsSynced) return <div className="p-8 text-center text-text-secondary h-screen flex justify-center items-center bg-canvas" dir="rtl">در حال بارگذاری...</div>;

  const currentUser = state.users?.find(u => u.id === state.currentUserId);
  const currentRole = state.roles?.find(r => r.id === currentUser?.roleId);
  const requiredDevicePerms = currentRole?.requiredDevicePermissions || [];
  const missingPerms = requiredDevicePerms.filter(p => !state.grantedDevicePermissions?.[p]);

  if (missingPerms.length > 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-text-main p-6 text-center" dir="rtl">
        <div className="bg-white p-8 rounded-3xl max-w-md w-full shadow-2xl space-y-5">
          <div className="w-16 h-16 bg-[#FEF2F2] text-[#991B1B] rounded-full flex items-center justify-center mx-auto">
            <AlertTriangle size={32} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-text-main">دسترسی‌های الزامی مسدود است</h2>
            <p className="text-sm text-text-secondary mt-2 leading-relaxed">
              با توجه به نقش شما ({currentRole?.name})، اجرای وظایف نیازمند تایید دسترسی‌های زیر است:
            </p>
            <div className="flex flex-wrap gap-2 justify-center my-3">
              {missingPerms.map(p => (
                <span key={p} className="text-xs bg-red-50 text-red-700 px-3 py-1 rounded-xl font-bold border border-red-100">
                  {p === 'LOCATION' ? 'موقعیت مکانی (GPS)' : p === 'NOTIFICATIONS' ? 'اعلان‌ها' : p === 'CAMERA' ? 'دوربین' : 'میکروفون'}
                </span>
              ))}
            </div>
          </div>
          <div className="space-y-2.5 w-full">
            <button 
              onClick={async () => {
                const res = await requestDevicePermissions(missingPerms as any);
                updateState(draft => {
                  if (!draft.grantedDevicePermissions) {
                    draft.grantedDevicePermissions = { LOCATION: false, CAMERA: false, MICROPHONE: false, NOTIFICATIONS: false };
                  }
                  missingPerms.forEach(p => {
                    draft.grantedDevicePermissions![p] = res[p] !== undefined ? (res[p] || true) : true;
                  });
                });
              }}
              className="w-full bg-primary hover:bg-primary-hover text-white font-bold py-3.5 rounded-xl shadow-sm transition-all flex justify-center items-center gap-2 cursor-pointer"
            >
              <ShieldCheck size={20} /> بررسی و تایید دسترسی‌ها
            </button>
            <button
              onClick={() => {
                updateState(draft => {
                  if (!draft.grantedDevicePermissions) {
                    draft.grantedDevicePermissions = { LOCATION: false, CAMERA: false, MICROPHONE: false, NOTIFICATIONS: false };
                  }
                  missingPerms.forEach(p => {
                    draft.grantedDevicePermissions![p] = true;
                  });
                });
                navigate('/settings');
              }}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl transition-all flex justify-center items-center gap-2 cursor-pointer text-xs"
            >
              تنظیمات و مدیریت دسترسی‌ها
            </button>
          </div>
        </div>
      </div>
    );
  }

  const unreadNotificationsCount = state.notifications?.filter(n => !n.read).length || 0;

  return (
    <>
      <Layout 
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadNotificationsCount={unreadNotificationsCount}
        state={state}
        updateState={updateState}
      >
        <Routes>
          <Route path="/" element={<HomeWorkspace state={state} />} />
          <Route path="/dashboard" element={<DashboardWorkspace state={state} />} />
          <Route path="/leads" element={<LeadsWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/accounts/*" element={<CustomersWorkspace state={state} updateState={updateState} />} />
          <Route path="/opportunities" element={<NegotiationsWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/quotes" element={<QuotesWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/activities" element={<ActivitiesWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/tasks" element={<TasksWorkspace state={state} updateState={updateState} />} />
          <Route path="/finance" element={<FinanceWorkspace state={state} updateState={updateState} />} />
          <Route path="/cases" element={<CasesWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/marketing" element={<CampaignsWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/knowledge" element={<KnowledgeWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/internal_automation" element={<InternalAutomationWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/groups" element={<GroupsWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/calendar" element={<CalendarWorkspace state={state} />} />
          <Route path="/reports" element={<ReportsWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="/settings" element={<SettingsWorkspace state={state} updateState={updateState} />} />
          <Route path="/profile" element={<ProfileWorkspace state={state} updateState={updateState} setActiveTab={(t: string) => navigate(`/${t}`)} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>

      <CommandPalette isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} state={state} updateState={updateState} />

      <SideDrawer isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} title="مرکز اعلان‌ها" subtitle={`${unreadNotificationsCount} اعلان جدید`} width="md">
        <div className="space-y-3">
          {(state.notifications || []).slice(-20).reverse().map(n => (
            <div key={n.id} onClick={() => handleNotificationClick(n)} className={`p-4 rounded-2xl border transition-all cursor-pointer ${n.read ? 'bg-canvas border-[#E2E8F0] opacity-70' : 'bg-white border-primary/30 shadow-sm'}`}>
              <div className="flex justify-between items-start mb-1">
                <strong className="text-sm font-bold text-text-main">{n.title}</strong>
                {!n.read && <span className="w-2 h-2 rounded-full bg-primary mt-1" />}
              </div>
              <p className="text-xs text-text-secondary leading-relaxed">{n.message}</p>
            </div>
          ))}
        </div>
      </SideDrawer>

      <OnboardingTour state={state} updateState={updateState} setActiveTab={(t) => navigate(t === 'home' ? '/' : `/${t}`)} />
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </ErrorBoundary>
  );
}
