import { useEffect, useRef } from 'react';
import { AppState } from '../types';
import { generateId } from '../lib/utils';
import { processPendingJobs } from '../lib/automation';

export function useWorkflowEngine(state: AppState, updateState: any) {
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    let timeoutId: number;

    const runEngine = async () => {
      if (!stateRef.current) return;

      await processPendingJobs(stateRef.current, updateState);

      updateState((draft: AppState) => {
        let stateChanged = false;
        const today = new Date().toISOString().split('T')[0];
        const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

        if (!draft.notifications) draft.notifications = [];
        if (!draft.tasks) draft.tasks = [];

        draft.tasks.filter(t => t.status !== 'COMPLETED').forEach(task => {
          let calculatedSla: 'ON_TRACK' | 'AT_RISK' | 'BREACHED' = 'ON_TRACK';

          if (task.dueDate && task.dueDate < today) {
            calculatedSla = 'BREACHED';
          } else if (task.dueDate && (task.dueDate === today || task.dueDate <= tomorrow)) {
            calculatedSla = 'AT_RISK';
          }

          if (task.slaStatus !== calculatedSla) {
            task.slaStatus = calculatedSla;
            stateChanged = true;
          }
        });

        const threshold = 100000000;
        (draft.quotes || []).filter(q => q.totalAmount > threshold && q.status === 'DRAFT').forEach(quote => {
          const alreadyNotified = draft.notifications!.some(n => n.title?.includes(quote.quoteNumber));
          if (!alreadyNotified) {
            draft.notifications!.push({
              id: generateId(),
              title: `پیش‌فاکتور با ارزش بالا (${quote.quoteNumber})`,
              message: `پیش‌فاکتور جدید به ارزش ${new Intl.NumberFormat('fa-IR').format(quote.totalAmount)} ریال ثبت شده است.`,
              type: 'INFO',
              read: false,
              createdAt: new Date().toISOString(),
              linkTab: 'quotes'
            });
            stateChanged = true;
          }
        });

        return stateChanged ? draft : false;
      });

      timeoutId = window.setTimeout(runEngine, 30000);
    };

    timeoutId = window.setTimeout(runEngine, 5000);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [updateState]);
}
