import { QuoteLine, ExternalProduct, PriceWaterfallBreakdown } from '../types';

export interface PriceWaterfallParams {
  basePrice?: number;
  quantity: number;
  costPrice?: number;
  negotiatedUnitPrice?: number;
  appliedVolumeDiscountPercent?: number;
  contractRebatePercent?: number;
  bundleDiscountPercent?: number;
}

export function calculateQuoteLineMargin(
  line: QuoteLine,
  product?: ExternalProduct,
  threshold: number = 15
) {
  const cost = (product?.costPrice ?? line.costPrice ?? 0) * line.quantity;
  const revenue = line.lineTotal || (line.unitPrice * line.quantity);
  const profit = revenue - cost;
  const marginPercent = revenue > 0 ? Math.round((profit / revenue) * 1000) / 10 : 0;

  return {
    marginPercent,
    marginAmount: profit,
    isBelowThreshold: marginPercent < threshold
  };
}

export function calculatePriceWaterfall({
  basePrice = 0,
  quantity = 1,
  costPrice = 0,
  negotiatedUnitPrice,
  appliedVolumeDiscountPercent = 0,
  contractRebatePercent = 0,
  bundleDiscountPercent = 0
}: PriceWaterfallParams): PriceWaterfallBreakdown {
  const totalBasePrice = (basePrice || 0) * quantity;
  const volumeDiscount = Math.round((totalBasePrice * (appliedVolumeDiscountPercent || 0)) / 100);
  const bundleDiscount = Math.round((totalBasePrice * (bundleDiscountPercent || 0)) / 100);
  const contractRebate = Math.round((totalBasePrice * (contractRebatePercent || 0)) / 100);

  const subtotalBeforeNegotiated = totalBasePrice - volumeDiscount - bundleDiscount - contractRebate;
  const targetNetPrice = negotiatedUnitPrice !== undefined 
    ? negotiatedUnitPrice * quantity 
    : subtotalBeforeNegotiated;

  const negotiatedDiscount = Math.max(0, subtotalBeforeNegotiated - targetNetPrice);
  const netPrice = targetNetPrice;
  const totalCost = (costPrice || 0) * quantity;
  const grossMarginAmount = netPrice - totalCost;
  const grossMarginPercent = netPrice > 0 ? Math.round((grossMarginAmount / netPrice) * 1000) / 10 : 0;

  return {
    basePrice: totalBasePrice,
    volumeDiscount,
    bundleDiscount,
    contractRebate,
    negotiatedDiscount,
    netPrice,
    costPrice: totalCost,
    grossMarginAmount,
    grossMarginPercent
  };
}
