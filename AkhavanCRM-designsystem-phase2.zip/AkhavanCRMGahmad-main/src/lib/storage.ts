import { create } from 'zustand';
import { persist, StateStorage, createJSONStorage } from 'zustand/middleware';
import { AppState } from '../types';
import { idbGet, idbSet, idbDel } from './idb';
import { generateSeedData } from './seed';

const STORAGE_VERSION = 19;
const STORAGE_NAME = 'akhavan_app_state';
const SYNC_CHANNEL_NAME = 'akhavan_state_sync_channel';

const MAX_LOG_RECORDS = 1000;
const MAX_NOTIFICATIONS = 200;

const idbStorage: StateStorage = {
  getItem: async (name: string): Promise<string | null> => {
    const value = await idbGet<string>(name);
    return typeof value === 'string' ? value : null;
  },
  setItem: async (name: string, value: string): Promise<void> => {
    await idbSet(name, value);
  },
  removeItem: async (name: string): Promise<void> => {
    await idbDel(name);
  },
};

interface AppStore {
  state: AppState;
  updateState: (updater: (draft: AppState) => void | Partial<AppState>) => void;
  error: string | null;
}

const cloneState = (state: AppState): AppState => {
  if (typeof structuredClone === 'function') return structuredClone(state);
  return JSON.parse(JSON.stringify(state)) as AppState;
};

const ensureStateIntegrity = (state: AppState): AppState => {
  const base = generateSeedData();
  
  const safeAuditLogs = Array.isArray(state?.auditLogs) ? state.auditLogs.slice(-MAX_LOG_RECORDS) : [];
  const safeNotifications = Array.isArray(state?.notifications) ? state.notifications.slice(-MAX_NOTIFICATIONS) : [];
  const safeBusinessEvents = Array.isArray(state?.businessEvents) ? state.businessEvents.slice(-MAX_LOG_RECORDS) : [];

  return {
    ...base,
    ...state,
    schemaVersion: typeof state?.schemaVersion === 'number' ? state.schemaVersion : STORAGE_VERSION,
    auditLogs: safeAuditLogs,
    notifications: safeNotifications,
    businessEvents: safeBusinessEvents,
    paymentAllocations: Array.isArray(state?.paymentAllocations) ? state.paymentAllocations : [],
    attachments: Array.isArray(state?.attachments) ? state.attachments : [],
    agents: Array.isArray(state?.agents) && state.agents.length > 0 ? state.agents : base.agents,
    agentLogs: Array.isArray(state?.agentLogs) ? state.agentLogs : (base.agentLogs || []),
    messagingChannels: Array.isArray(state?.messagingChannels) && state.messagingChannels.length > 0 ? state.messagingChannels : base.messagingChannels,
    messagingLogs: Array.isArray(state?.messagingLogs) ? state.messagingLogs : (base.messagingLogs || []),
    settings: {
      ...base.settings,
      ...(state?.settings || {}),
      locale: {
        ...(base.settings?.locale || {}),
        ...(state?.settings?.locale || {})
      }
    }
  };
};

const broadcastChannel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel(SYNC_CHANNEL_NAME) : null;

export const useAppStore = create<AppStore>()(
  persist(
    (set) => {
      if (broadcastChannel) {
        broadcastChannel.onmessage = (event) => {
          if (event.data && event.data.type === 'STATE_UPDATED') {
            idbGet(STORAGE_NAME).then((persistedStr) => {
              if (persistedStr) {
                const parsed = JSON.parse(persistedStr);
                set({ state: ensureStateIntegrity(parsed.state), error: null });
              }
            });
          }
        };
      }

      return {
        state: ensureStateIntegrity(generateSeedData()),
        error: null,
        updateState: (updater) =>
          set((prev) => {
            try {
              const newState = cloneState(prev.state);
              const result = updater(newState);
              const finalState = ensureStateIntegrity(result ? { ...newState, ...result } : newState);
              
              if (broadcastChannel) {
                broadcastChannel.postMessage({ type: 'STATE_UPDATED', timestamp: Date.now() });
              }

              return { state: finalState, error: null };
            } catch (err: any) {
              console.error('[AKHAVAN][STATE_UPDATE_FAILED]', err);
              return { ...prev, error: err?.message || 'خطا در بروزرسانی اطلاعات سامانه.' };
            }
          }),
      };
    },
    {
      name: STORAGE_NAME,
      storage: createJSONStorage(() => idbStorage),
      version: STORAGE_VERSION,
    }
  )
);
