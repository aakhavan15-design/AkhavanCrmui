import { AppState } from '../types';

export function generateSeedData(): AppState {
  const defaultCustomers = [
    {
      id: 'cust-1',
      name: 'شرکت مهندسی فراگستر',
      company: 'فراگستر نوین',
      phone: '02188776655',
      email: 'info@faragostar.com',
      ownerId: 'user-admin',
      branchId: 'branch-tehran',
      status: 'ACTIVE',
      creditLimit: 500000000,
      balance: 150000000,
      totalRevenue: 450000000,
      createdAt: '2025-01-15T09:00:00Z',
      contacts: [
        {
          id: 'con-1',
          name: 'مهندس حسینی',
          title: 'مدیر تدارکات و خرید',
          phone: '09121112233',
          email: 'hosseini@faragostar.com',
          isPrimary: true
        }
      ]
    },
    {
      id: 'cust-2',
      name: 'صنایع فولاد آذرخش',
      company: 'فولاد آذرخش',
      phone: '02122334455',
      email: 'contact@azarakhsh.ir',
      ownerId: 'user-sales-1',
      branchId: 'branch-tehran',
      status: 'ACTIVE',
      creditLimit: 800000000,
      balance: 0,
      totalRevenue: 280000000,
      createdAt: '2025-02-10T11:30:00Z',
      contacts: [
        {
          id: 'con-2',
          name: 'دکتر صابری',
          title: 'معاون بازرگانی',
          phone: '09123334455',
          email: 'saberi@azarakhsh.ir',
          isPrimary: true
        }
      ]
    },
  ];

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  return {
    schemaVersion: 19,
    currentUserId: 'user-admin',
    users: [
      {
        id: 'user-admin',
        name: 'احمد اخوان',
        username: 'a.akhavan',
        email: 'admin@akhavan.ir',
        phone: '09121111111',
        roleId: 'role-admin',
        permissionSetId: 'perm-admin',
        branchId: 'branch-tehran',
        isActive: true,
        active: true,
        onboardingCompleted: false
      },
      {
        id: 'user-sales-1',
        name: 'سارا رضایی',
        username: 's.rezaei',
        email: 'rezaei@akhavan.ir',
        phone: '09122222222',
        roleId: 'role-sales',
        permissionSetId: 'perm-sales',
        branchId: 'branch-tehran',
        isActive: true,
        active: true,
        onboardingCompleted: true
      },
      {
        id: 'user-finance-1',
        name: 'رضا کمالی',
        username: 'r.kamali',
        email: 'kamali@akhavan.ir',
        phone: '09123333333',
        roleId: 'role-finance',
        permissionSetId: 'perm-admin',
        branchId: 'branch-tehran',
        isActive: true,
        active: true,
        onboardingCompleted: true
      }
    ],
    roles: [
      {
        id: 'role-admin',
        name: 'مدیر ارشد سامانه',
        visibilityScope: 'ORG',
        description: 'دسترسی کامل به کل سازمان و تمامی شعب',
        requiredDevicePermissions: ['LOCATION', 'NOTIFICATIONS']
      },
      {
        id: 'role-sales',
        name: 'کارشناس فروش و مذاکرات',
        visibilityScope: 'OWNER',
        description: 'دسترسی به پرونده‌ها و مشتریان تخصیص‌یافته به خود',
        requiredDevicePermissions: ['NOTIFICATIONS']
      },
      {
        id: 'role-finance',
        name: 'مدیر امور مالی و وصول مطالبات',
        visibilityScope: 'ORG',
        description: 'دسترسی کامل به تراکنش‌ها، چک‌ها و صورتحساب‌ها',
        requiredDevicePermissions: ['NOTIFICATIONS']
      }
    ],
    permissionSets: [
      {
        id: 'perm-admin',
        name: 'دسترسی کامل مدیریتی',
        permissions: [
          'accounts.view',
          'accounts.edit',
          'accounts.delete',
          'leads.view',
          'leads.edit',
          'quotes.view',
          'quotes.create',
          'quotes.approve',
          'finance.view',
          'finance.manage',
          'settings.manage',
          'cases.view',
          'cases.edit',
          'marketing.manage',
          'knowledge.manage',
          'agents.manage',
          'automation.manage',
          'users.manage',
          'roles.manage',
          'internal.view',
          'internal.manage',
        ],
      },
      {
        id: 'perm-sales',
        name: 'دسترسی کارشناس فروش',
        permissions: [
          'accounts.view',
          'accounts.edit',
          'leads.view',
          'leads.edit',
          'quotes.view',
          'quotes.create',
          'finance.view',
          'internal.view',
          'knowledge.manage'
        ],
      },
    ],
    groups: [
      {
        id: 'group-tehran-sales',
        name: 'تیم فروش و بازرگانی تهران',
        description: 'هماهنگی و پیگیری سفارشات مشتریان مستقر در استان تهران و البرز',
        managerId: 'user-admin',
        memberIds: ['user-admin', 'user-sales-1'],
        active: true
      },
      {
        id: 'group-finance-coll',
        name: 'تیم مالی و وصولی',
        description: 'پایش سررسید چک‌ها، تسهیم اسناد دریافتی و تراز بدهی مشتریان',
        managerId: 'user-admin',
        memberIds: ['user-admin', 'user-finance-1'],
        active: true
      }
    ],
    customers: defaultCustomers,
    accounts: defaultCustomers,
    quotes: [
      {
        id: 'quote-101',
        quoteNumber: 'Q-1403-101',
        accountId: 'cust-1',
        customerId: 'cust-1',
        ownerId: 'user-admin',
        totalAmount: 185000000,
        marginPercent: 20,
        status: 'DRAFT',
        lines: [
          {
            id: 'line-1',
            productId: 'prod-1',
            quantity: 3,
            unitPrice: 50000000,
            costPrice: 20000000,
            lineTotal: 150000000
          }
        ],
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        updatedAt: new Date().toISOString()
      },
    ],
    tasks: [
      {
        id: 'task-1',
        title: 'پیگیری تسویه فاکتور شرکت فراگستر',
        description: 'تماس با واحد مالی جهت هماهنگی وصول مانده فاکتور',
        accountId: 'cust-1',
        customerId: 'cust-1',
        status: 'IN_PROGRESS',
        priority: 'HIGH',
        dueDate: todayStr,
        slaStatus: 'ON_TRACK',
        assigneeType: 'USER',
        assigneeId: 'user-admin',
        assignedTo: 'user-admin',
        createdAt: new Date().toISOString()
      },
    ],
    opportunities: [
      {
        id: 'opp-1',
        accountId: 'cust-1',
        title: 'قرارداد توسعه زیرساخت و لایسنس سالانه',
        amount: 250000000,
        stage: 'NEGOTIATION',
        expectedCloseDate: new Date(Date.now() + 86400000 * 15).toISOString().split('T')[0],
        ownerId: 'user-admin',
        createdAt: new Date().toISOString()
      }
    ],
    externalProducts: [
      {
        id: 'prod-1',
        name: 'سرویس CRM ابری اخوان',
        code: 'AKH-CRM-CLOUD',
        sku: 'AKH-CRM-CLOUD',
        category: 'نرم‌افزار',
        unitPrice: 50000000,
        basePrice: 50000000,
        costPrice: 20000000,
      },
      {
        id: 'prod-2',
        name: 'پکیج ماژول یکپارچه‌سازی مالی و CPQ',
        code: 'AKH-MOD-FIN',
        sku: 'AKH-MOD-FIN',
        category: 'ماژول‌های تخصصی',
        unitPrice: 35000000,
        basePrice: 35000000,
        costPrice: 12000000,
      }
    ],
    invoices: [
      {
        id: 'INV-1001',
        invoiceNumber: 'INV-1403-1001',
        accountId: 'cust-1',
        customerId: 'cust-1',
        totalAmount: 150000000,
        paidAmount: 50000000,
        balance: 100000000,
        status: 'PARTIAL',
        date: '2025-03-01',
        dueDate: todayStr
      },
    ],
    payments: [
      {
        id: 'pay-1',
        accountId: 'cust-1',
        customerId: 'cust-1',
        amount: 50000000,
        date: '2025-03-05',
        method: 'TRANSFER',
        reference: 'TR-889922',
        status: 'CLEARED',
        notes: 'حواله ساتنا پیش‌پرداخت'
      }
    ],
    paymentAllocations: [
      {
        id: 'alloc-1',
        paymentId: 'pay-1',
        invoiceId: 'INV-1001',
        amount: 50000000,
        createdAt: '2025-03-05T10:00:00Z'
      }
    ],
    cheques: [
      {
        id: 'chq-1',
        chequeNumber: '782910384756',
        bankName: 'بانک ملت - شعبه مرکزی',
        amount: 100000000,
        dueDate: new Date(Date.now() + 86400000 * 10).toISOString().split('T')[0],
        status: 'PENDING',
        customerId: 'cust-1',
        accountId: 'cust-1'
      }
    ],
    activities: [
      {
        id: 'act-1',
        accountId: 'cust-1',
        customerId: 'cust-1',
        type: 'CALL',
        title: 'مذاکره تلفنی در خصوص تمدید پشتیبانی',
        description: 'با مهندس حسینی صحبت شد؛ کلیات قرارداد مورد توافق قرار گرفت.',
        dateTime: new Date(Date.now() - 86400000).toISOString(),
        ownerId: 'user-admin'
      }
    ],
    internalRequests: [
      {
        id: 'req-1',
        type: 'LEAVE',
        title: 'درخواست مرخصی استحقاقی دوره‌ای',
        creatorId: 'user-sales-1',
        currentAssigneeId: 'user-admin',
        status: 'IN_REVIEW',
        data: {
          startDate: todayStr,
          endDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
          substituteName: 'احمد اخوان'
        },
        createdAt: new Date().toISOString()
      }
    ],
    internalMeetings: [
      {
        id: 'meet-1',
        title: 'جلسه بازنگری تارگت‌های فصلی فروش',
        date: todayStr,
        startTime: '10:30',
        endTime: '12:00',
        organizerId: 'user-admin',
        participantIds: ['user-admin', 'user-sales-1'],
        groupIds: ['group-tehran-sales']
      }
    ],
    notifications: [],
    businessEvents: [],
    timelineEvents: [
      {
        id: 'tl-1',
        customerId: 'cust-1',
        type: 'CALL',
        title: 'مذاکره تلفنی در خصوص تمدید پشتیبانی',
        description: 'با مهندس حسینی صحبت شد؛ کلیات قرارداد مورد توافق قرار گرفت.',
        dateTime: new Date(Date.now() - 86400000).toISOString(),
        relatedEntityId: 'act-1'
      }
    ],
    auditLogs: [],
    attachments: [],
    agents: [
      {
        id: 'agent-sales',
        name: 'دستیار هوشمند فروش و جذب سرنخ',
        type: 'SALES',
        role: 'پایش و پیگیری خودکار فرصت‌های تجاری و سرنخ‌های جدید',
        active: true,
        requiresHumanApproval: false,
        allowedTools: ['createTask', 'searchAccounts', 'calculateQuote'],
        prompt: 'پاسخگویی سریع به سرنخ‌های ورودی، اولویت‌بندی تماس‌ها و هماهنگی جلسات دمو',
        autonomyLevel: 85,
        description: 'تسهیل چرخه تبدیل سرنخ به مشتری و یادآوری پیگیری‌های فروش',
        lastActive: new Date().toISOString()
      },
      {
        id: 'agent-collection',
        name: 'دستیار پایش مطالبات و وصولی',
        type: 'COLLECTION',
        role: 'پایش سررسید چک‌ها، اخطار فاکتورهای معوق و هشدار برگشتی',
        active: true,
        requiresHumanApproval: true,
        allowedTools: ['createTask', 'searchAccounts'],
        prompt: 'ارسال یادآوری پیامکی و بومی پیش از موعد سررسید چک و ارجاع موارد پرریسک به سرپرست مالی',
        autonomyLevel: 70,
        description: 'پیشگیری از نکول مطالبات با اخطارهای محترمانه چندمرحله‌ای',
        lastActive: new Date(Date.now() - 3600000 * 2).toISOString()
      },
      {
        id: 'agent-pricing',
        name: 'دستیار تحلیل قیمت و مظنه (CPQ)',
        type: 'PRICING',
        role: 'تحلیل حاشیه سود، اعتبارسنجی تخفیف‌های پلکانی و پیشنهاد پکیج',
        active: true,
        requiresHumanApproval: true,
        allowedTools: ['calculateQuote', 'negotiateTerms'],
        prompt: 'بررسی حداقل کف حاشیه سود مصوب و پیشنهاد بهترین شیوه پرداخت نقدی/اقساطی',
        autonomyLevel: 60,
        description: 'تضمین سودآوری در پیش‌فاکتورها و جلوگیری از نقض سیاست‌های قیمت‌گذاری',
        lastActive: new Date(Date.now() - 3600000 * 5).toISOString()
      }
    ],
    agentLogs: [
      {
        id: 'alog-1',
        agentId: 'agent-sales',
        trigger: 'OPPORTUNITY_CREATED',
        actionProposed: 'createTask',
        actionTaken: 'createTask',
        status: 'EXECUTED',
        timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
        reason: 'تولید خودکار وظیفه تماس و پیگیری برای قرارداد توسعه زیرساخت'
      },
      {
        id: 'alog-2',
        agentId: 'agent-collection',
        trigger: 'CHEQUE_DUE_WARNING',
        actionProposed: 'createTask',
        actionTaken: 'createTask',
        status: 'AWAITING_APPROVAL',
        timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        reason: 'سررسید چک ۱۰ روز آینده؛ نیازمند تایید سرپرست مالی پیش از ارسال پیامک'
      }
    ],
    messagingChannels: [
      {
        id: 'eitaa',
        name: 'پیام‌رسان ایتا (Eitaa)',
        type: 'EITAA',
        active: true,
        status: 'CONNECTED',
        botToken: 'bot_eitaa_akhavan_9921',
        webhookUrl: 'https://eitaa.com/api/v1/webhook/crm',
        autoReply: true,
        lastPing: new Date().toISOString(),
        latencyMs: 120
      },
      {
        id: 'rubika',
        name: 'سوپراپلیکیشن روبیکا (Rubika)',
        type: 'RUBIKA',
        active: true,
        status: 'CONNECTED',
        botToken: 'rubika_auth_882194',
        webhookUrl: 'https://messengerg2c6.iranlms.ir/v1/bot',
        autoReply: false,
        lastPing: new Date().toISOString(),
        latencyMs: 95
      },
      {
        id: 'bale',
        name: 'پیام‌رسان بانکی بله (Bale)',
        type: 'BALE',
        active: true,
        status: 'CONNECTED',
        botToken: 'bot_bale_crm_34807',
        webhookUrl: 'https://ble.ir/api/v2/bot/webhook',
        autoReply: true,
        lastPing: new Date().toISOString(),
        latencyMs: 110
      },
      {
        id: 'kavenegar',
        name: 'درگاه پیامک خدماتی (کاوه‌نگار)',
        type: 'SMS',
        active: true,
        status: 'CONNECTED',
        botToken: 'kav_api_771829',
        webhookUrl: 'https://api.kavenegar.com/v1/sms/send',
        autoReply: true,
        lastPing: new Date().toISOString(),
        latencyMs: 180
      },
      {
        id: 'telegram',
        name: 'تلگرام بات (Telegram)',
        type: 'TELEGRAM',
        active: false,
        status: 'DISCONNECTED',
        botToken: '',
        webhookUrl: '',
        autoReply: false,
        latencyMs: 0
      },
      {
        id: 'custom_webhook',
        name: 'وب‌هوک سفارشی سازمانی',
        type: 'WEBHOOK',
        active: true,
        status: 'CONNECTED',
        botToken: 'wh_secret_8912',
        webhookUrl: 'https://api.mycompany.ir/crm/events',
        autoReply: false,
        lastPing: new Date().toISOString(),
        latencyMs: 65
      }
    ],
    messagingLogs: [
      {
        id: 'msg-1',
        channelId: 'eitaa',
        direction: 'INBOUND',
        sender: '09121112233',
        recipient: 'بات اخوان CRM',
        content: 'سلام، کاتالوگ و شرایط پرداخت نسخه تحت وب را می‌خواستم.',
        status: 'DELIVERED',
        timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
        trackingId: 'EIT-88491'
      },
      {
        id: 'msg-2',
        channelId: 'eitaa',
        direction: 'OUTBOUND',
        sender: 'دستیار هوشمند فروش',
        recipient: '09121112233',
        content: 'درود بر شما؛ کاتالوگ ارسال شد و پیش‌فاکتور مقدماتی برای شما آماده گردید.',
        status: 'SENT',
        timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
        trackingId: 'EIT-88492'
      },
      {
        id: 'msg-3',
        channelId: 'rubika',
        direction: 'INBOUND',
        sender: 'روبیکا: @faragostar_user',
        recipient: 'درگاه CRM',
        content: 'لطفاً وضعیت تایید فاکتور شماره ۱۰۱ را اطلاع دهید.',
        status: 'DELIVERED',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        trackingId: 'RUB-12940'
      }
    ],
    settings: {
      quoteApprovalMarginThreshold: 15,
      aiKillSwitch: false,
      orgConfig: {
        enableLeadManagement: true,
        enableOpportunities: true,
        enableQuotes: true,
        enableFinance: true
      },
      locale: {
        rtl: true,
        language: 'fa',
        calendar: 'jalali',
        currency: 'IRR',
        timezone: 'Asia/Tehran',
        firstDayOfWeek: 6,
        numberFormat: 'persian'
      },
      privacy: {
        soundEnabled: true
      },
      integrations: {
        erpConnector: { active: false, status: 'NOT_CONFIGURED', endpoint: '', token: '' },
        whatsappGateway: { active: false, status: 'NOT_CONFIGURED', endpoint: '', token: '' },
        smsGateway: { active: false, status: 'NOT_CONFIGURED', endpoint: '', token: '' }
      }
    }
  };
}
