export const tokens = {
  colors: {
    primary: '#0B0B0C',
    accent: '#8CA3DD',
    textMain: '#0F1115',
    textSecondary: '#64748B',
    canvas: '#EEF1F5',
    surface: '#FFFFFF',
    status: {
      info: '#8CA3DD',
      danger: '#D96B63',
      warning: '#F4BE86',
    }
  },
  radius: {
    xs: 'rounded-md',
    sm: 'rounded-lg',
    md: 'rounded-[12px]',
    lg: 'rounded-[18px]',
    xl: 'rounded-[24px]',
    full: 'rounded-full',
  },
  shadows: {
    subtle: 'shadow-[0_2px_10px_rgba(31,33,40,0.04)]',
    card: 'shadow-[0_4px_16px_rgba(31,33,40,0.06)]',
    modal: 'shadow-[0_20px_50px_rgba(31,33,40,0.12)]',
  }
};
