import { AppState, CapabilityPermission, UserAccount, NavigationTab } from '../types';

export const PERMISSION_LABELS: Record<CapabilityPermission, string> = {
  'accounts.view': 'مشاهده حساب‌ها و مشتریان',
  'accounts.edit': 'ویرایش اطلاعات مشتریان',
  'accounts.delete': 'حذف حساب تجاری',
  'leads.view': 'مشاهده سرنخ‌های فروش',
  'leads.edit': 'ویرایش و تبدیل سرنخ',
  'quotes.view': 'مشاهده پیش‌فاکتورها',
  'quotes.create': 'صدور پیش‌فاکتور جدید',
  'quotes.approve': 'تایید پیش‌فاکتور (مدیریتی)',
  'finance.view': 'مشاهده اطلاعات مالی و وصولی',
  'finance.manage': 'ثبت پرداختی و مدیریت مالی',
  'settings.manage': 'مدیریت تنظیمات کلان سیستم',
  'cases.view': 'مشاهده پرونده‌ها و شکایات',
  'cases.edit': 'ویرایش و پاسخ به پرونده‌ها',
  'marketing.manage': 'مدیریت کمپین‌های بازاریابی',
  'knowledge.manage': 'مدیریت پایگاه دانش',
  'agents.manage': 'مدیریت دستیاران هوشمند (AI)',
  'automation.manage': 'مدیریت قوانین گردش‌کار',
  'users.manage': 'مدیریت کاربران سیستم',
  'roles.manage': 'مدیریت نقش‌ها و دسترسی‌ها',
  'internal.view': 'مشاهده اتوماسیون داخلی',
  'internal.manage': 'مدیریت و تایید اتوماسیون داخلی'
};

export class RBACService {
  private state: AppState;

  constructor(state: AppState) {
    this.state = state;
  }

  getCurrentUser(): UserAccount | null {
    if (!this.state.users || this.state.users.length === 0) return null;
    return this.state.users.find(u => u.id === this.state.currentUserId) || this.state.users[0] || null;
  }

  hasPermission(permission: CapabilityPermission): boolean {
    const user = this.getCurrentUser();
    if (!user) return false;
    const pSet = (this.state.permissionSets || []).find(p => p.id === user.permissionSetId);
    return pSet ? pSet.permissions.includes(permission) : false;
  }

  canSeeRecord(recordOwnerId?: string, recordBranchId?: string, recordTerritoryId?: string): boolean {
    const user = this.getCurrentUser();
    if (!user) return false;
    
    const role = (this.state.roles || []).find(r => r.id === user.roleId);
    if (!role) return false;

    switch (role.visibilityScope) {
      case 'ORG': return true;
      case 'BRANCH': return !recordBranchId || recordBranchId === user.branchId;
      case 'TERRITORY': return !recordTerritoryId || recordTerritoryId === user.territoryId;
      case 'TEAM': {
        const userTeams = (this.state.groups || []).filter(g => g.memberIds.includes(user.id));
        return userTeams.some(t => t.memberIds.includes(recordOwnerId || ''));
      }
      case 'OWNER': return recordOwnerId === user.id;
      default: return false;
    }
  }

  getFieldVisibility(entityType: string, field: string): 'SEE' | 'DO' | 'HIDDEN' {
    const user = this.getCurrentUser();
    if (!user) return 'HIDDEN';
    const pSet = (this.state.permissionSets || []).find(p => p.id === user.permissionSetId);
    if (!pSet || !pSet.fieldPermissions) return 'DO';

    const key = `${entityType}.${field}`;
    return pSet.fieldPermissions[key] || 'DO';
  }

  canAccessWorkspace(tab: NavigationTab): boolean {
    switch (tab) {
      case 'accounts': return this.hasPermission('accounts.view');
      case 'leads': return this.hasPermission('leads.view');
      case 'quotes': return this.hasPermission('quotes.view');
      case 'finance': return this.hasPermission('finance.view');
      case 'cases': return this.hasPermission('cases.view');
      case 'marketing': return this.hasPermission('marketing.manage');
      case 'knowledge': return this.hasPermission('knowledge.manage');
      case 'settings': return this.hasPermission('settings.manage') || this.hasPermission('users.manage') || this.hasPermission('roles.manage');
      case 'internal_automation': return this.hasPermission('internal.view') || this.hasPermission('internal.manage');
      default: return true;
    }
  }
}
