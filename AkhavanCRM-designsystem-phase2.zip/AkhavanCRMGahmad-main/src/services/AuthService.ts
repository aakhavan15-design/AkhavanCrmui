import { AppState, UserAccount } from '../types';

export const AuthService = {
  getCurrentUser(state: AppState): UserAccount | null {
    if (!state.users || state.users.length === 0) return null;
    return state.users.find(u => u.id === state.currentUserId) || state.users[0] || null;
  }
};
