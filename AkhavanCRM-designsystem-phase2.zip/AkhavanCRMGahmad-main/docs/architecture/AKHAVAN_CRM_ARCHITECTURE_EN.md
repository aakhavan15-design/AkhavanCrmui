# Technical Architecture & Core Engines (AKHAVAN CRM ARCHITECTURE)
## Three-Tier Software Architecture, 28 Domain Engines, and Data Sovereignty

---

### 1. Mission Statement & System Scope
**AKHAVAN CRM** is an enterprise-grade platform uniting Customer 360, Configure-Price-Quote (CPQ), receivables monitoring, Sayad commercial cheque tracking, and sales workflow automation tailored for modern industrial and commercial environments. The platform is architected for sovereign, client-resilient operation without dependence on external backend servers.

---

### 2. Three-Tier Architectural Topology

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     TIER 1: INTERFACE & PRESENTATION                    │
│  - Modular Workspaces (Quotes, Accounts, Tasks, Finance, Reports, Sets) │
│  - Responsive Universal Navigation (Desktop Sidebar & Mobile Drawer)    │
│  - Accessible Design System with Tabular Numbers & RTL Support          │
├─────────────────────────────────────────────────────────────────────────┤
│                     TIER 2: COMPUTATION & CORE LOGIC                    │
│  - CPQ Engine with Tiered Discounts, Bundles & Waterfall Margin Analysis│
│  - Dual Jalali / Gregorian Date Engine                                  │
│  - Business Event Dispatcher & RBAC Authorization                       │
│  - Local AI Agent Simulator & Native Iranian Messaging Adapters         │
├─────────────────────────────────────────────────────────────────────────┤
│                     TIER 3: DATA PERSISTENCE & RESILIENCE               │
│  - IndexedDB & Synchronized LocalStorage Client Store                   │
│  - Offline Mutation Queue & Conflict Resolution                         │
│  - Structured Data Export/Import (CSV / JSON)                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

### 3. Detailed Specifications of the 28 Core Domain Engines

1. **Customer 360 Engine:** Aggregates interactions, invoices, cheques, and history around account entities.
2. **CPQ Pricing Engine:** Real-time computation of net unit prices, cost of goods, and gross margin percentages.
3. **Price Waterfall Engine:** Transparent step-down breakdown from list price to contracted net price.
4. **Product Bundle Engine:** Grouping discrete products with composite discounting logic.
5. **Volume Tier Engine:** Dynamic discount adjustments based on quantity thresholds.
6. **Contract Terms Engine:** Application of annual rebates and corporate terms.
7. **Pricing Snapshot Engine:** Immutable snapshot freeze on approved and finalized commercial quotes.
8. **Quote-to-Invoice Bridge:** Conversion of accepted quotes into financial receivables and billing entries.
9. **Receivables & Collection Engine:** Live calculation of account balances, overdue debts, and cash flow risk.
10. **Sayad Cheque Engine:** Lifecycle management of commercial banking cheques and maturity tracking.
11. **Dual Calendar Engine:** Bidirectional Jalali and Gregorian date conversions and formatting.
12. **Workflow Automation Engine:** Event-driven rule evaluation and automatic action triggers.
13. **Approval Matrix Engine:** Multi-step escalation for quotes violating margin guardrails.
14. **RBAC Security Engine:** Granular permission resolution based on roles, scopes, and workspaces.
15. **Device Permission Engine:** Client hardware bridge for location, camera, and notification access.
16. **Native Messaging Engine:** Webhook simulation and message dispatch for Eitaa, Rubika, and Bale.
17. **AI Safety Kill-Switch Engine:** Global circuit-breaker to instantly suspend all autonomous AI agent triggers.
18. **Human-in-the-Loop Audit Queue:** Queuing autonomous agent actions for supervisory review and approval.
19. **Lead Qualification Engine:** Pipeline monitoring from initial touchpoint to qualified account conversion.
20. **Advanced Margin Matrix Engine:** Risk prevention against loss-making enterprise transactions.
21. **Command Palette Engine:** Keyboard-driven instant navigation and search across all entities.
22. **Notification Dispatch Engine:** Centralized dispatch for cheque maturity, task deadlines, and quote approvals.
23. **Audit Logging Engine:** Tamper-evident logging of actor identities, timestamps, and payload diffs.
24. **Duplicate Account Merge Engine:** Heuristic matching and merging of redundant customer records.
25. **Print & Export Engine:** Standardized print layouts for quotes and invoices with official signatures.
26. **Local Persistence Engine:** High-performance caching in IndexedDB for resilient offline operations.
27. **Industry Profile Engine:** Dynamic field and process tailoring across appliances, trade, and services.
28. **KPI & Analytics Engine:** Real-time executive dashboards measuring revenue velocity and pipeline health.

---

### 4. Integration Boundaries with Enterprise ERP Systems
- The CRM owns commercial negotiation, quoting, discount governance, and customer interaction history.
- Final tax compliance, ledger entries, and double-entry accounting reside in ERP systems; data synchronization is bridged via standardized Webhooks and export channels.
