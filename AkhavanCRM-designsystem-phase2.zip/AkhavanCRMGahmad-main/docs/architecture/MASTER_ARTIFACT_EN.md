# Master Engineering Artifact & Quality Assurance Standard (MASTER ARTIFACT)
## Enterprise Customer Relationship Management & CPQ (AKHAVAN CRM)

---

### 1. Document Objective & Philosophy
This document establishes the binding engineering guidelines, software architecture standards, implementation principles, and quality assurance criteria for developers, software engineers, and automated agents collaborating on the **AKHAVAN CRM** codebase. Adherence to all rules defined herein is mandatory and non-negotiable.

---

### 2. Golden Engineering Rules & Guardrails

1. **Zero Feature Regression Principle:**
   No existing workspace, sub-tab, action button, input form, calculation routine, or business rule shall be removed, hidden, or degraded during updates, refactoring, or visual enhancements. All improvements must maintain backward compatibility and preserve all functional surfaces.

2. **Zero-Mock UI Policy:**
   No button or clickable link shall be cosmetic, inert (no-op), or purely placeholder. Every user-facing action must trigger a real operation: opening a verified modal, submitting or updating state persistence, firing an audited domain event, or redirecting to valid resources.

3. **Core Multi-Tenancy & Tenant Neutrality:**
   Akhavan is the initial enterprise tenant deployed upon this framework. Core domain engines, data structures, and state management controllers are strictly tenant-neutral. Tenant-specific branding and business rules reside in configuration profiles, never hardcoded into core abstractions.

4. **Customer 360 Sovereignty:**
   Every commercial quote, task, interaction activity, invoice, and note must attach to a definitive Account or Contact within the unified Customer 360 repository. No orphaned records are permitted.

5. **Strict CRM vs. Financial ERP Boundaries:**
   The CRM oversees commercial quotes (CPQ), payment terms, receivables monitoring, Sayad cheques tracking, and sales milestones. Deep general ledger accounting, payroll, and asset depreciation are integrated via external Webhooks and ERP connectors (e.g., Sepidar, Rahkaran, System Group).

---

### 3. Unified Design Constitution & Visual Guidelines

- **RTL-First Typography & Accessibility:**
  - Native Right-to-Left (RTL) directional layout with verified icon mirroring and tabular numeric alignment (`tabular-nums`) for currency, identifiers, and timestamps.
- **Zero-Pill Discipline:**
  - Elimination of decorative, content-free pill tags. Statistical summaries and metadata are rendered using clean typographic hierarchy and subtle boundary borders (`border-border/60`).
- **Contrast & Ergonomics (WCAG AA Compliance):**
  - High-contrast text and interactive action buttons meeting the 4.5:1 ratio threshold on all device screens.
- **Cross-Platform Responsive Navigation:**
  - Fluid responsiveness supporting Desktop workstations (1920px/1440px), laptops, tablets, and mobile smartphones with a drawer sidebar and interactive bottom sheet navigation.

---

### 4. Localization & Dual-Calendar Architecture

1. **Jalali / Gregorian Dual Calendar Engine:**
   System-wide runtime support for switching between the Persian Solar Hijri (Jalali) calendar and the Gregorian calendar across invoices, tasks, meeting schedules, and transaction registers.
2. **Numeral and Currency Standardization:**
   Configurable number formatting (Persian digits `۱۲۳` vs. Latin digits `123`) and official currency denominations (Iranian Rials, Tomans, foreign currencies).
3. **Canonical Date Persistence:**
   All dates are stored in canonical ISO-8601 UTC strings and transformed dynamically into the user's localized presentation layer.

---

### 5. Role-Based Access Control & CPQ Authorization (RBAC / ABAC)

- **Standard Roles:**
  - Super Admin: Comprehensive system administration and tenant management.
  - Sales Director: Quote discounting approvals, margin thresholds, team analytics.
  - Sales Representative: Account management, task execution, quote drafting.
  - Financial Controller: Invoicing, payment reconciliation, Sayad cheque registration.
- **CPQ Margin Guardrails:**
  - Any quote falling below the organizational minimum gross margin threshold (default 15%) is locked into `PENDING_APPROVAL` status until explicitly authorized by management.
  - Snapshot freeze on approved or dispatched quotes prevents retroactive modifications to quoted items and pricing tiers.

---

### 6. QA Checklist & Verification

- [x] Zero TypeScript compilation errors (`tsc --noEmit`).
- [x] Production bundling passes cleanly (`vite build`).
- [x] Interactive messaging gateway simulator (Eitaa, Rubika, Bale) operational with live event auditing.
- [x] AI agent safety kill-switch and tool access permissions enforced.
- [x] Quote-to-Invoice conversion flow fully bridged with Sayad cheque tracking.
