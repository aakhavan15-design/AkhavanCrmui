# ⚠️ دستورالعمل الزامی مطالعه پیش از شروع توسعه پروژه AKHAVAN CRM

> **هشدار مهم برای تمام توسعه‌دهندگان، مهندسین نرم‌افزار و ابزارهای هوش مصنوعی (AI Assistants):**
> قبل از نوشتن حتی یک خط کد، تغییر هرگونه کامپوننت، ویرایش API، یا دستکاری در دیتابیس این پروژه، مطالعه کامل ۴ فایل موجود در این پوشه **کاملاً اجباری و غیرقابل‌مذاکره** است.

---

## 📌 لیست مستندات مرجع پروژه

۱. **`MASTER_ARTIFACT_FA.md` (سند استاندارد مهندسی و تضمین کیفیت - فارسی)**
   - شامل خطوط قرمز مهندسی، اصل عدم حذف قابلیت‌ها، سیستم دیزاین یکپارچه، کنترل اکشن‌ها و دکمه‌ها، بومی‌سازی RTL/تقویم، و چک‌لیست پذیرش ماژول‌ها.

۲. **`MASTER_ARTIFACT_EN.md` (Engineering Standards & Quality Assurance - English)**
   - English reference for engineering guardrails, zero mock UI policy, strict RBAC/ABAC authorization, and module acceptance checklists.

۳. **`AKHAVAN_CRM_ARCHITECTURE_FA.md` (معماری کلان و مأموریت محصول - فارسی)**
   - شامل تعریف مأموریت محصول، اصالت Customer 360، تفکیک مرزها با ERP/مالی، لایه‌بندی سه‌گانه و شرح ۲۸ موتور تخصصی نرم‌افزار.

۴. **`AKHAVAN_CRM_ARCHITECTURE_EN.md` (Technical Architecture & Core Engines - English)**
   - Complete technical breakdown of domain engines, multi-tenancy rules, industry profiles layer, and ERP separation boundaries.

---

## 🛑 قوانین طلایی توسعه (Golden Rules)
- **اصل حفظ قابلیت‌ها:** هیچ کد یا قابلیتی نباید به بهانه بازنویسی یا توسعه جدید حذف، پنهان یا خراب شود.
- **اصالت Customer 360:** تمام داده‌ها و فعالیت‌ها باید به پرونده یکپارچه مشتری متصل باشند.
- **عدم وابستگی به اخوان:** اطلاعات و قوانین شرکت اخوان نباید در هسته کد هاردکد شوند؛ اخوان صرفاً نخستین مستأجر (Tenant) سیستم است.
- **توسعه مبتنی بر اثبات:** هیچ باگ یا قابلیتی بدون تست واقعی و قابل مشاهده تایید نمی‌شود.
