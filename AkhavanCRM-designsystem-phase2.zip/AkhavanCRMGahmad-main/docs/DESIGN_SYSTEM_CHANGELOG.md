# طراحی سیستم — فایل‌های تغییرکرده (فاز ۱ و ۲)

قابلیتی حذف نشده؛ فقط ظاهر/ناوبری. Build و Lint اجرا نشده (محیط بدون node_modules).

```
NEW src/components/NavDock.tsx
NEW src/components/charts
NEW src/components/ui/PageToolbar.tsx
NEW src/lib/navigation.ts
src/App.tsx
src/components/ActivitiesWorkspace.tsx
src/components/CommandPalette.tsx
src/components/Customer360.tsx
src/components/DashboardWorkspace.tsx
src/components/EnterpriseWorkspaces.tsx
src/components/ErrorBoundary.tsx
src/components/GroupsWorkspace.tsx
src/components/HomeWorkspace.tsx
src/components/InternalAutomationWorkspace.tsx
src/components/Layout.tsx
src/components/LeadsWorkspace.tsx
src/components/NavigationDrawer.tsx
src/components/NegotiationsWorkspace.tsx
src/components/PrintLayouts.tsx
src/components/ProfitModal.tsx
src/components/QuoteWizardModal.tsx
src/components/QuotesWorkspace.tsx
src/components/ReportsWorkspace.tsx
src/components/SettingsWorkspace.tsx
src/components/modals/CustomerActionModals.tsx
src/components/modals/ModalOverlay.tsx
src/components/shared/TaskCard.tsx
src/components/ui/AttachmentManager.tsx
src/components/ui/Avatar.tsx
src/components/ui/Badge.tsx
src/components/ui/Button.tsx
src/components/ui/CustomDatePicker.tsx
src/components/ui/EmptyState.tsx
src/components/ui/Input.tsx
src/components/ui/Modal.tsx
src/components/ui/Progress.tsx
src/components/ui/SearchableSelect.tsx
src/components/ui/SecureField.tsx
src/components/ui/Tabs.tsx
src/components/ui/index.ts
src/index.css
src/lib/tokens.ts
src/workspaces/ProfileWorkspace.tsx
```
